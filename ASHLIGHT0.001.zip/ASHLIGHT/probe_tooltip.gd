extends SceneTree

func _initialize() -> void:
	var s := preload("res://battle/scripts/units/unit_buff_tooltip.gd")
	print("PROBE OK: ", s)
	quit()

class_name BattleRoot
extends Node2D

## 战斗场景根节点（战斗场景骨架）。
## 当前职责：持有三层背景节点（Background / Midground / Foreground）的引用，并在 _ready 统一设置各层 z_index，
## 确保绘制顺序为 Background（最底）→ Midground → Foreground（最顶）。
## 单位放置逻辑（原单位槽位）已按需求移除；后续由用户指定放置方案后再接入。

# 三层背景的 z_index：Background 在最底、Foreground 在最顶。
const Z_FAR: int = -20
const Z_MID: int = 0
const Z_NEAR: int = 20

@onready var layer_far: Node2D = get_node("Background") as Node2D
@onready var layer_mid: Node2D = get_node("Midground") as Node2D
@onready var layer_near: Node2D = get_node("Foreground") as Node2D
@onready var atb_track: AtbTrack = get_node("ATB/AtbTrack") as AtbTrack

## 单位组容器引用（_collect_roster_into_atb 中缓存，供 _process 每帧命中测试）。
var _units: Node2D
## 当前「聚光」单位 uid（每帧权威重算，见 _process）。空串=无聚光，全部彩色。
var _spot_uid: String = ""

func _ready() -> void:
	add_to_group("battle_root")   # 供 HandManager 经 group 取得本节点（与 hand_manager 组对称），避免硬编码路径
	_apply_layer_order()
	_collect_roster_into_atb()
	_randomize_unit_rows()

## 统一设置三层背景的绘制层级（单一真相来源，避免散落在 .tscn 里）。
func _apply_layer_order() -> void:
	if is_instance_valid(layer_far):
		layer_far.z_index = Z_FAR
	if is_instance_valid(layer_mid):
		layer_mid.z_index = Z_MID
	if is_instance_valid(layer_near):
		layer_near.z_index = Z_NEAR


## 收集 Units 子节点的 UnitRoot 节点，喂给 ATB 轨道，使 ATB 插图与战斗单位联动。
## 联动方向：Units（单一真相来源）→ AtbTrack.start_turn，避免两份硬编码名册。
## 联动后：逐一对【敌方】单位读取其意图（type/target/value），经 AtbTrack.apply_enemy_intent
## 同步给对应 ATB 部件，使 ATB 的敌人意图图标与 battle 单位的意图图标完全一致。
func _collect_roster_into_atb() -> void:
	if not is_instance_valid(atb_track):
		return
	var units := get_node_or_null("Units") as Node2D
	if units == null:
		return
	_units = units
	var nodes: Array = []
	for u in units.get_children():
		if u is UnitRoot:
			nodes.append(u)
	# 高亮框(第0格)占据单位变化 → 转发给 HandManager 动态扩/缩手牌组间距（连接一次，防重复）。
	if not atb_track.framed_changed.is_connected(_on_atb_framed_changed):
		atb_track.framed_changed.connect(_on_atb_framed_changed)
	atb_track.start_turn(nodes)
	# 敌方意图联动：
	# ① 初始同步；② 信号绑定 UnitRoot.intent_changed → AtbTrack.apply_enemy_intent，
	#    之后战斗单位意图实时变更时，ATB 对应部件自动跟随（向上广播、向下不依赖 parent）。
	for u in units.get_children():
		if u is UnitRoot:
			var root := u as UnitRoot
			if root.unit_faction == "enemy":
				var info: Dictionary = root.get_intent()
				if info.get("type", "") != "":
					atb_track.apply_enemy_intent(root.unit_id, info["type"], info["target"], info["value"])
				if is_instance_valid(atb_track):
					root.intent_changed.connect(atb_track.apply_enemy_intent)
	# 联动 hover 改由 BattleRoot._process 每帧权威命中测试驱动（见 _process / _apply_spot），
	# 不再依赖各部件/单位的 mouse_entered/exited（快速移动会漏发 exit，导致高亮卡死）。


## 每帧权威命中测试：决定当前「聚光」单位 uid（ATB 部件优先于单位组，二者视觉不重叠时取任一处）。
## 仅当聚光 uid 变化时才更新 ATB 压暗与单位组反向描边，避免每帧重启动画。
## 采用「每帧从头判定」而非信号，是因为 Godot 在鼠标快速移动时会漏发 mouse_exited，
## 导致离开的单位/部件卡在「高亮/黑叠」态——此处在每帧重算可彻底消除该残留。
func _process(_delta: float) -> void:
	if not is_instance_valid(atb_track) or not is_instance_valid(_units):
		return
	var mp := get_global_mouse_position()
	var uid := ""
	# ATB 部件（视觉在最高层 z=40）优先
	for p in atb_track.get_parts():
		if is_instance_valid(p) and p.is_point_inside(mp):
			uid = p.unit_uid()
			break
	if uid == "":
		for u in _units.get_children():
			if u is UnitRoot and (u as UnitRoot).is_point_inside(mp):
				uid = (u as UnitRoot).unit_id
				break
	if uid != _spot_uid:
		_apply_spot(uid)


## 应用聚光变化：清除上一个单位的反向描边、点亮新单位（若有）、并刷新 ATB 压暗。
func _apply_spot(uid: String) -> void:
	if _spot_uid != "":
		var prev := _find_unit(_spot_uid)
		if is_instance_valid(prev):
			prev.set_external_highlight(false)
	_spot_uid = uid
	if uid != "":
		var cur := _find_unit(uid)
		if is_instance_valid(cur):
			cur.set_external_highlight(true)
	if is_instance_valid(atb_track):
		atb_track.set_spotlight(uid)


## 选靶中使用：选中卡后左键点单位碰撞箱(UnitRoot.is_point_inside，即 _spot_uid) → 触发「使用」过程。
## 当前无效果：仅通知 HandManager 完成一次使用（广播 card_used + 复位手牌位移）；效果实装由 card_used 信号接。
## 右键取消与位移复位在 HandManager 内处理，本节点不重复。
func _input(event: InputEvent) -> void:
	if not (event is InputEventMouseButton):
		return
	var mb := event as InputEventMouseButton
	if not mb.pressed or mb.button_index != MOUSE_BUTTON_LEFT:
		return
	var hm := get_tree().get_first_node_in_group("hand_manager") as HandManager
	if not is_instance_valid(hm):
		return
	if hm.get_selected() == null:
		return
	if _spot_uid == "":
		return
	var unit := _find_unit(_spot_uid)
	if not is_instance_valid(unit):
		return
	# 点中黑幕单位(非目标) → 不可作为卡牌作用对象，吞掉本次点击（与黑幕规则一致：黑幕=不可选）。
	if unit.is_dimmed():
		return
	hm.notify_used_on_unit(unit)


## 按 unit_id 在 Units 子节点中查找对应 UnitRoot（联动的唯一真相来源，不缓存引用避免场景重置失效）。
func _find_unit(uid: String) -> UnitRoot:
	var units := get_node_or_null("Units") as Node2D
	if units == null:
		return null
	for u in units.get_children():
		if u is UnitRoot and (u as UnitRoot).unit_id == uid:
			return u as UnitRoot
	return null

## 返回战斗中所有 UnitRoot（缓存 _units 失效时回退重新查找）。供选靶黑幕枚举用。
func _get_units() -> Array[UnitRoot]:
	if not is_instance_valid(_units):
		_units = get_node_or_null("Units") as Node2D
	var out: Array[UnitRoot] = []
	if not is_instance_valid(_units):
		return out
	for u in _units.get_children():
		if u is UnitRoot:
			out.append(u as UnitRoot)
	return out

## 选靶黑幕：根据卡牌行标签与施法者(self_id 对应单位)计算目标集合，对集合外单位(施法者自身例外)盖黑幕剪影。
## row_tag ∈ {前排, 后排, 同排, 异排, 全部}（由 HandManager 从卡面 effects_text 解析得到）。
## 规则(v2.1, 用户确立 2026-09-07)：
##  - 统一定律：施法者自身恒为 lit（不盖黑幕）。
##  - 前排/后排：敌方按自身 is_back_row 绝对判定（前排→敌方前排 lit / 后排→敌方后排 lit）；我方除施法者外全部盖黑幕。
##  - 同排/异排：敌方全部盖黑幕；我方按施法者前后排相对判定（同排→同排队友 lit、异排队友盖；异排→异排队友 lit、同排队友盖）。
##  - 全部/未识别：全 lit（不盖）。
func set_target_dim(row_tag: String, self_id: String) -> void:
	var caster := _find_unit(self_id)
	var caster_back: bool = is_instance_valid(caster) and caster.is_back_row
	# [DEBUG] 选靶黑幕排查探针
	print("[BR] set_target_dim row_tag=%s self_id=%s caster_valid=%s caster_back=%s units=%d" % [row_tag, self_id, is_instance_valid(caster), caster_back, _get_units().size()])
	for u in _get_units():
		var ur := u as UnitRoot
		if not is_instance_valid(ur):
			continue
		var is_self: bool = is_instance_valid(caster) and ur == caster
		var lit: bool = is_self or _is_unit_target(ur, row_tag, caster, caster_back)
		print("[BR]   unit=%s faction=%s back=%s is_self=%s is_target=%s → %s" % [ur.unit_id, ur.unit_faction, ur.is_back_row, is_self, _is_unit_target(ur, row_tag, caster, caster_back), "亮(不盖)" if lit else "黑幕"])
		ur.set_dimmed(not lit)

## 清除全部单位黑幕（取消选靶 / 打出后调用）。
func clear_all_dim() -> void:
	for u in _get_units():
		var ur := u as UnitRoot
		if is_instance_valid(ur):
			ur.set_dimmed(false)

## 单卡行标签 → 该单位是否属目标集合（true=应高亮/不盖黑幕）。调用方已先行排除施法者自身。
## caster_back = 施法者是否后排；用于同排/异排的我方相对判定。
func _is_unit_target(ur: UnitRoot, row_tag: String, caster: UnitRoot, caster_back: bool) -> bool:
	var is_enemy: bool = ur.unit_faction == "enemy"
	match row_tag:
		"前排":
			# 敌方：前排(目标)亮、后排盖；我方：仅施法者亮(调用方已排除)，其余全盖
			return is_enemy and not ur.is_back_row
		"后排":
			# 敌方：后排(目标)亮、前排盖；我方：仅施法者亮，其余全盖
			return is_enemy and ur.is_back_row
		"同排":
			# 敌方全盖；我方：同排队友(目标)亮、异排队友盖
			if is_enemy:
				return false
			return ur.is_back_row == caster_back
		"异排":
			# 敌方全盖；我方：异排队友(目标)亮、同排队友盖
			if is_enemy:
				return false
			return ur.is_back_row != caster_back
		"全部", _:
			return true
	return true

## 卡牌「使用」后应用效果（当前实装：移动词条）。
## row_tag/scope 由 HandManager 从卡面 effects_text 解析后传入（与黑幕判定同源）。
## 目标集 = 行标签有效集(复用 _is_unit_target，与 v2.1 黑幕同源)；单体=被点单位，群体=有效集全部。
## q-0：移动对象=卡牌选中目标(敌我皆可)；q-1：先满足行标签，群体=满足后全部目标。
func apply_card_effect(hc: HandCard, unit: UnitRoot, row_tag: String, scope: String) -> void:
	if not is_instance_valid(hc) or not is_instance_valid(unit):
		return
	var cd := hc.data
	if cd == null:
		return
	var caster := _find_unit(hc.owner_group)
	var caster_back: bool = is_instance_valid(caster) and caster.is_back_row
	# 基础目标集：行标签有效集（无标签时 _is_unit_target 默认 true → 全场）。
	var base: Array[UnitRoot] = []
	for u in _get_units():
		var ur := u as UnitRoot
		if is_instance_valid(ur) and _is_unit_target(ur, row_tag, caster, caster_back):
			base.append(ur)
	var targets: Array[UnitRoot] = []
	if scope == "群体":
		targets = base
	else:
		targets = [unit]
	# ── 词条分发 ──
	if cd.effects_text.contains("【移动】"):
		print("[BR-effect] 移动: scope=%s row_tag=%s 命中单位数=%d → 翻转前后排" % [scope, row_tag, targets.size()])
		for t in targets:
			if is_instance_valid(t):
				t.is_back_row = not t.is_back_row
				print("[BR-effect]   unit=%s faction=%s back=%s → %s" % [t.unit_id, t.unit_faction, not t.is_back_row, t.is_back_row])


## ATB 高亮框(第0格)占据单位变化 → 转发给 HandManager 动态扩/缩对应角色手牌组间距。
## uid = 占据单位 uid（玩家单位 uid 即角色名 ROLES 之一）；is_player = 是否玩家阵营。
func _on_atb_framed_changed(uid: String, is_player: bool) -> void:
	var hm := get_tree().get_first_node_in_group("hand_manager") as HandManager
	if is_instance_valid(hm):
		hm.apply_framed_role(uid, is_player)




## 战斗场景生成结束后，随机为场上所有单位赋予前后排属性。
## 每个单位独立以 50% 概率落入后排(is_back_row=true)，其余为前排。
## 前后排由 UnitRoot.is_back_row 驱动（含后排渐变遮罩材质的自动切换）。
## 若后续需要「每边保证前后排数量平衡」，把此处的 randf() < 0.5 换成按阵营配额逻辑即可。
func _randomize_unit_rows() -> void:
	var units := get_node_or_null("Units") as Node2D
	if units == null:
		return
	for u in units.get_children():
		if u is UnitRoot:
			(u as UnitRoot).is_back_row = randf() < 0.5
	

extends SceneTree

## 验证插入预览标记：切换可见后两三角应上下浮动（本地 Y 在 -65/-30 间往返），无脚本错误。
var _track: AtbTrack
var _frames := 0
var _t0 := 0
var _samples: Array[String] = []

func _init() -> void:
	_track = load("res://battle/scripts/atb/atb_track.tscn").instantiate() as AtbTrack
	root.add_child(_track)

func _process(_d: float) -> bool:
	_frames += 1
	if _frames == 4:
		_track.toggle_insert_marker()
		_t0 = Time.get_ticks_msec()
	elif _frames > 4:
		var ms := Time.get_ticks_msec() - _t0
		if ms > 200 and ms < 2600 and _frames % 12 == 0:
			var up_y: float = _track._tri_up.position.y
			var down_y: float = _track._tri_down.position.y
			_samples.append("t=%.2fs up=%.1f down=%.1f gap=%.1f" % [ms / 1000.0, up_y, down_y, down_y - up_y])
		if ms > 2600:
			for s in _samples:
				print("MARKER " + s)
			quit()
	return false

class_name AtbPart
extends Node2D

## 单个 ATB 单位部件：插图 + 渐变黑幕 + 意图 icon + 确认高亮动画。
## 注意：本部件【不含高亮框】——高亮框是轨道(AtbTrack)级别的常驻指示器，
## 钉死在「当前行动格」，不随部件移动（见 atb_track.gd）。
## 部件原点 = 插图中心，便于轨道直接把 part.position 设到格子中心完成定位。
## 层级（z_index）：插图(0) < 黑幕(1) < icon(2) < 高亮动画(3)
## 黑幕仅覆盖插图矩形，不影响其它部件。

const ATB_ART_DIR: String = "res://assets/atb/unit_atb/"
const ART_PREFIX: String = "Img_"

## 意图 icon：使用 atb 文件夹内【用户已提供的美术资源】（res://assets/atb/{type_id}.png，如 att.png）。
## 注意：ATB 意图组不复用 battle 的意图资源，它有自己的美术（att/shield/state/think 图标），
## 仅保证「参数对应」——怪物意图 type=att 时，ATB 对应部件显示 atb 文件夹的 att.png。
const INTENT_ICON_DIR: String = "res://assets/atb/"
const ICON_FILES: Array[String] = ["att", "shield", "state", "think"]

const CONFIRM_DIR: String = "res://assets/atb/confirm/"
const CONFIRM_FRAMES: Array[String] = ["atb_confirm_1.png", "atb_confirm_2.png", "atb_confirm_3.png"]

## 叠加层（icon/动画）统一尺寸，用于居中定位。
const OVERLAY_SIZE: Vector2 = Vector2(53.0, 148.0)

## 主题色（9c660a），用于意图 icon 着色覆盖。
const COLOR_ENHANCED: Color = Color(0.61176, 0.4, 0.03922, 1.0)

## 联动高亮表现：常态/自身激活 = 彩色；其它部件被「聚光」时 = 灰度 + 沿插图 alpha 的 50% 黑叠。
## 意图 icon 与确认动画不挂此材质，故不受去饱和与黑叠影响。见 _build_saturation() 与 set_dimmed()。

## 联动表现着色器（canvas_item）：
##   saturation : 去饱和，1=彩色（常态/激活态），0=灰度（被聚光压暗时）。
##   black_amount : 沿【插图 alpha 形状】的黑色叠加量，0=无，0.5=50% 黑（被压暗时）。
## 注：Godot 4 的 CanvasItemMaterial 已移除 saturation 属性，故用 shader 自己算亮度混合。
const ATB_PART_LOOK_SHADER: String = """
shader_type canvas_item;
uniform float saturation : hint_range(0.0, 1.0) = 1.0;
uniform float black_amount : hint_range(0.0, 1.0) = 0.0;
void fragment() {
	vec4 col = texture(TEXTURE, UV);
	float l = dot(col.rgb, vec3(0.299, 0.587, 0.114));
	vec3 gray = vec3(l);
	vec3 out_rgb = mix(gray, col.rgb, saturation);
	out_rgb = mix(out_rgb, vec3(0.0), black_amount);
	COLOR = vec4(out_rgb, col.a);
}
"""

## 联动信号：本部件插图被鼠标悬停/离开时发出，携带所属单位 uid 供 BattleRoot 反向点亮对应单位组。
## 注：自 v 起 hover 判定改由 BattleRoot._process 每帧权威命中（见 is_point_inside），
##     本信号保留仅作向下兼容占位，实际已不再被连接。
signal part_hovered(uid: String)
signal part_unhovered()

## 阵营枚举。敌方(unit_id 在 ENEMY_IDS)才会显示随机意图 icon。
## WEATHER(天气)为预留最高优先级类，当前未提供具体部件（排序见 AtbTrack._precedence）。
enum Faction { WEATHER, ALLY, ENEMY }

## 卡牌类型（player 阵营专用，决定同格内先后）：执行(EXECUTION) 优先于 即时(SWIFT)。
## NONE 等同执行(EXECUTION)，保持既有行为；敌方/天气部件忽略此字段。
enum CardType { NONE, EXECUTION, SWIFT }

const ENEMY_IDS: Array[String] = [
	"Banner", "DogKnight", "Tusk", "AshrobeDevotee", "Grey",
	"Mafe", "Remy", "TheDisciplinarian", "VeiledAcolyte", "Wangg"
]


@onready var _view: TextureRect = $AtbView
@onready var _curtain: ColorRect = $BlackCurtain
@onready var _icon: TextureRect = $IntentIcon
@onready var _anim: AnimatedSprite2D = $HighlightAnim

## 插图相对部件中心的偏移（只挪插图，不挪叠加层）。
@export var art_offset: Vector2 = Vector2(0.0, -7.0)

## 黑幕渐变起点（0=顶, 1=底）：黑色仅从 black_start 到 1.0 的【底部一段】渐显，
## 值越大黑幕越靠下、黑→透明的过渡距离越短。0.55 = 仅底部 45% 渐变。
@export var curtain_black_start: float = 0.55

## 阵营（由 AtbTrack 按 unit_id 推断后写入）。
var faction: int = Faction.ALLY

## 卡牌类型（同格内 execution 优先于 swift；NONE 等同执行）。player 阵营卡牌后续接入时由 AtbTrack 写入。
var card_type: int = CardType.NONE

## 部件当前所在格子索引（由 AtbTrack 维护，用于轨道定位与「进入高亮框」判定）。
var cell_index: int = 0

## 敌方起始 ATB 格序号（由 AtbTrack 在 _spawn_part 时按 UnitRoot.start_cell_index 写入）。
## 用于敌方「行动结束」后重新插队到该格，以及预览标记显示其回插落点。玩家部件忽略（恒为 1）。
var start_cell_index: int = 1

## 已播放过确认动画（一次 tick 内防重复）。
var _confirmed_this_tick: bool = false

## 格内序号（同一格子可容纳多个部件，由 AtbTrack 维护的队列位置）。
var slot_index: int = 0

var _art_files: Array[String] = []
var _has_intent: bool = false
var _art_px: Vector2 = Vector2.ZERO
## 本部件对应的单位 uid（show_atb 时写入，供 AtbTrack.apply_enemy_intent 联动反查）。
var _uid: String = ""

## 联动表现材质（ShaderMaterial，仅挂到插图 _view）：
## saturation=1 → 彩色（常态/激活态）；=0 → 灰度（被聚光压暗时）。
## black_amount=0 → 无叠加；=0.5 → 沿插图 alpha 形状的 50% 黑叠（被压暗时）。
## 意图 icon 与确认动画不挂此材质，故二者既不去饱和、也不被黑叠遮挡。
var _sat_material: ShaderMaterial

## 返回本部件对应的单位 uid（AtbTrack 用它匹配敌方意图）。
func unit_uid() -> String:
	return _uid


func _ready() -> void:
	_scan_art_files()
	_build_overlays()
	if _art_files.is_empty():
		push_error("AtbPart: 未找到 ATB 插图，请将 Img_{unit_id}.png 放入 " + ATB_ART_DIR)
		return
	show_atb(_art_files[0])
	_build_saturation()

	# 让三个 Control 子节点（插图/黑幕/意图icon）一律忽略鼠标，避免它们吞掉 GUI 事件、
	# 导致下方 Area2D 收不到悬停。确认动画 _anim 是 AnimatedSprite2D(Node2D)，本就不接收 GUI 鼠标，无需处理。
	_ignore_mouse(_view)
	_ignore_mouse(_curtain)
	_ignore_mouse(_icon)


## 构建黑幕/意图 icon/确认动画，设定层级（z_index）。
func _build_overlays() -> void:
	_view.z_index = 0
	_curtain.z_index = 1
	_icon.z_index = 2
	_anim.z_index = 3

	# 黑幕：渐变着色器（底黑 → 顶透明），按【插图 alpha 形状】遮罩，
	# 这样圆角矩形插图的四角不会溢出黑色（mask_tex 在 show_atb 时设为插图纹理）。
	var shader := Shader.new()
	shader.code = """
shader_type canvas_item;
uniform vec4 color_top : source_color = vec4(0.0, 0.0, 0.0, 0.0);
uniform vec4 color_bottom : source_color = vec4(0.0, 0.0, 0.0, 1.0);
uniform sampler2D mask_tex;
uniform float black_start : hint_range(0.0, 1.0) = 0.55;
void fragment() {
	float mask = texture(mask_tex, UV).a;
	// 黑色仅从 black_start 到 1.0 的【底部一段】渐显（smoothstep），
	// 值越大黑幕越靠下、黑→透明过渡距离越短。
	float t = smoothstep(black_start, 1.0, UV.y);
	vec4 grad = mix(color_top, color_bottom, t);
	COLOR = vec4(grad.rgb, grad.a * mask);
}
"""
	var mat := ShaderMaterial.new()
	mat.shader = shader
	mat.set_shader_parameter("black_start", curtain_black_start)
	_curtain.material = mat
	_curtain.visible = false

	# 确认动画：SpriteFrames 三帧，仅播放一次（不循环）
	var frames := SpriteFrames.new()
	for i in CONFIRM_FRAMES.size():
		var path := CONFIRM_DIR + CONFIRM_FRAMES[i]
		var tex := load(path) as Texture2D
		if tex != null:
			frames.add_frame("default", tex)
	frames.set_animation_loop("default", false)
	_anim.sprite_frames = frames
	_anim.centered = false
	_anim.animation_finished.connect(_on_anim_finished)
	_anim.visible = false

	# 意图 icon：主题色覆盖，初始隐藏
	_icon.modulate = COLOR_ENHANCED
	_icon.visible = false


func _scan_art_files() -> void:
	_art_files.clear()
	var dir := DirAccess.open(ATB_ART_DIR)
	if dir == null:
		push_error("AtbPart: 无法打开目录 " + ATB_ART_DIR)
		return
	dir.list_dir_begin()
	var file_name := dir.get_next()
	while file_name != "":
		if not dir.current_is_dir() and file_name.get_extension().to_lower() == "png":
			_art_files.append(file_name.trim_prefix(ART_PREFIX).get_basename())
		file_name = dir.get_next()
	dir.list_dir_end()
	_art_files.sort()


## 按 unit_id（纯单位名）加载并显示插图，据尺寸定位黑幕与居中叠加层。
## 部件原点 = 插图中心，故插图左上 = -art_size/2 + art_offset。
func show_atb(unit_id: String) -> void:
	_uid = unit_id
	var path := ATB_ART_DIR + ART_PREFIX + unit_id + ".png"
	if not ResourceLoader.exists(path):
		push_error("AtbPart: 未找到插图 " + path)
		return
	var tex := load(path) as Texture2D
	if tex == null:
		return
	var art_size := tex.get_size()
	_art_px = art_size
	_view.texture = tex
	# 黑幕按插图 alpha 形状遮罩：把同一张插图纹理喂给着色器当蒙版，圆角不溢出。
	if _curtain.material is ShaderMaterial:
		(_curtain.material as ShaderMaterial).set_shader_parameter("mask_tex", tex)
	_view.expand_mode = TextureRect.EXPAND_KEEP_SIZE
	_view.stretch_mode = TextureRect.STRETCH_KEEP
	_view.size = art_size
	_view.visible = true

	# 黑幕必须精确覆盖插图矩形：与 _view 同左上角、同尺寸（插图经 art_offset 偏移后，
	# 黑幕若不跟随会溢出插图上下边缘）。
	var art_topleft := -art_size * 0.5 + art_offset
	_view.position = art_topleft
	_curtain.size = art_size
	_curtain.position = art_topleft

	var off := -OVERLAY_SIZE * 0.5
	_icon.position = off
	_anim.position = off


## 插图像素尺寸（部件占位宽高）。轨道用它计算内容驱动的动态格宽。
func art_size() -> Vector2:
	return _art_px


## 权威悬停命中测试：插图矩形（中心 = 世界 position + art_offset，尺寸 = 插图尺寸，水平各放宽 3px）。
## 由 BattleRoot._process 每帧调用，取代不可靠的 Area2D mouse_exited（快速移动会漏发离开事件导致高亮卡死）。
func is_point_inside(global_pos: Vector2) -> bool:
	var center := global_position + art_offset
	var size := _art_px + Vector2(6.0, 0.0)
	var half := size * 0.5
	return Rect2(center - half, size).has_point(global_pos)


# 悬停检测已移至 BattleRoot._process 每帧权威命中（见 is_point_inside），不再使用 Area2D。


## 构建联动表现材质（canvas_item shader），仅挂到插图(_view)：
## 常态 saturation=1（彩色）、black_amount=0（无黑叠）。
## 意图 icon(_icon)【不挂】此材质——既不随去饱和变灰，也不被黑叠遮挡（满足需求）。
## 黑幕(_curtain)保留自身渐变着色器、确认动画(_anim)保持彩色反馈，二者不挂此材质。
func _build_saturation() -> void:
	var sh := Shader.new()
	sh.code = ATB_PART_LOOK_SHADER
	_sat_material = ShaderMaterial.new()
	_sat_material.shader = sh
	_sat_material.set_shader_parameter("saturation", 1.0)
	_sat_material.set_shader_parameter("black_amount", 0.0)
	if is_instance_valid(_view):
		_view.material = _sat_material


## 让 Control 子节点忽略鼠标，确保下方 ActivationArea 收到悬停（避免 TextureRect 默认 STOP 吞事件）。
func _ignore_mouse(c: Control) -> void:
	if is_instance_valid(c):
		c.mouse_filter = Control.MOUSE_FILTER_IGNORE


## ---- 联动「聚光」API（由 AtbTrack 统一调度，本部件只管自己亮/暗）----
## dim=true → 本部件是「其它」：灰度 + 沿插图 alpha 的 50% 黑叠；
## dim=false → 本部件是聚光目标或常态：彩色、无黑叠。
## 意图 icon(_icon) 与确认动画(_anim) 不挂此材质，始终彩色且不被黑叠遮挡。
func set_dimmed(dim: bool) -> void:
	if not is_instance_valid(_sat_material):
		return
	var cur_s: float = _sat_material.get_shader_parameter("saturation")
	var cur_b: float = _sat_material.get_shader_parameter("black_amount")
	var tgt_s := 1.0 if not dim else 0.0
	var tgt_b := 0.0 if not dim else 0.5
	if absf(cur_s - tgt_s) < 0.001 and absf(cur_b - tgt_b) < 0.001:
		return
	var tw := create_tween().set_parallel(true)
	tw.tween_method(_set_saturation, cur_s, tgt_s, 0.18)
	tw.tween_method(_set_black, cur_b, tgt_b, 0.18)


## tween_method 代理：shader uniform 无法直接 tween_property，经此设 saturation / black_amount。
func _set_saturation(s: float) -> void:
	if is_instance_valid(_sat_material):
		_sat_material.set_shader_parameter("saturation", s)


func _set_black(b: float) -> void:
	if is_instance_valid(_sat_material):
		_sat_material.set_shader_parameter("black_amount", b)


# hover 信号改由 BattleRoot._process 权威判定后通过 AtbTrack.set_spotlight 应用，此处不再需要。


## 判定 unit_id 是否属于敌方阵营。
func is_enemy(unit_id: String) -> bool:
	return ENEMY_IDS.has(unit_id)


## 显示意图 icon（按 type_id，加载 atb 文件夹内用户已提供的 {type_id}.png，如 att.png）。
## 仅参数对应：怪物意图 type=att → 显示 atb 的 att.png；不改动 atb 自身美术资源。
## 意图与黑幕是绑定关系：开意图即开渐变黑幕（黑幕仅覆盖插图矩形）。
func set_intent(type_id: String, target_id: String = "", value: String = "") -> void:
	var path := INTENT_ICON_DIR + type_id + ".png"
	if not ResourceLoader.exists(path):
		push_error("AtbPart: 未找到意图图标 " + path)
		return
	var tex := load(path) as Texture2D
	if tex == null:
		return
	_icon.texture = tex
	_icon.visible = true
	_curtain.visible = true
	_has_intent = true


## 随机一张意图 icon（敌方单位调用，从 atb 文件夹已提供的图标中取）。
func random_intent() -> void:
	if ICON_FILES.is_empty():
		return
	var name := ICON_FILES[randi_range(0, ICON_FILES.size() - 1)]
	set_intent(name, "", "")


func clear_intent() -> void:
	_icon.visible = false
	_curtain.visible = false
	_has_intent = false


func has_intent() -> bool:
	return _has_intent


## 播放确认高亮动画一次（帧 1-3），播完自动隐藏。
func play_confirm() -> void:
	if _confirmed_this_tick:
		return
	if _anim.sprite_frames == null or _anim.sprite_frames.get_frame_count("default") == 0:
		return
	_confirmed_this_tick = true
	_anim.visible = true
	_anim.play("default")


func _on_anim_finished() -> void:
	# 防御：部件若在动画播完前被 queue_free（如场景重置/重抽名册），_anim 已随父节点释放，
	# 此时再赋值 visible 会报「previously freed」，故先校验有效性。
	if not is_instance_valid(_anim):
		return
	_anim.stop()
	_anim.visible = false


## 每个 tick 开始时清确认标记。
func reset_tick_flag() -> void:
	_confirmed_this_tick = false

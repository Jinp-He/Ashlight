extends SceneTree

## 端到端回归：顺序 execute_end 6 次（直接 await 协程），校验「卡死修复」未被 _insert 排序改动破坏，
## 且每拍结束后标记位置始终有限、_busy 已释放。

func _initialize() -> void:
	var track := load("res://battle/scripts/atb/atb_track.tscn").instantiate() as AtbTrack
	root.add_child(track)
	await process_frame
	print("PROBE EXEC start parts=%d" % track._parts.size())
	var ok := true
	for i in 6:
		await track.execute_end()
		if track._busy:
			print("PROBE EXEC tick %d 卡死(_busy 仍 true)!" % i)
			ok = false
			break
		var mp := track.get_insertion_point()
		if not is_finite(mp.x) or not is_finite(mp.y):
			print("PROBE EXEC tick %d marker 非有限 %s" % [i, mp])
			ok = false
			break
		print("PROBE EXEC tick %d ok marker_x=%.2f busy=%s" % [i, mp.x, track._busy])
	print("PROBE EXEC RESULT ok=%s" % ok)
	quit()

extends SceneTree

## 校验预览占位组三条新规则：
##  A/B：目标格为空 → 锚定在「(target-1,target) 分割线」（含最后一格、连续空格）
##  C ：目标格非空 → 按同格先后排序(_ordered_insert_index)算出 front 落点，占位组站该槽间隙中央

func _initialize() -> void:
	var track := load("res://battle/scripts/atb/atb_track.tscn").instantiate() as AtbTrack
	if track == null:
		push_error("PROBE: 场景加载失败")
		quit()
		return
	root.add_child(track)
	await process_frame  # _ready 跑完
	track.spawn_random()
	await process_frame

	var ok := true
	var fails := 0

	var layout := track._compute_layout()
	var line_xs := layout["line_xs"] as Array[float]

	# ---- 规则 A/B：空目标格 → 锚定在 (target-1, target) 分割线 ----
	var empty_cell := -1
	for c in track.cell_count:
		if track._cell_parts(c).is_empty():
			empty_cell = c
			break
	if empty_cell < 0:
		for attempt in 50:
			track.spawn_random()
			await process_frame
			for c in track.cell_count:
				if track._cell_parts(c).is_empty():
					empty_cell = c
					break
			if empty_cell >= 0:
				break
	if empty_cell > 0:
		track._framed = track._front_part()
		track._framed_target_cell = empty_cell
		var mp := track.get_insertion_point()
		var expect_left: float = line_xs[empty_cell - 1] if empty_cell - 1 >= 0 and empty_cell - 1 < line_xs.size() else line_xs[0]
		var dx: float = abs(mp.x - expect_left)
		print("PROBE A/B empty_cell=%d marker_x=%.2f expect_left=%.2f dx=%.2f" % [empty_cell, mp.x, expect_left, dx])
		if dx > 1.5:
			ok = false
			fails += 1
	else:
		print("PROBE A/B SKIP: 未找到空格（罕见）")

	# ---- 规则 A（最后一格空） ----
	var last := track.cell_count - 1
	var qlast := track._cell_parts(last)
	for p in qlast:
		track._detach(p)  # 摘出后 cell_index=-1，不参与任何格布局
	track._relayout(false)
	track._framed = track._front_part()
	track._framed_target_cell = last
	var mp2 := track.get_insertion_point()
	var expect_last: float = line_xs[last - 1] if last - 1 >= 0 and last - 1 < line_xs.size() else line_xs[0]
	var dx2: float = abs(mp2.x - expect_last)
	print("PROBE A last_empty marker_x=%.2f expect=%.2f dx=%.2f" % [mp2.x, expect_last, dx2])
	if dx2 > 1.5:
		ok = false
		fails += 1

	# ---- 规则 C：非空目标格按序排队（目标格须 >=1，cell0 是框内格、预览目标永远 >=1） ----
	var nc := -1
	for c in track.cell_count:
		if c >= 1 and not track._cell_parts(c).is_empty():
			nc = c
			break
	if nc >= 0:
		track._framed = track._front_part()
		track._framed_target_cell = nc
		var mp3 := track.get_insertion_point()
		var q := track._cell_parts(nc)
		var idx := _expect_index(q, track._front_part())
		var pos: Dictionary = track._compute_layout()["pos"]
		var exp_x: float
		if idx <= 0:
			var ll: float = line_xs[nc - 1] if nc - 1 >= 0 and nc - 1 < line_xs.size() else line_xs[0]
			var fl: float = float(pos[q[0]].x if pos.has(q[0]) else q[0].position.x) - track._part_width(q[0]) * 0.5
			exp_x = (ll + fl) * 0.5
		elif idx >= q.size():
			var lp: AtbPart = q[q.size() - 1]
			var tr: float = float(pos[lp].x if pos.has(lp) else lp.position.x) + track._part_width(lp) * 0.5
			var rl: float = line_xs[nc] if nc < line_xs.size() else tr
			exp_x = (tr + rl) * 0.5
		else:
			var pr: float = float(pos[q[idx - 1]].x if pos.has(q[idx - 1]) else q[idx - 1].position.x) + track._part_width(q[idx - 1]) * 0.5
			var cl: float = float(pos[q[idx]].x if pos.has(q[idx]) else q[idx].position.x) - track._part_width(q[idx]) * 0.5
			exp_x = (pr + cl) * 0.5
		var dx3: float = abs(mp3.x - exp_x)
		print("PROBE C nonempty_cell=%d idx=%d marker_x=%.2f expect=%.2f dx=%.2f" % [nc, idx, mp3.x, exp_x, dx3])
		if dx3 > 1.5:
			ok = false
			fails += 1
	else:
		print("PROBE C SKIP: 无空格（罕见）")

	print("PROBE RESULT ok=%s fails=%d" % [ok, fails])
	quit()


## 独立复刻排序（验证 _compute_marker_slot 用的 _ordered_insert_index 行为一致）
func _expect_index(q: Array[AtbPart], p: AtbPart) -> int:
	var pr := _rank(p)
	for i in q.size():
		if _rank(q[i]) > pr:
			return i
	return q.size()


func _rank(p: AtbPart) -> int:
	match p.faction:
		AtbPart.Faction.WEATHER:
			return 0
		AtbPart.Faction.ALLY:
			return 12 if p.card_type == AtbPart.CardType.SWIFT else 10
		AtbPart.Faction.ENEMY:
			return 20
		_:
			return 30

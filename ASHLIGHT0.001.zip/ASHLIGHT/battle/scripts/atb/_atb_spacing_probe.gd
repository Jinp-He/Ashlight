extends SceneTree

## 测量探针：插入后 / 推进后，部件实际 position 是否等于 _compute_layout 的 pos。
## 若插入后某部件 d(actual-computed) 显著 != 0，说明插入留下了不一致布局；
## 再跑一次 execute_end（推进）后若 d 全部 ≈ 0，则吻合用户「插入间距不对、推进复位」的描述。

var _track: AtbTrack
var _phase := 0
var _frames := 0
var _t0 := 0
var _log: Array[String] = []

func _init() -> void:
	_track = load("res://battle/scripts/atb/atb_track.tscn").instantiate() as AtbTrack
	root.add_child(_track)

func _process(_d: float) -> bool:
	_frames += 1
	if _phase == 0:
		if _frames > 3:
			_measure("spawn后")
			_track.add_part_at(0)
			_phase = 1
			_t0 = Time.get_ticks_msec()
	elif _phase == 1:
		if Time.get_ticks_msec() - _t0 > 1000:
			_measure("插入首格后")
			_track.execute_end()
			_phase = 2
			_t0 = Time.get_ticks_msec()
	elif _phase == 2:
		if Time.get_ticks_msec() - _t0 > 1200:
			_measure("执行结束(推进)后")
			_track.execute_end()
			_phase = 3
			_t0 = Time.get_ticks_msec()
	elif _phase == 3:
		if Time.get_ticks_msec() - _t0 > 1200:
			_measure("二次推进后")
			for l in _log:
				print(l)
			quit()
	return false

func _measure(tag: String) -> void:
	var layout: Dictionary = _track._compute_layout()
	var pos: Dictionary = layout["pos"]
	for c in _track.cell_count:
		var q: Array[AtbPart] = _track._cell_parts(c)
		if q.is_empty():
			continue
		var parts: Array[AtbPart] = q.duplicate()
		parts.sort_custom(func(a: AtbPart, b: AtbPart) -> bool: return a.slot_index < b.slot_index)
		var items: Array[String] = []
		for i in parts.size():
			var p_cur: AtbPart = parts[i]
			var exp: Vector2 = pos[p_cur] if pos.has(p_cur) else Vector2(-9999.0, -9999.0)
			var dx: float = p_cur.position.x - exp.x
			var gap_txt := ""
			if i > 0:
				var p_prev: AtbPart = parts[i - 1]
				var gap: float = p_cur.position.x - p_prev.position.x
				gap_txt = " gap=%.1f" % gap
			var flag := "OK" if abs(dx) < 0.5 else "<<< MISMATCH"
			items.append("s%d x=%.1f exp=%.1f d=%.1f%s %s" % [i, p_cur.position.x, exp.x, dx, gap_txt, flag])
		_log.append("MEAS [%s] cell%d(%d个): %s" % [tag, c, parts.size(), " | ".join(items)])

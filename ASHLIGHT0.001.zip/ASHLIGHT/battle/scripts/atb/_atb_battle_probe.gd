extends SceneTree

func _init() -> void:
	var scene := load("res://battle/scripts/atb/atb_track.tscn") as PackedScene
	var t := scene.instantiate() as AtbTrack
	t.start_with_marker = true
	root.add_child(t)
	await process_frame
	await process_frame
	var vis := t._insert_marker != null and t._insert_marker.visible
	var ip := t.get_insertion_point()
	print("PROBE battle marker visible=%s insertion_point=(%.1f,%.1f)" % [vis, ip.x, ip.y])
	if vis:
		print("RESULT OK")
	else:
		printerr("FAIL: marker not visible with start_with_marker=true")
	quit(0)

extends SceneTree

## ATB 轨道探针（仅开发验证，非游戏逻辑）：
## 校验内容驱动格宽、同格多部件间隔、黑幕对齐、阵营分块插队、空格 8px、10 部件上限、tick 后线段数量恒定。
## 跑法：Godot_console.exe --headless --path . --script battle/scripts/atb/_atb_probe.gd
## 注意：_initialize 阶段节点 _ready 尚未触发，所有校验必须放在 _process 第一帧之后。

var _track: AtbTrack = null
var _frames: int = 0
var _enemy: AtbPart = null


func _initialize() -> void:
	var scene := load("res://battle/scripts/atb/atb_track.tscn")
	_track = scene.instantiate() as AtbTrack
	_track.random_min = 0
	_track.random_max = 0
	root.add_child(_track)


## 断言某格内阵营序列非递减（ally 块在前、enemy 块在后，保持同阵营连续）。
func _assert_contiguity(cell: int) -> bool:
	var q := _track._cell_parts(cell)
	for i in range(1, q.size()):
		if q[i].faction < q[i - 1].faction:
			return false
	return true


## 断言黑幕与插图精确重合（同左上角、同尺寸）。
func _assert_curtain() -> bool:
	var ok := true
	for p in _track._parts:
		if p._curtain.position != p._view.position or p._curtain.size != p._view.size:
			ok = false
	return ok


## 返回某格实际宽度（右边界 - 左边界）。
func _cell_width(c: int) -> float:
	var lxs: Array[float] = _track._compute_layout()["line_xs"]
	var left := _track.origin.x if c == 0 else lxs[c - 1]
	return lxs[c] - left


func _static_checks() -> void:
	# ---- 阵营分块插队（核心修正）：cell0 = [ally, enemy, ally] 应落为 [ally, ally, enemy] ----
	_track._clear_parts()
	_track._build_lines()
	_track._framed = null
	_track._spawn_part("Zhouzhou", 0)   # ally
	_track._spawn_part("Banner", 0)     # enemy
	_track._spawn_part("Rocket", 0)     # ally（应插到 ally 块末尾，而非落到 enemy 之后）
	_track._relayout(false)
	print("PROBE --- 阵营分块插队（cell0 依次 ally/enemy/ally） ---")
	_dump()
	var q0 := _track._cell_parts(0)
	var seq := ""
	for p in q0:
		seq += "E" if p.faction == AtbPart.Faction.ENEMY else "A"
	var contig := _assert_contiguity(0)
	print("PROBE 序列=%s 同阵营连续=%s（期望 AAE / true；旧逻辑会得 AEA 混排）" % [seq, contig])

	# ---- 同格多部件间隔 2px + cell0 宽 129 + line0=279 ----
	var expect_x: Array[float] = [173.5, 214.5, 255.5]
	var ok := q0.size() == 3
	for i in q0.size():
		if absf(q0[i].position.x - expect_x[i]) > 0.01:
			ok = false
	print("PROBE cell0 三部件间隔2px 命中=%s (x=%s)" % [ok, [q0[0].position.x, q0[1].position.x, q0[2].position.x]])
	var lxs: Array[float] = _track._compute_layout()["line_xs"]
	print("PROBE cell0宽=%.1f 期望129.0 | line0.x=%.1f 期望279.0" % [lxs[0] - _track.origin.x, _track._lines[0].position.x])

	# ---- 黑幕对齐 + 敌方意图 ----
	_enemy = q0[2]
	print("PROBE 黑幕对齐插图=%s（期望 true）| 敌方 intent=%s curtain=%s" % [
		_assert_curtain(), _enemy.has_intent(), _enemy._curtain.visible])
	print("PROBE 线粗=%.1f 颜色=%s（期望 2.0 / (0,0,0,1)）" % [_track._lines[0].width, _track._lines[0].default_color])

	# ---- 空格子宽度 = line_gap*2 = 8（仅留线两侧 4px） ----
	# 当前 cell0 有 3 部件、cell1-4 空、再加一个部件到 cell5。
	_track._spawn_part("Tusk", 5)
	_track._relayout(false)
	var empty_w := _cell_width(1)
	print("PROBE 空格子宽=%.1f 期望8.0（线周围仅 4px 间距）" % empty_w)
	var nonempty := _cell_width(5)
	print("PROBE 单部件格宽=%.1f 期望47.0（4+39+4）" % nonempty)


## 10 部件上限 + 重复单位 + 分块连续校验。
func _ten_part_test() -> void:
	_track._clear_parts()
	_track._build_lines()
	_track._framed = null
	_track.random_min = 10
	_track.random_max = 10
	_track.spawn_random()
	print("PROBE --- 10 部件测试 ---")
	_dump()
	var total := _track._parts.size()
	var all_contig := true
	for c in _track.cell_count:
		if not _assert_contiguity(c):
			all_contig = false
	print("PROBE 部件总数=%d 期望10 | 各格同阵营连续=%s | 线数=%d 期望5" % [
		total, all_contig, _track._lines.size()])
	print("PROBE 黑幕对齐(10部件)=%s" % _assert_curtain())


func _process(_delta: float) -> bool:
	_frames += 1
	if _frames == 2:
		_static_checks()
	elif _frames == 4:
		_ten_part_test()
	elif _frames == 6:
		_track.execute_end()
	elif _frames == 160:
		print("PROBE --- tick1 后 ---")
		_dump()
		_track.execute_end()
	elif _frames == 340:
		print("PROBE --- tick2 后 ---")
		_dump()
		_setup_collapse_case()
	elif _frames == 346:
		_track.execute_end()
	elif _frames == 560:
		print("PROBE --- 折叠 tick 后（应左推：c0/c1/c2 空 → 部件到前排，线循环复用） ---")
		_dump()
		var vis := 0
		for line in _track._lines:
			if line.visible and line.modulate.a > 0.5:
				vis += 1
		print("PROBE 线总数=%d 可见=%d（期望 5/5，证明队尾复用而非只剩尾线）" % [_track._lines.size(), vis])
		return true
	return false


## 构造「cell0/cell1 空、cell3 有部件」用例，验证连续空格折叠 + 线段循环复用。
func _setup_collapse_case() -> void:
	_track._clear_parts()
	_track._build_lines()
	_track._framed = null
	_track._spawn_part("Zhouzhou", 3)
	_track._spawn_part("Banner", 3)
	_track._relayout(false)
	print("PROBE --- 折叠用例（c0/c1/c2 空，c3 两部件） ---")
	_dump()


func _dump() -> void:
	var occ: Array[String] = []
	for c in _track.cell_count:
		var q := _track._cell_parts(c)
		var ids: Array[String] = []
		for p in q:
			ids.append("%s%d" % ["E" if p.faction == AtbPart.Faction.ENEMY else "A", p.slot_index])
		occ.append("c%d[%s]" % [c, ",".join(ids)])
	var lx: Array[String] = []
	for line in _track._lines:
		lx.append("%.0f%s" % [line.position.x, "" if line.visible else "(hid)"])
	var want: Array[float] = _track._compute_layout()["line_xs"]
	print("PROBE 部件=%d 线=%d | %s | lines=%s | 终态期望=%s" % [
		_track._parts.size(), _track._lines.size(), " ".join(occ), " ".join(lx),
		[want[0], want[1], want[2], want[3], want[4]]])

class_name AtbRoot
extends Node2D

## ATB 测试场景宿主：实例化 AtbTrack，提供调试按钮。
## 按钮：
##   重生成   —— 随机插入 0-4 个部件（可多个落在同一格）
##   执行结束 —— ATB tick：队首 detour 按阵营插队 → 其余与线段重排 → cell0 空则折叠左推 → 入框播确认
##   全部意图 —— 切换敌方意图 icon 与黑幕显隐
##   插入首格 —— 往 cell0 追加一个随机单位，验证「同格多部件 + 插队时分隔线随格子位移」
##   插入预览 —— 切换 cell0 插入位置预览标记（▲/▼ 双白三角，夹住插入点上下浮动）

@onready var _track: AtbTrack = $AtbTrack


func _on_btn_respawn_pressed() -> void:
	_track.spawn_random()


func _on_btn_execute_pressed() -> void:
	_track.execute_end()


func _on_btn_intent_pressed() -> void:
	_track.toggle_all_intents()


func _on_btn_add_pressed() -> void:
	_track.add_part_at(0)


func _on_btn_marker_pressed() -> void:
	_track.toggle_insert_marker()

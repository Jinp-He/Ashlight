class_name AtbTrack
extends Node2D

## ATB 轨道系统：分隔线隔出格子，最左格(cell0)常驻高亮框（钉死不动，见工作记忆「ATB 收窄到当前行动格」）。
##
## 布局模型（内容驱动，非固定格宽）：
##   一格可容纳【多个】部件，按 slot_index 排成队列；
##   格宽 = line_gap*2 + Σ部件宽 + (n-1)*part_gap；空格退化为 line_gap*2（仅留线两侧 4px 间距）；
##   分隔线 i 钉在 cell i 的【右边界】，x 由左往右累积格宽算出。
##   => 任何插队/消费导致格宽变化时，线段自动随格子前进或后退（tween 位移），
##      而不是把同格部件挤到后一格去。
##
## 「执行结束」tick：
##   1. cell0 队首部件 detour（下移→横移→上插入）到【提前读取】的目标格（见 _framed_target_cell），按同格先后排序插队（见 _insert / _precedence）；
##   2. 其余部件与所有分隔线按新布局重排（Y 静态对齐，仅 detour 期间可破）；
##   3. 若 cell0 变空 → 淡出 line0 并把该 Line2D【循环复用】到队尾（瞬移+淡入），
##      所有部件左移一格；若新的 cell0 仍为空则继续折叠（对应「连续空格直接推进」）。
##      线段总数恒定，故场上永远有分隔线，不会只剩队尾在生成。
##   4. 新占据 cell0 slot0（高亮框内）的部件播放一次确认动画。

const HIGHLIGHT_FRAME: String = "res://assets/atb/atb_highlight.png"
const ATB_ART_DIR: String = "res://assets/atb/unit_atb/"
const ART_PREFIX: String = "Img_"

## 主题色（9c660a），高亮框描边。
const COLOR_ENHANCED: Color = Color(0.61176, 0.4, 0.03922, 1.0)

## 联动信号：某部件插图被鼠标悬停/离开时由本轨道转发，携带其 unit uid，
## 供 BattleRoot 反向点亮对应单位组（向上广播、不依赖 parent）。
## 注：自 v 起 hover 判定改由 BattleRoot._process 每帧权威命中（见 AtbPart.is_point_inside），
##     本信号保留仅作向下兼容占位，实际已不再被连接。
signal part_hovered(uid: String)
signal part_unhovered(uid: String)

## 高亮框(第0格)当前占据单位变化信号：携带其 unit uid 与是否玩家阵营。
## 供 BattleRoot 转发给 HandManager，动态扩/缩对应角色手牌组的间距。
signal framed_changed(uid: String, is_player: bool)

## 敌方回合开始信号：携带其 unit uid，供未来接入敌方 AI 行动逻辑（目前为占位，无实际行为）。
## 由 _maybe_auto_enemy_turn 在每个敌方「行动」开始时发出。
signal enemy_action_started(uid: String)

## 高亮框描边着色器：按 atb_highlight.png 的 alpha 边缘描边（贴合图形轮廓，非整张矩形）。
const FRAME_OUTLINE_SHADER: String = """
shader_type canvas_item;
uniform vec4 outline_color : source_color = vec4(0.61176, 0.4, 0.03922, 1.0);
uniform float outline_thickness : hint_range(0.0, 8.0) = 2.0;
void fragment() {
	vec4 col = texture(TEXTURE, UV);
	vec2 ts = outline_thickness / vec2(textureSize(TEXTURE, 0));
	float a = 0.0;
	a = max(a, texture(TEXTURE, UV + vec2(ts.x, 0.0)).a);
	a = max(a, texture(TEXTURE, UV - vec2(ts.x, 0.0)).a);
	a = max(a, texture(TEXTURE, UV + vec2(0.0, ts.y)).a);
	a = max(a, texture(TEXTURE, UV - vec2(0.0, ts.y)).a);
	a = max(a, texture(TEXTURE, UV + ts).a);
	a = max(a, texture(TEXTURE, UV - ts).a);
	a = max(a, texture(TEXTURE, UV + vec2(ts.x, -ts.y)).a);
	a = max(a, texture(TEXTURE, UV + vec2(-ts.x, ts.y)).a);
	COLOR = (col.a > 0.01) ? col : ((a > 0.01) ? outline_color : vec4(0.0));
}
"""

## 部件场景（AtbPart）。
@export var part_scene: PackedScene

## 联动名册：指定本轨道要展示的单位 unit_id 列表（如 Battle 场景 Units 子节点的 unit_id）。
## 非空时 _ready 用其生成部件（取代随机扫描），实现 ATB 与战斗单位联动；空则回退 spawn_random（独立测试场景）。
@export var unit_roster: Array[String] = []

## 格子数 / 分隔线数（5 线钉在 cell0..cell4 右边界 → 6 格）。
@export var cell_count: int = 6
@export var line_count: int = 5

## 轨道左上基准（cell0 左边界 x；竖线垂直中心 y）。
@export var origin: Vector2 = Vector2(150.0, 440.0)

@export_group("Line")
## 竖线长度 / 粗度 / 颜色（黑色 2px）。
@export var line_length: float = 100.0
@export var line_thickness: float = 2.0
@export var line_color: Color = Color(0.0, 0.0, 0.0, 1.0)

@export_group("Spacing")
## 同格内相邻部件的间隔。
@export var part_gap: float = 2.0
## 分隔线与部件的间隔（= 格子左右内边距）。
@export var line_gap: float = 4.0
## 部件标准宽度（插图 39px），用于高亮框定位的稳定基准。
@export var default_part_width: float = 39.0

@export_group("Animation")
## 部件/线段滑动时长。
@export var slide_time: float = 0.35
## 线段淡入淡出时长。
@export var fade_time: float = 0.2
## detour 下沉距离。
@export var detour_drop: float = 40.0

@export_group("Spawn")
## 随机插入部件数量范围（上限 10，允许同单位重复出现）。
@export var random_min: int = 5
@export var random_max: int = 10

@export_group("Marker")
## 预览占位组整体上下偏移（默认 -5 = 整组上移 5px；正数下移、负数上移）。
@export var marker_y_offset: float = -5.0
## 上下三角初始间距（默认 150 = 上下各 75px）。
@export var marker_gap: float = 140.0
## 浮动振幅（三角向中心收拢/扩散的幅度，单位 px）。
@export var marker_float_amp: float = 6.5
## 浮动单程时长（秒）。
@export var marker_float_time: float = 1.0
## 是否在 _ready 时直接打开插入位置预览（常态预览、始终显示）。
## 调试/独立测试场景用（可经按钮 toggle_insert_marker 切换）。
## Battle 正式集成必须设为 false：预览标记常态隐藏，仅当鼠标悬停【付费卡】时由 preview_cost_for 显示，
## 0 费卡与无悬停时不显示（见 preview_cost_for / clear_preview）。
@export var start_with_marker: bool = false

@export_group("Auto Advance")
## 自动推进空的高亮框（用于 Battle 等【无「执行」按钮】的集成场景）：当 cell0 为空（分隔线落入高亮框）时，
## 无视执行按钮自动播放「消费最左格」——分隔线原地淡出并循环复用回队尾、所有部件左移，直到 cell0 重新有 atb 部件。
## 关闭（默认）时，空的高亮框需手动点「执行」才能推进（带按钮的测试场景用）。
@export var auto_advance: bool = false

@export var auto_spawn_on_ready: bool = true
## 是否在 _ready 时自动填充名册（spawn_random / unit_roster）。
## Battle 集成场景必须设为 false——BattleRoot 会在自身 _ready 中主动调用 start_turn(nodes) 重建真实名册；
## 若此处先随机填充、又恰有敌人落入 cell0，会【提前】触发 auto_enemy_turn 协程，
## 而随后 start_turn 清场重建时发生「加载期竞态」，表现为敌人无故移动、玩家插图被无视。
## 独立 ATB 测试场景保持默认 true（自包含运行）。

@export_group("Enemy Turn")
## 敌方回合自动推进：当高亮框(第0格)内单位为敌方时，自动执行「执行结束」tick——
## 占位行动（enemy_action_started 信号，目前无实际行为）后按起始 cell 序号重新插队，并持续挨个推进下一个敌方，
## 直到框内变为玩家单位（玩家回合）或空框。关闭时敌方需手动「执行」按钮才能行动（测试场景用）。
@export var auto_enemy_turn: bool = false
## 敌方回合内每个敌方行动的间隔（秒），用于肉眼可见地「挨个」推进。
@export var enemy_step_delay: float = 0.6

@export_group("Layout / Screen")
## 是否自动把整组在屏幕上居中并贴顶边（Battle 集成设 true；测试场景保持默认关，避免位置变动影响探针）。
@export var auto_center: bool = false
## auto_center 时整组顶部对齐到的 y（像素，默认 20 = 离顶边 20px）。
@export var top_margin: float = 20.0
## 高亮框整体上下偏移（默认 -2 = 上移 2px；正数下移、负数上移）。
@export var frame_y_offset: float = -2.0

@onready var _parts_container: Node2D = $PartsContainer
@onready var _frame: TextureRect = $HighlightFrame

var _parts: Array[AtbPart] = []
var _lines: Array[Line2D] = []
var _art_files: Array[String] = []
var _busy: bool = false
## 敌方自动回合进行中标记（防止 _set_framed 在 tick 内部再次触发 _maybe_auto_enemy_turn 造成重入）。
var _enemy_turn_active: bool = false
## 当前布局 tween 引用：_relayout 开头先 kill 上一次未完成的，避免多次调用叠加多个 tween
## 同时写同一节点 position（导致抖动/重叠，即用户报告的「零件重叠」根因之一）。
var _relayout_tween: Tween = null

## 本次重排中需要「瞬移+淡入」而非 tween 的循环复用线段。
var _recycled: Line2D = null
## 当前占据高亮框（cell0 slot0）的部件，用于避免重复播确认动画。
var _framed: AtbPart = null
## 当前占据高亮框的部件【下次执行结束】将位移到的目标格（提前读取，供预览标记显示真实落点）。
var _framed_target_cell: int = -1

## 加载闸门：名册尚未建立完成前（_ready 的随机填充 / start_turn 的真实名册重建），
## 自动敌方回合驱动器一律不响应，杜绝「加载期竞态」提前触发敌人移动。
## 解锁点：① _ready 自启填充完成（auto_spawn_on_ready=true 的测试场景）；② start_turn 名册建立完成（Battle 集成）。
var _loading: bool = true

## 插入位置预览标记（调试用）：上下两个白色三角形（▲/▼）组成的占位组，
## 钉在「当前框内单位的下次执行结束将插入的目标格」的【队尾部件右缘 ↔ 右侧分割线】间隙中央，
## 只代表「一个 atb 部件将插入此处」（不预览分隔线本身）。三角上下浮动仅作视觉提示。
var _insert_marker: Node2D = null
var _tri_top: Polygon2D = null  ## 顶部三角 ▼：apex 朝下，指向中心（inward）
var _tri_bot: Polygon2D = null  ## 底部三角 ▲：apex 朝上，指向中心（inward）
var _float_tweens: Array[Tween] = []


func _ready() -> void:
	_scan_art_files()
	_build_lines()
	_build_frame()
	_build_marker()
	add_to_group("atb_track")   # 供 HandManager 经 get_first_node_in_group 取得引用（解耦路径）
	# Battle 集成：auto_spawn_on_ready=false 时跳过自启填充，名册由 BattleRoot._ready 的 start_turn 提供。
	# 避免 _ready 随机名册（可能含 cell0 敌人）提前触发 auto_enemy_turn 与 start_turn 发生加载竞态。
	if auto_spawn_on_ready:
		if not unit_roster.is_empty():
			_spawn_from_roster(unit_roster)
		else:
			spawn_random()
		_loading = false   # _ready 自启填充完成 → 解锁自动敌方回合（测试场景路径）
	if start_with_marker:
		toggle_insert_marker()
	if auto_center:
		_recenter()


## ---- 资源扫描 ----
func _scan_art_files() -> void:
	_art_files.clear()
	var dir := DirAccess.open(ATB_ART_DIR)
	if dir == null:
		push_error("AtbTrack: 无法打开目录 " + ATB_ART_DIR)
		return
	dir.list_dir_begin()
	var f := dir.get_next()
	while f != "":
		if not dir.current_is_dir() and f.get_extension().to_lower() == "png":
			_art_files.append(f.trim_prefix(ART_PREFIX).get_basename())
		f = dir.get_next()
	dir.list_dir_end()
	_art_files.sort()


## ---- 队列查询 ----
## 取某格的部件队列（按 slot_index 升序）。oc/os 提供 cell_index/slot_index 的临时覆盖（用于预览模拟）。
func _cell_parts(c: int, oc: Dictionary = {}, os: Dictionary = {}) -> Array[AtbPart]:
	var out: Array[AtbPart] = []
	for p in _parts:
		if not is_instance_valid(p):
			continue
		var ci := p.cell_index
		if oc.has(p):
			ci = oc[p]
		if ci == c:
			out.append(p)
	var f := func(a: AtbPart, b: AtbPart) -> bool:
		var sa := a.slot_index
		var sb := b.slot_index
		if os.has(a):
			sa = os[a]
		if os.has(b):
			sb = os[b]
		return sa < sb
	out.sort_custom(f)
	return out


func _part_width(p: AtbPart) -> float:
	var w := p.art_size().x
	return w if w > 0.0 else default_part_width


## ---- 布局计算 ----
## 返回 { "pos": {AtbPart: Vector2}, "line_xs": Array[float] }（line_xs[i] = cell i 右边界 x）。
## oc/os 提供 cell_index/slot_index 的临时覆盖（用于预览模拟，不影响真实 _parts）。
func _compute_layout(oc: Dictionary = {}, os: Dictionary = {}) -> Dictionary:
	var pos: Dictionary = {}
	var line_xs: Array[float] = []
	var x := origin.x
	for c in cell_count:
		var q := _cell_parts(c, oc, os)
		# 空格子宽度 = 线两侧间距之和（line_gap 各 4px），不再保留可插一个部件的余量。
		var w := line_gap * 2.0
		if not q.is_empty():
			var inner := 0.0
			for p in q:
				inner += _part_width(p)
			inner += part_gap * float(q.size() - 1)
			w = line_gap * 2.0 + inner
		var px := x + line_gap
		for p in q:
			var pw := _part_width(p)
			pos[p] = Vector2(px + pw * 0.5, origin.y)
			px += pw + part_gap
		x += w
		line_xs.append(x)
	return {"pos": pos, "line_xs": line_xs}


## 应用布局。skip 指定的部件不参与（由 detour 曲线单独驱动）。
func _relayout(animated: bool, skip: AtbPart = null) -> void:
	# 先 kill 上一次未完成的布局 tween，避免多次调用叠加多个 tween 同时写同一节点 position（导致抖动/重叠）。
	if _relayout_tween != null and _relayout_tween.is_valid():
		_relayout_tween.kill()
		_relayout_tween = null
	var layout := _compute_layout()
	var pos: Dictionary = layout["pos"]
	var line_xs: Array[float] = layout["line_xs"]
	var tw: Tween = null
	var moves := 0
	if animated:
		# 树绑定 tween：不会被同节点的其他 create_tween 调用 kill（见 execute_end 并行 detour 卡死 bug）
		tw = get_tree().create_tween().set_parallel(true)
		_relayout_tween = tw

	for p in _parts:
		if p == skip or not is_instance_valid(p) or not pos.has(p):
			continue
		var target: Vector2 = pos[p]
		if animated:
			tw.tween_property(p, "position", target, slide_time)
			moves += 1
		else:
			p.position = target

	for i in _lines.size():
		if i >= line_xs.size():
			continue
		var line := _lines[i]
		if line == null:
			continue
		var target_p := Vector2(line_xs[i], origin.y)
		if line == _recycled:
			# 循环复用的线：瞬移到队尾后淡入，绝不横穿轨道 tween
			line.position = target_p
			line.visible = true
			line.modulate.a = 0.0
			var tf := get_tree().create_tween()
			tf.tween_property(line, "modulate:a", 1.0, fade_time)
			_recycled = null
		elif animated:
			tw.tween_property(line, "position", target_p, slide_time)
			moves += 1
		else:
			line.position = target_p

	if tw != null and moves == 0:
		tw.kill()
		_relayout_tween = null

	# 预览标记跟随「当前框内单位的位移目标格」（detour/折叠期间也会刷新，保持「大致位置」可读）
	if _insert_marker != null and _insert_marker.visible:
		_insert_marker.position = get_insertion_point() + Vector2(0.0, marker_y_offset)


## ---- 构建分隔线与高亮框 ----
func _build_lines() -> void:
	for line in _lines:
		if line != null:
			line.queue_free()
	_lines.clear()
	_recycled = null
	for i in line_count:
		var line := Line2D.new()
		line.points = PackedVector2Array([
			Vector2(0.0, -line_length * 0.5),
			Vector2(0.0, line_length * 0.5)
		])
		line.width = line_thickness
		line.default_color = line_color
		line.z_index = -1
		add_child(line)
		_lines.append(line)


func _build_frame() -> void:
	var tex := load(HIGHLIGHT_FRAME) as Texture2D
	if tex != null:
		_frame.texture = tex
	_frame.expand_mode = TextureRect.EXPAND_KEEP_SIZE
	_frame.stretch_mode = TextureRect.STRETCH_KEEP
	_frame.size = Vector2(53.0, 148.0)
	# 框钉在 cell0 的 slot0 位置（用标准宽度算，不随格内容抖动）；frame_y_offset 整体上移/下移
	var center := Vector2(origin.x + line_gap + default_part_width * 0.5, origin.y + frame_y_offset)
	_frame.position = center - _frame.size * 0.5
	_frame.z_index = 10
	var shader := Shader.new()
	shader.code = FRAME_OUTLINE_SHADER
	var mat := ShaderMaterial.new()
	mat.shader = shader
	mat.set_shader_parameter("outline_color", COLOR_ENHANCED)
	mat.set_shader_parameter("outline_thickness", 2.0)
	_frame.material = mat
	_frame.visible = true
	# 高亮框是常驻装饰，忽略鼠标，避免它盖住其下部件插图、拦截 Area2D 悬停检测。
	_frame.mouse_filter = Control.MOUSE_FILTER_IGNORE


## ---- 生成随机部件 ----
func spawn_random() -> void:
	_clear_parts()
	_build_lines()
	_set_framed(null)
	var count := randi_range(random_min, random_max)
	for n in count:
		var cell := randi_range(0, cell_count - 1)
		var uid := _art_files[randi_range(0, _art_files.size() - 1)]
		_spawn_part(uid, cell)
	_relayout(false)
	_set_framed(_front_part())
	_auto_collapse_if_needed()


func _spawn_part(uid: String, cell: int, start_cell: int = 1) -> void:
	if part_scene == null:
		push_error("AtbTrack: part_scene 未设置")
		return
	var part := part_scene.instantiate() as AtbPart
	if part == null or not is_instance_valid(part):
		return
	part.cell_index = -1
	_parts_container.add_child(part)
	part.show_atb(uid)
	part.faction = AtbPart.Faction.ENEMY if part.is_enemy(uid) else AtbPart.Faction.ALLY
	if part.faction == AtbPart.Faction.ENEMY:
		part.random_intent()
	part.start_cell_index = start_cell
	_parts.append(part)
	_insert(part, cell)


func _clear_parts() -> void:
	for p in _parts:
		if is_instance_valid(p):
			p.queue_free()
	_parts.clear()


## 按指定名册生成部件（联动战斗单位）：每个 id 生成一个部件并随机分配到某格，
## 阵营由 AtbTrack 按 id 推断（敌方额外挂随机意图）。用于 Battle 场景把真实单位喂给 ATB。
func _spawn_from_roster(ids: Array[String]) -> void:
	_clear_parts()
	_build_lines()
	_set_framed(null)
	for uid in ids:
		if uid == "":
			continue
		_spawn_part(uid, randi_range(0, cell_count - 1))
	_relayout(false)
	_set_framed(_front_part())
	_auto_collapse_if_needed()


## 运行时设置/替换名册并重建部件（BattleRoot 在 _ready 收集 Units 的 unit_id 后调用）。
## 空数组回退 spawn_random。重建后刷新预览标记与居中。
func set_roster(ids: Array[String]) -> void:
	unit_roster = ids
	if ids.is_empty():
		spawn_random()
	else:
		_spawn_from_roster(ids)
	if _insert_marker != null and _insert_marker.visible:
		_refresh_marker()
	if auto_center:
		_recenter()


## 回合开始名册建立（Battle 集成用）：玩家阵营单位按场景 x【从右往左】排序、全部进入 cell0；
## 敌方单位均匀分布到 cell0 之后的其余格。落实两条规则：
##   ①「第0格固定玩家插图」——取代 set_roster 的随机分配；
##   ②「敌方阵营单位 ATB 绝不会在第0格」——cell0 固定保留给玩家插图，敌方起始格 clamp 到 [1, cell_count-1]。
## unit_nodes: Units 子节点的 UnitRoot 列表（需读取 unit_id / unit_faction / global_position.x）。
func start_turn(unit_nodes: Array) -> void:
	_clear_parts()
	_build_lines()
	_set_framed(null)
	var players: Array = []
	var enemies: Array = []
	for u in unit_nodes:
		if u is UnitRoot and (u as UnitRoot).unit_id != "":
			var ur := u as UnitRoot
			if ur.unit_faction == "player":
				players.append(ur)
			else:
				enemies.append(ur)
	# 玩家按场景 x 降序（从右往左）→ 依次进入 cell0，slot0 = 最右单位（炮炮/艾琳/周周）。
	players.sort_custom(func(a: UnitRoot, b: UnitRoot) -> bool:
		return a.global_position.x > b.global_position.x)
	for ur in players:
		_spawn_part(ur.unit_id, 0)
	# 敌方按各自起始 cell 序号(start_cell_index)落格；clamp 防御仍保留 cell0 不被占（仅约束开局布局）。
	for e in enemies.size():
		var ur := enemies[e] as UnitRoot
		var cell := clampi(ur.start_cell_index, 1, cell_count - 1)   # 防御：永不落入 cell0（仅约束开局布局）
		_spawn_part(ur.unit_id, cell, ur.start_cell_index)
	_relayout(false)
	_set_framed(_front_part())
	_auto_collapse_if_needed()
	_loading = false   # 真实名册建立完成 → 解锁自动敌方回合（Battle 集成路径）
	if auto_center:
		_recenter()   # 真实名册建好后按实际内容宽度重新居中（_ready 时部件为空，居中用空布局，须在此纠正）


## 按 unit_uid 查找部件（只读）。
func _find_part(uid: String) -> AtbPart:
	for p in _parts:
		if is_instance_valid(p) and p.unit_uid() == uid:
			return p
	return null


## 预览：悬停一张费用为 cost、归属单位 uid 的手牌时，把插入预览标记移到
## 「该单位插图当前所在格 + cost」格的插入位（即打这张牌后插图将落入的位置）。
## 仅在悬停付费卡时显示；0 费卡（即时施放、不插队）不显示预览。常态下（无悬停）标记隐藏。
func preview_cost_for(cost: int, uid: String) -> void:
	if _insert_marker == null:
		return
	# 0 费卡不插队 → 不显示预览标记
	if cost <= 0:
		_insert_marker.visible = false
		_stop_float()
		return
	var part := _find_part(uid)
	if part == null:
		return
	var target := clampi(part.cell_index + cost, 1, cell_count - 1)
	_insert_marker.visible = true
	_insert_marker.position = _marker_slot_for(part, target) + Vector2(0.0, marker_y_offset)
	_start_float()


## 清除费用预览：鼠标离开卡牌 → 隐藏插入预览标记（常态不显示）。
func clear_preview() -> void:
	if _insert_marker != null and _insert_marker.visible:
		_insert_marker.visible = false
		_stop_float()


## 真实插入：玩家单位打出 cost 费卡时，其插图从当前格向前插入 cost 格（落入「当前格 + cost」）。
## 内部复用 _detach + _insert（同格内按 _precedence 插队），随后重排并刷新预览。
## 注：当前手牌尚未接入「点击打出」，故本方法暂未被触发——仅落实费用→插入格规则，供后续卡牌打出时调用。
func advance_unit(uid: String, cost: int) -> void:
	var part := _find_part(uid)
	if part == null:
		return
	var target := clampi(part.cell_index + cost, 0, cell_count - 1)
	_detach(part)
	_insert(part, target)
	_relayout(true)
	_set_framed(_front_part())
	_refresh_marker()


## 让指定 uid 的敌方部件显示与 battle 单位【参数一致】的意图（同 type_id；图标取 atb 文件夹内 {type_id}.png，
## 即用户已提供的美术，不作改动）。由 BattleRoot 在收集名册后 / 收到 intent_changed 信号时调用。
## 仅作用于敌方部件，使 ATB 意图图标 = battle 意图图标的【参数对应】。
func apply_enemy_intent(uid: String, type_id: String, target_id: String, value: String) -> void:
	for p in _parts:
		if is_instance_valid(p) and p.unit_uid() == uid:
			p.set_intent(type_id, target_id, value)
			return


## 联动「聚光」协调器：单一真相来源。
## 由 BattleRoot._process 每帧权威命中测试后调用 set_spotlight(uid)（uid="" 表示无聚光 → 全部彩色）。
## 有聚光 uid 时，该 uid 部件保持彩色，其余部件压暗（灰度 + 形状黑叠）；无聚光时全部彩色。
## 采用「每帧权威命中」而非部件/单位各自的 mouse_entered/exited，是因为 Godot 在鼠标快速移动时会
## 漏发 mouse_exited 事件，导致离开的部件卡在「高亮/黑叠」态——每帧从头判定可彻底消除该残留。
var _spot_uid: String = ""


## 设定聚光 uid（空串视为清除全部压暗）。仅在 uid 变化时才刷新，避免每帧重启动画 tween。
func set_spotlight(uid: String) -> void:
	if uid == _spot_uid:
		return
	_spot_uid = uid
	_refresh_dimming()


## 根据聚光 uid 刷新所有部件压暗状态：仅「非聚光 uid」的部件被压暗。
func _refresh_dimming() -> void:
	for p in _parts:
		if is_instance_valid(p):
			p.set_dimmed(_spot_uid != "" and p.unit_uid() != _spot_uid)


## 暴露部件列表供 BattleRoot 做权威命中测试（只读）。
func get_parts() -> Array[AtbPart]:
	return _parts


## ---- 队列增删（插队规则） ----
## 从所在格摘出，同格后续部件 slot 前移补位。
func _detach(p: AtbPart) -> void:
	var q := _cell_parts(p.cell_index)
	q.erase(p)
	for i in q.size():
		q[i].slot_index = i
	p.cell_index = -1


## 插入目标格：按「同格内先后排序」插队（见 _precedence / _ordered_insert_index）。
## 排序规则：天气(WEATHER, 预留) > player(ALLY) > 敌方(ENEMY)；player 内部执行(EXECUTION) 优先于 即时(SWIFT)；
## 同优先级按既有顺序（sequence）排在其后。该规则与预览标记(_compute_marker_slot)共用，保证预览 = 真实落点。
## 只影响本格队列，其他格部件不动；其后部件 slot 顺次后移。
func _insert(p: AtbPart, cell: int) -> void:
	var q := _cell_parts(cell)
	q.erase(p)
	var idx := _ordered_insert_index(q, p)
	q.insert(idx, p)
	p.cell_index = cell
	for i in q.size():
		q[i].slot_index = i


## 同格内先后排序优先级（数值越小越靠前/越靠左）：
##   天气(WEATHER, 当前未提供部件) = 0（最高）
##   player(ALLY) = 10；其中 即时(SWIFT) = 12、执行(NONE/EXECUTION) = 10
##   敌方(ENEMY) = 20
##   其它 = 30
func _precedence(p: AtbPart) -> int:
	match p.faction:
		AtbPart.Faction.WEATHER:
			return 0
		AtbPart.Faction.ALLY:
			# NONE 与 EXECUTION 同优先级（保持既有行为），SWIFT 排在其后
			return 12 if p.card_type == AtbPart.CardType.SWIFT else 10
		AtbPart.Faction.ENEMY:
			return 20
		_:
			return 30


## 在格队列 q 中，部件 p 按 _precedence 应插入的槽位索引：
## 插到「第一个优先级严格低于 p 的部件」之前；若不存在则追加到队尾。
func _ordered_insert_index(q: Array[AtbPart], p: AtbPart) -> int:
	var pr := _precedence(p)
	for i in q.size():
		if _precedence(q[i]) > pr:
			return i
	return q.size()


## ---- 执行结束 tick ----
## 关键：detour 动画与「线段原地淡出」【并行】启动，而不是等 detour 落位后再淡线。
## 旧实现 await _animate_detour 之后才 _collapse_front，导致线段总在部件位移进框后才淡出。
## cost_override<0 = 常规 tick（目标用提前读取的 _framed_target_cell）；
## cost_override>=0 = 玩家打出有费用卡的插队式 tick（目标 = 「当前格 + cost」，= 悬停预览落点）。
func execute_end(cost_override: int = -1) -> void:
	if _busy or _parts.is_empty():
		return
	_busy = true
	for p in _parts:
		p.reset_tick_flag()

	var front := _front_part()
	var detour_tw: Tween = null
	if front != null:
		# 目标格：常规 tick 用提前读取的 _framed_target_cell（无效则随机）；
		# 插队式(cost_override>=0)用「当前格 + 费用」(= 悬停预览落点 clampi(cell+cost,1,cell_count-1))。
		var target := _framed_target_cell
		if cost_override >= 0:
			target = clampi(front.cell_index + cost_override, 1, cell_count - 1)
		elif front != _framed or target < 1 or target >= cell_count:
			target = randi_range(1, cell_count - 1)
		_detach(front)
		_insert(front, target)
		# 其余部件 + 所有线段按新布局滑动（front 不参与，避免与 detour tween 冲突）
		_relayout(true, front)
		# ⚠️ detour 动画【独立运行、自行结束】（tree tween 跑完自动 free），
		# 切勿 await 它的 finished —— 它在 collapse 等待期间就可能已结束并 free，
		# 届时 await 永久挂起、_busy 卡死（已用探针复现）。
		detour_tw = _animate_detour(front)

	# 立即消费 cell0：线段【原地】淡出（与 detour 并行），不等待部件位移进框
	await _collapse_front(front, detour_tw)

	# 重设框内单位并【重新读取】其下次位移目标格（预览标记随即跳到新落点）
	var q := _cell_parts(0)
	var prev := _framed
	if not q.is_empty():
		_set_framed(q[0])
		if q[0] != prev:
			q[0].play_confirm()
	else:
		_set_framed(null)
	_refresh_marker()
	# detour 动画已自行结束；collapse 也已结束，安全解锁 _busy。
	_busy = false


## 玩家打出「有费用」卡：高亮框(第0格)内单位（施法者）按其卡牌费用 cost 向前插入「当前格 + cost」格
## （= 悬停预览落点 clampi(cell+cost,1,cell_count-1)），结束其回合并推进 ATB 队列使下一单位进入高亮框。
## cost<=0 不生效（0 费卡=即时施放，不插队、不推进）。复用 execute_end 的 detour/折叠/重框逻辑，
## 仅把插入目标换成「当前格 + 费用」。由 HandManager.notify_used_on_unit 在有费用卡打出时调用。
func advance_framed(cost: int) -> void:
	if cost <= 0:
		return
	execute_end(cost)




## cell0 队首部件（高亮框内那个）。
func _front_part() -> AtbPart:
	var q := _cell_parts(0)
	return q[0] if not q.is_empty() else null


## detour：下沉 → 横移到目标格 → 上插入。落点取自最终布局，动画期 Y 可破对齐。
## 返回 Tween（调用方自行 await finished，实现与「线段原地淡出」并行）。
func _animate_detour(front: AtbPart) -> Tween:
	var layout := _compute_layout()
	var pos: Dictionary = layout["pos"]
	var dest: Vector2 = pos[front] if pos.has(front) else front.position
	var down := front.position + Vector2(0.0, detour_drop)
	var across := Vector2(dest.x, origin.y + detour_drop)
	var tw := get_tree().create_tween()
	tw.tween_property(front, "position", down, 0.15)
	tw.tween_property(front, "position", across, 0.25)
	tw.tween_property(front, "position", dest, 0.15)
	return tw


## cell0 为空则整体左移一格（含线段循环复用）；连续空格继续折叠，直到 cell0 有部件或全空。
## detour_tw：front 的 detour 动画。折叠开始时若它仍在跑必须 kill 掉，改由 relayout 把 front
## 与全员一起左移——否则 front 停在「折叠前」的目标格、cell_index 却被 -1，出现 8px(=line_gap*2)错位，
## 且下一次 advance 才被重新对齐（即用户报告的「插入间距不对、推进复位」）。
func _collapse_front(skip: AtbPart = null, detour_tw: Tween = null) -> void:
	var guard := 0
	while _cell_parts(0).is_empty() and not _parts.is_empty() and guard < cell_count:
		if detour_tw != null and detour_tw.is_valid():
			detour_tw.kill()
		await _consume_front_cell()
		_relayout(true)
		await get_tree().create_timer(slide_time).timeout
		guard += 1


## 消费最左格：淡出 line0 → 把它循环复用到队尾 → 所有部件左移一格。
func _consume_front_cell() -> void:
	if not _lines.is_empty():
		var line := _lines[0]
		if line != null:
			var tw := get_tree().create_tween()
			tw.tween_property(line, "modulate:a", 0.0, fade_time)
			# 用必定触发的 timer 代替 await tw.finished（规避 4.6.2「tween 提前 free 后 finished 不再发、协程永久挂起」的坑）
			await get_tree().create_timer(fade_time).timeout
			# 防御：await 期间若场景重置(spawn_random→_build_lines)已把此线 queue_free，
			# 此处再赋 visible 会报「previously freed」，故先校验有效性。
			if is_instance_valid(line):
				line.visible = false
			_lines.remove_at(0)
			# 防御：若本协程在 await 期间场景被拆除（--quit-after 等），line 可能已释放，
			# 直接 append 会触发「push_back invalid previously freed」。先校验有效性。
			if is_instance_valid(line):
				_lines.append(line)
				_recycled = line
	for p in _parts:
		p.cell_index -= 1


## 自动推进空的高亮框（auto_advance 开启时）：cell0 为空 → 分隔线落入框内，
## 自动消费最左格（淡出 line0 并循环复用回队尾、部件左移），直到 cell0 有 atb 部件。
## 与 execute_end 的区别：不移动框内单位、不播 detour，仅处理「空格」情况，故无需执行按钮。
## fire-and-forget（不 await）：由 _spawn_from_roster / spawn_random 在生成后调用，_busy 守卫防重入。
func _auto_collapse_if_needed() -> void:
	if not auto_advance or _busy or _parts.is_empty():
		return
	if not _cell_parts(0).is_empty():
		return
	_busy = true
	await _collapse_front(null, null)
	var q := _cell_parts(0)
	if not q.is_empty():
		_set_framed(q[0])
	else:
		_set_framed(null)
	_refresh_marker()
	_busy = false


## 敌方回合自动推进驱动器（由 _set_framed 在框内变为敌方时触发）。
## 持续处理连续敌方：依次 emit enemy_action_started（占位行动，目前无实际行为）→ execute_end（按起始 cell 重排队），
## 间隔 enemy_step_delay 让行动肉眼可见；直到框内变为玩家单位或空框即停（玩家回合/等待）。
## 用 _enemy_turn_active 防止 execute_end 内部 _set_framed 再次进入本函数造成重入。
## 注：headless 下 create_timer 不触发，故自动推进在 headless 校验中不会实际运行，仅验证代码可加载/解析。
func _maybe_auto_enemy_turn() -> void:
	if _loading:
		return
	if not auto_enemy_turn or _enemy_turn_active or _busy:
		return
	if _framed == null or _framed.faction != AtbPart.Faction.ENEMY:
		return
	_enemy_turn_active = true
	var guard := 0
	while guard < 64:
		guard += 1
		var cur := _framed
		if cur == null or not is_instance_valid(cur) or cur.faction != AtbPart.Faction.ENEMY:
			break
		enemy_action_started.emit(cur.unit_uid())
		await execute_end()
		await get_tree().create_timer(enemy_step_delay).timeout
	_enemy_turn_active = false


## 调试：切换所有敌方意图（含黑幕）显隐。
func toggle_all_intents() -> void:
	for p in _parts:
		if p.faction == AtbPart.Faction.ENEMY:
			if p.has_intent():
				p.clear_intent()
			else:
				p.random_intent()


## ---- 插入位置预览标记 ----
## 上下两个白色三角形（▲/▼）：均【指向中心】（夹住插入点，非朝外）；同 X，初始 Y 相差 marker_gap(默认150px)；
## 锚定在「当前框内单位的下次执行结束将插入的目标格」的【队尾部件右缘 ↔ 右侧分割线】间隙中央，
## 即一个 atb 部件即将插入的位置（不预览分隔线本身）。两三角上下同步浮动。
func _build_marker() -> void:
	_insert_marker = Node2D.new()
	_insert_marker.name = "InsertMarker"
	_insert_marker.z_index = 20
	_insert_marker.visible = false
	add_child(_insert_marker)

	var half := marker_gap * 0.5
	# 顶部三角 ▼：apex 朝下，指向中心（inward），约 10px
	_tri_top = Polygon2D.new()
	_tri_top.color = Color.WHITE
	_tri_top.polygon = PackedVector2Array([Vector2(0.0, 5.0), Vector2(-5.0, -5.0), Vector2(5.0, -5.0)])
	_tri_top.position = Vector2(0.0, -half)
	_tri_top.add_child(_make_outline(_tri_top.polygon))
	_insert_marker.add_child(_tri_top)

	# 底部三角 ▲：apex 朝上，指向中心（inward），约 10px
	_tri_bot = Polygon2D.new()
	_tri_bot.color = Color.WHITE
	_tri_bot.polygon = PackedVector2Array([Vector2(0.0, -5.0), Vector2(-5.0, 5.0), Vector2(5.0, 5.0)])
	_tri_bot.position = Vector2(0.0, half)
	_tri_bot.add_child(_make_outline(_tri_bot.polygon))
	_insert_marker.add_child(_tri_bot)


## 沿三角轮廓生成主题色（COLOR_ENHANCED）2px 描边（闭合 Line2D），作为三角子节点随浮动动画一起移动。
func _make_outline(poly: PackedVector2Array) -> Line2D:
	var line := Line2D.new()
	line.points = poly
	line.closed = true
	line.width = 2.0
	line.default_color = COLOR_ENHANCED
	line.z_index = 1
	return line


## 插入位置预览锚点：返回「当前框内单位下次执行结束将插入的目标格」中、
## 【队尾部件右缘 ↔ 该格右侧分割线】间隙的中心点。即占位条应站立的精确插入位。
## 此位置与 execute_end 实际插入位置一致（同 _framed_target_cell、同插队规则）。
func get_insertion_point() -> Vector2:
	return _compute_marker_slot()


## 参数化预览落点：给定目标格 target 与要插入的部件 part，返回「part 应插入 target 格的位置」。
## 规则与 execute_end 实际插入一致（同 _ordered_insert_index）。仅用于预览，不改 _parts。
func _marker_slot_for(part: AtbPart, target: int) -> Vector2:
	if target < 1 or target >= cell_count:
		# 无有效目标 → 兜底 cell1 内容中心
		var fallback := _compute_layout()
		var lx: Array[float] = fallback["line_xs"]
		var left1 := lx[0] if lx.size() > 0 else origin.x
		return Vector2(left1 + line_gap + default_part_width * 0.5, origin.y)
	var layout := _compute_layout()
	var pos: Dictionary = layout["pos"]
	var line_xs: Array[float] = layout["line_xs"]
	var q := _cell_parts(target)
	if q.is_empty():
		# 目标格为空 → 锚定在「该格左侧分割线」(target-1 与 target 之间)
		var left_line: float = line_xs[target - 1] if target - 1 >= 0 and target - 1 < line_xs.size() else origin.x
		return Vector2(left_line, origin.y)
	# 非空格：按同格先后排序算出 part 应插槽位
	var idx := _ordered_insert_index(q, part) if part != null else q.size()
	if idx <= 0:
		var left_line: float = line_xs[target - 1] if target - 1 >= 0 and target - 1 < line_xs.size() else origin.x
		var first_left: float = float(pos[q[0]].x if pos.has(q[0]) else q[0].position.x) - _part_width(q[0]) * 0.5
		return Vector2((left_line + first_left) * 0.5, origin.y)
	if idx >= q.size():
		var last_p: AtbPart = q[q.size() - 1]
		var tail_right: float = float(pos[last_p].x if pos.has(last_p) else last_p.position.x) + _part_width(last_p) * 0.5
		var right_line: float = line_xs[target] if target < line_xs.size() else tail_right
		return Vector2((tail_right + right_line) * 0.5, origin.y)
	var prev_right: float = float(pos[q[idx - 1]].x if pos.has(q[idx - 1]) else q[idx - 1].position.x) + _part_width(q[idx - 1]) * 0.5
	var cur_left: float = float(pos[q[idx]].x if pos.has(q[idx]) else q[idx].position.x) - _part_width(q[idx]) * 0.5
	return Vector2((prev_right + cur_left) * 0.5, origin.y)


## 框内单位默认预览落点（execute_end 实际插入位）：_framed 部件、_framed_target_cell 目标格。
func _compute_marker_slot() -> Vector2:
	return _marker_slot_for(_front_part(), _framed_target_cell)


## 设置当前占据高亮框的部件，并【提前读取】其下次执行结束将位移到的目标格（供预览标记显示真实落点）。
## 变化后发出 framed_changed(uid, is_player)，供 HandManager 动态扩/缩对应角色手牌组间距。
func _set_framed(p: AtbPart) -> void:
	_framed = p
	if p != null:
		if p.faction == AtbPart.Faction.ENEMY:
			# 敌方「行动结束」后重新插队的落点 = 其起始 cell 序号（由 UnitRoot.start_cell_index 提供）。
			_framed_target_cell = clampi(p.start_cell_index, 1, cell_count - 1)
		else:
			_framed_target_cell = randi_range(1, cell_count - 1)
	else:
		_framed_target_cell = -1
	var is_pl := p != null and p.faction == AtbPart.Faction.ALLY
	framed_changed.emit(p.unit_uid() if p != null else "", is_pl)
	# 敌方回合自动推进（无角色回合时持续挨个推进 atb；占位行动后按起始 cell 重排队）。
	if p != null and p.faction == AtbPart.Faction.ENEMY:
		_maybe_auto_enemy_turn()


## 预览标记位置刷新（跟随最新目标格 + 上下偏移）。
func _refresh_marker() -> void:
	if _insert_marker != null and _insert_marker.visible:
		_insert_marker.position = get_insertion_point() + Vector2(0.0, marker_y_offset)


## 调试：切换插入位置预览（上下三角占位组）的显隐，并启停浮动动画。
func toggle_insert_marker() -> void:
	if _insert_marker == null:
		return
	_insert_marker.visible = not _insert_marker.visible
	if _insert_marker.visible:
		_insert_marker.position = get_insertion_point() + Vector2(0.0, marker_y_offset)
		_start_float()
	else:
		_stop_float()


## 两三角各跑一条无限循环 tween：本地 Y 在 ±half(间距=marker_gap) 与 ±(half-amp)(间距<marker_gap) 间正弦往返，
## 同时创建故同步 —— 即「同时往中心收拢 / 同时扩散」。
func _start_float() -> void:
	_stop_float()
	var half := marker_gap * 0.5
	var t_top := get_tree().create_tween().set_loops(-1)
	t_top.tween_property(_tri_top, "position:y", -half + marker_float_amp, marker_float_time).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	t_top.tween_property(_tri_top, "position:y", -half, marker_float_time).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	var t_bot := get_tree().create_tween().set_loops(-1)
	t_bot.tween_property(_tri_bot, "position:y", half - marker_float_amp, marker_float_time).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	t_bot.tween_property(_tri_bot, "position:y", half, marker_float_time).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	_float_tweens = [t_top, t_bot]


func _stop_float() -> void:
	for t in _float_tweens:
		if t != null and t.is_valid():
			t.kill()
	_float_tweens.clear()


## 整组内容在【局部空间】的边界与中心（供最近居中 _recenter 与椭圆衬底 _build_glow 共用，
## 保证椭圆与整组严格居中一致）：左边界 = cell0 左缘(origin.x)，右边界 = 最右分割线(line_xs[cell_count-1])，
## 垂直中心 = origin.y。
func _content_bounds() -> Dictionary:
	var layout := _compute_layout()
	var line_xs: Array[float] = layout["line_xs"]
	var left: float = origin.x
	var right: float = line_xs[cell_count - 1] if line_xs.size() >= cell_count else origin.x
	return {
		"left": left,
		"right": right,
		"center_x": (left + right) * 0.5,
		"center_y": origin.y
	}

## auto_center：把整组在屏幕上水平居中、并把整组顶部（含高亮框与预览三角的最高点）对齐到 top_margin。
## 通过移动本节点自身 position 实现（不动内部 origin 局部布局），故对 relayout / 预览计算透明。
func _recenter() -> void:
	var b := _content_bounds()
	var content_w: float = max(b.right - b.left, 1.0)
	var vp: Vector2 = get_viewport().size
	var cx: float = b.center_x
	# 整组最高点：高亮框顶 与 预览三角顶 取较小者（预览三角可浮动到更高处）
	var frame_top_local := (origin.y + frame_y_offset) - (_frame.size.y * 0.5)
	var marker_ext := marker_gap * 0.5 + marker_float_amp
	var marker_top_local := (origin.y + marker_y_offset) - marker_ext
	var group_top_local: float = min(frame_top_local, marker_top_local)
	position.x = vp.x * 0.5 - cx
	position.y = top_margin - group_top_local


## 调试：在指定格追加一个随机单位（验证同格多部件与插队位移）。
func add_part_at(cell: int) -> void:
	if _art_files.is_empty():
		return
	var uid := _art_files[randi_range(0, _art_files.size() - 1)]
	_spawn_part(uid, clampi(cell, 0, cell_count - 1))
	_relayout(true)
	_set_framed(_front_part())
	_refresh_marker()

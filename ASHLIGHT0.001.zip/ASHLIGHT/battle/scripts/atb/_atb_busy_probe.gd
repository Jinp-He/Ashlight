extends SceneTree

## 仅开发验证：顺序连点「执行结束」，每次等 _busy 释放再点下一次，单次>3s 未释放即判卡死。
## 跑法：Godot_console.exe --headless --path . --script battle/scripts/atb/_atb_busy_probe.gd

var _track: AtbTrack = null
var _tick_idx: int = 0
var _busy_since: int = -1
var _report: Array[String] = []


func _initialize() -> void:
	var scene := load("res://battle/scripts/atb/atb_track.tscn")
	_track = scene.instantiate() as AtbTrack
	root.add_child(_track)


func _process(_delta: float) -> bool:
	var now := Time.get_ticks_msec()
	if not _track._busy:
		if _tick_idx >= 10:
			for s in _report:
				print(s)
			return true
		# 上一次 tick 在 3s 内完成则继续，否则已在下方判卡死
		_track.execute_end()
		_busy_since = now
		_tick_idx += 1
		_report.append("TICK %d 开始" % (_tick_idx - 1))
	else:
		if _busy_since >= 0 and now - _busy_since > 3000:
			_report.append(">>> 卡死复现于第 %d 次 tick！_busy 已持续 %dms 未释放" % [
				_tick_idx - 1, now - _busy_since])
			for s in _report:
				print(s)
			return true
		if now - _busy_since > 0 and (now - _busy_since) % 750 < 16:
			_report.append("TICK %d 仍忙 t=%dms 部件=%d 线=%d" % [
				_tick_idx - 1, now - _busy_since, _track._parts.size(), _track._lines.size()])
	return false

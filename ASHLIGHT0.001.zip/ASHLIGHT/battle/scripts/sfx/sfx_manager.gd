## 全局音效服务（Autoload，服务定位器）。
## 仅负责音效播放，不持有任何玩法逻辑：抽牌随机音 + 鼠标点击音。
## 注册于 project.godot [autoload] 段，名称 SfxManager。
extends Node

## 4 种抽牌音（zapsplat 发牌声），随机取一播放。
const DRAW_STREAMS: Array[AudioStream] = [
	preload("res://assets/audio/sfx/draw_001.mp3"),
	preload("res://assets/audio/sfx/draw_002.mp3"),
	preload("res://assets/audio/sfx/draw_003.mp3"),
	preload("res://assets/audio/sfx/draw_004.mp3"),
]
## 鼠标点击音。
const CLICK_STREAM: AudioStream = preload("res://assets/audio/sfx/ui_click.mp3")

var _click_player: AudioStreamPlayer

func _ready() -> void:
	_click_player = AudioStreamPlayer.new()
	add_child(_click_player)


## 抽牌音：每次调用独立生成一个 AudioStreamPlayer 播放随机一种，播完自动回收。
## 因此可多重叠加——同一时刻多张抽牌音同时响，不会被前一张截断（修正之前 4 池轮询互切的问题）。
func play_random_draw() -> void:
	if DRAW_STREAMS.is_empty():
		return
	var player := AudioStreamPlayer.new()
	add_child(player)
	player.stream = DRAW_STREAMS[randi() % DRAW_STREAMS.size()]
	player.finished.connect(player.queue_free)
	player.play()


## 鼠标点击音。
func play_click() -> void:
	if is_instance_valid(_click_player):
		_click_player.stream = CLICK_STREAM
		_click_player.play()


## 全局左键按下即播点击音——覆盖按钮、卡牌选靶、单位点选等一切鼠标点击动作。
func _input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.pressed and mb.button_index == MOUSE_BUTTON_LEFT:
			play_click()

class_name CutscenePreview
extends Node2D

## 演出预览独立场景：点击按钮播放一次 CutsceneController + CutsceneInsert。
## 美术来源随机（res://assets/units/...），用于调整编排器位置/速度等参数时快速目测。
## 不作为正式战斗逻辑；正式接入仍在 battle/Battle.tscn 的 HandManager 路径。

@onready var _controller: CutsceneController = $Stage/CutsceneController
@onready var _button: Button = $PlayButton

## 可用单位池：{"id":String, "faction":String}
var _unit_pool: Array[Dictionary] = []

func _ready() -> void:
	_build_unit_pool()
	_button.pressed.connect(_on_play_pressed)

## 扫描 res://assets/units/{player,enemy}/{id}/ 收集所有可用单位 id。
func _build_unit_pool() -> void:
	_unit_pool.clear()
	for faction in ["player", "enemy"]:
		var dir := DirAccess.open("res://assets/units/%s" % faction)
		if dir == null:
			continue
		dir.list_dir_begin()
		var sub: String = dir.get_next()
		while sub != "":
			if dir.current_is_dir() and not sub.begins_with("."):
				_unit_pool.append({"id": sub, "faction": faction})
			sub = dir.get_next()
		dir.list_dir_end()

## 随机取一个单位的 id/faction 副本（避免改到池内引用）。
func _random_unit() -> Dictionary:
	if _unit_pool.is_empty():
		return {}
	var u: Dictionary = _unit_pool[randi() % _unit_pool.size()]
	return {"id": u["id"], "faction": u["faction"]}

## 点击按钮：随机选美术（施法者/受击者/方向/美术态）播放一次演出。
func _on_play_pressed() -> void:
	var caster: Dictionary = _random_unit()
	caster["state"] = randi() % 5   # 0 Idle / 1 Attack / 2 Cast / 3 Hit / 4 Charge（缺态自动回退 Idle）
	var target: Dictionary = _random_unit()
	if target == caster or randf() < 0.25:
		target = {}   # 自施法或单块场景：仅施法者居中
	else:
		target["state"] = randi() % 5
	var direction: String = "player" if randf() < 0.5 else "enemy"
	_controller.play(caster, target, direction, 3)

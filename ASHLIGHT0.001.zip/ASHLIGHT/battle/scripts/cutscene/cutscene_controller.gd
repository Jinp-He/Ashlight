class_name CutsceneController
extends Node2D

## 战斗「打入/施法」演出编排器（Phase 1：玩家出牌）。
## 读取施法者(主目标)与受击者(次目标)的单位美术，生成 A/B 单位图沿参考实现 generate_cutscene.py 的轨迹滑入：
##   我方：左外滑入→向右→右外出；敌方：右外滑入→向左→左外出（单位 A 恒在左、B 恒在右，仅方向翻转）。
##   经过中央慢速区[675,925]减速（对位定格感），抵达中央时触发 CutsceneInsert 14帧特效 + 屏幕震动。
## 美术仅取单位态贴图（res://assets/units/{faction}/{id}/{id}_{State}.png），不含血条/buff/意图等部件。
## 美术态按卡牌类型(施法者)或敌方意图类型(Phase 2)选取；怪物缺 Charge 态回退 Idle。
## 单位图保持原尺寸显示、底部对齐（脚线贴 unit_baseline）。
## 依赖：CutsceneInsert（group "cutscene_insert"，层级须低于本节点）播放帧特效；BattleRoot 父节点用于屏幕震动偏移。

signal finished

# --- 运动参数（与 generate_cutscene.py / BattleCutscene_Preview 对齐）---
@export var spawn_delay: float = 0.2
@export var slide_speed: float = 4000.0
@export var slow_width: float = 250.0
@export var slow_factor: float = 0.15
@export var max_duration: float = 1.5
@export var unit_baseline: float = 360.0   # 单位图底部基线 y（底部对齐：脚线落此）
@export var unit_scale: float = 1.0        # 单位图缩放（保持原尺寸 = 1.0）
# 六单位偶数间隔插槽：屏幕宽 1600 ÷ 6，居中两槽 = 666.7 / 933.3（中点 800）。
@export var slot_count: int = 6
@export var design_width: float = 1600.0

# --- 屏幕震动参数（由特效触发后延迟起手）---
@export var shake_amp: float = 3.0
@export var shake_delay: float = 0.3
@export var shake_duration: float = 0.25

const W: float = 1600.0

var _unit_sprites: Array[Sprite2D] = []
var _slot_x: Array[float] = []             # 各单位静息对齐的 x
var _unit_half_heights: Array[float] = []  # 各单位图半高（含缩放），用于底部对齐
var _elapsed: float = 0.0
var _active: bool = false
var _effect_triggered: bool = false
var _shake_at: float = -1.0
var _direction: String = "player"
var _battle_root: Node2D

func _ready() -> void:
	add_to_group("cutscene_controller")
	_battle_root = get_parent() as Node2D

## 启动一次演出。caster/target 为字典 {"id":String,"faction":String,"state":int(UnitArtState)}；
## target 为空字典表示自施法（仅 caster 单块居中）。direction ∈ {"player","enemy"}。
func play(caster: Dictionary, target: Dictionary, direction: String, cost: int) -> void:
	_clear_units()
	_direction = direction
	_elapsed = 0.0
	_effect_triggered = false
	_shake_at = -1.0
	# A=施法者(左)，B=次目标(右)；仅施法者时单块居中。
	var entries: Array[Dictionary] = []
	if not caster.is_empty() and caster.get("id", "") != "":
		entries.append({"id": caster.get("id", ""), "faction": caster.get("faction", "player"), "state": int(caster.get("state", 0))})
	if not target.is_empty() and target.get("id", "") != "":
		entries.append({"id": target.get("id", ""), "faction": target.get("faction", "enemy"), "state": int(target.get("state", 0))})
	if entries.is_empty():
		return
	# 对齐位置：N 个单位置于居中 N 槽（保留传入左-右顺序）。
	var slot_spacing: float = design_width / float(slot_count)
	var center_idx: float = float(entries.size() - 1) * 0.5
	_slot_x.clear()
	_unit_half_heights.clear()
	for i in entries.size():
		var slot: int = int(center_idx - float(entries.size() - 1) * 0.5 + i)
		var x: float = slot_spacing * (float(slot) + 0.5)
		_slot_x.append(x)
		var spr := Sprite2D.new()
		spr.centered = true
		spr.texture = _load_unit_texture(entries[i]["id"], entries[i]["faction"], int(entries[i]["state"]))
		spr.scale = Vector2.ONE * unit_scale
		var h: float = spr.texture.get_height() if spr.texture != null else 0.0
		_unit_half_heights.append(h * unit_scale * 0.5)
		spr.visible = false
		spr.z_index = 1
		add_child(spr)
		_unit_sprites.append(spr)
	_active = true

func _clear_units() -> void:
	for b in _unit_sprites:
		if is_instance_valid(b):
			b.queue_free()
	_unit_sprites.clear()
	_slot_x.clear()
	_unit_half_heights.clear()

func _load_unit_texture(id: String, faction: String, state: int) -> Texture2D:
	if id == "":
		return null
	var base := "res://assets/units/%s/%s/%s_" % [faction, id, id]
	var tex := load(base + _state_suffix(state) + ".png") as Texture2D
	if tex == null and state != 0:
		tex = load(base + "Idle.png") as Texture2D   # 缺态回退 Idle（怪物无 Charge 时即落此）
	if tex == null:
		push_warning("CutsceneController: 单位美术缺失 %s/%s state=%d" % [faction, id, state])
	return tex

func _state_suffix(state: int) -> String:
	match state:
		0: return "Idle"
		1: return "Attack"
		2: return "Cast"
		3: return "Hit"
		4: return "Charge"
	return "Idle"

## 返回 A-B 单位对中心的 x；调用方须确保 t>=spawn_delay。
## 节奏（用户 2026-09-09 调整）：快速进场(ease-out 减速入慢速区) ➡️ 慢速区匀速定格(缓动核心) ➡️ 快速离场(ease-in 加速出慢速区)。
## 即进场/离场为平滑缓动而非硬切速度，中央仍为 15% 慢速对位停顿。d=+1 我方从左、d=-1 敌方从右，坐标直接插值无需乘方向。
func _pair_center_x(t: float) -> float:
	var x_time: float = t - spawn_delay
	var slow_start: float = (W - slow_width) * 0.5
	var slow_end: float = (W + slow_width) * 0.5
	var d: int = 1 if _direction == "player" else -1
	var slot_spacing: float = design_width / float(slot_count)
	var speed: float = slide_speed
	var slow_speed: float = speed * slow_factor
	var start_x: float = -slot_spacing if d == 1 else W + slot_spacing
	var end_x: float = W + slot_spacing if d == 1 else -slot_spacing
	var slow_entry: float = slow_start if d == 1 else slow_end
	var slow_exit: float = slow_end if d == 1 else slow_start
	var entry_dur: float = abs(slow_entry - start_x) / speed
	var slow_dur: float = abs(slow_exit - slow_entry) / slow_speed
	var exit_dur: float = abs(end_x - slow_exit) / speed
	if x_time < entry_dur:
		# 进场：ease-out —— 起初最快(快速进场)、临近慢速区平滑减速(缓动)。
		var p: float = clampf(x_time / entry_dur, 0.0, 1.0)
		var e: float = 1.0 - (1.0 - p) * (1.0 - p)
		return lerpf(start_x, slow_entry, e)
	x_time -= entry_dur
	if x_time < slow_dur:
		# 慢速区：匀速定格（对位打击停顿感的核心）。
		var p: float = clampf(x_time / slow_dur, 0.0, 1.0)
		return lerpf(slow_entry, slow_exit, p)
	x_time -= slow_dur
	# 离场：ease-in —— 缓动起步、临近屏外加速到全速(快速离场)。
	var p: float = clampf(x_time / exit_dur, 0.0, 1.0)
	var e: float = p * p
	return lerpf(slow_exit, end_x, e)

func _process(delta: float) -> void:
	if not _active:
		return
	_elapsed += delta
	if _elapsed < spawn_delay:
		for b in _unit_sprites:
			if is_instance_valid(b):
				b.visible = false
		return
	var cx: float = _pair_center_x(_elapsed)
	var off: float = cx - (design_width * 0.5)
	for i in _unit_sprites.size():
		var b := _unit_sprites[i] as Sprite2D
		if not is_instance_valid(b):
			continue
		b.visible = true
		# 底部对齐：脚线（sprite 底边）贴 unit_baseline，整图向上生长。
		b.position = Vector2(_slot_x[i] + off, unit_baseline - _unit_half_heights[i])
	# 进入慢速区 → 触发特效（仅一次）
	if not _effect_triggered:
		var slow_start: float = (W - slow_width) * 0.5
		var slow_end: float = (W + slow_width) * 0.5
		var in_zone: bool = (_direction == "player" and cx >= slow_start) or (_direction == "enemy" and cx <= slow_end)
		if in_zone:
			_effect_triggered = true
			_trigger_effect()
			_shake_at = _elapsed + shake_delay
	_update_shake()
	if _elapsed >= max_duration:
		_finish()

func _trigger_effect() -> void:
	var cs := get_tree().get_first_node_in_group("cutscene_insert") as CutsceneInsert
	if is_instance_valid(cs):
		cs.play(_direction)

func _update_shake() -> void:
	if _shake_at < 0.0 or _battle_root == null:
		return
	if _elapsed < _shake_at:
		return
	var st: float = _elapsed - _shake_at
	if st >= shake_duration:
		_battle_root.position = Vector2.ZERO
		_shake_at = -1.0
		return
	var f: float = 1.0 - st / shake_duration
	var ang: float = randf() * TAU
	_battle_root.position = Vector2(cos(ang), sin(ang)) * shake_amp * f

func _finish() -> void:
	_active = false
	_clear_units()
	if is_instance_valid(_battle_root):
		_battle_root.position = Vector2.ZERO
	_shake_at = -1.0
	finished.emit()

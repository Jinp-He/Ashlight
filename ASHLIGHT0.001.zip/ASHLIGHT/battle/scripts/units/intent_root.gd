class_name IntentRoot
extends Node2D

## 单位意图组组件：读取怪物行动逻辑后的视觉效果。
## 由三组构成，均以 IntentRoot 局部原点为中心对齐：
##   ① 底图(Base)             —— 单张意图底板 intent_base.png
##   ② 意图类型组(TypeGroup)  —— 全部类型图标 type_{id}.png，统一着色为 COLOR_INTENT；活动图标居中于底图，数值文字(NxM)位于其下方并上移40px（与图标同色9c660a、同样居中于底图）
##   ③ 意图目标组(TargetGroup)—— 点(单体/target_monomer) + 线(范围/target_aoe) 并排组合成「点线」或「线点」，
##                                  二者 Y 轴居中对齐（点/线同高）；默认额外上移 37px（见 target_offset）。
##                                  排序与激活色由 TARGET_ORDER / TARGET_ACTIVE 决定（取决于 前/后排 × 单体/范围）；
##                                  think 状态下点线均无明确目标，二者皆取灰色未激活(COLOR_INACTIVE)。
## 显示逻辑：仅当单位阵营为敌人(enemy)且已设置意图时显示，否则隐藏（见 set_faction / _apply_visibility）。

const INTENT_DIR: String = "res://assets/Unit UI/intent/"
## 数值文字字体（Biantao 边桃体，已导入）。
const FONT_PATH: String = "res://assets/fonts/Biantao.ttf"

## 底图文件名（单张意图底板）。
const BASE_FILE: String = "intent_base.png"
## 类型图标 id 列表（与美术 type_{id}.png 对应）。供随机组合按钮直接引用。
const TYPE_IDS: Array[String] = ["att", "shield", "state", "think"]
## 意图目标组合 id 列表（前/后排 × 单体/范围，共 4 种）。供 API 与随机按钮引用。
## 美术资产固定：monomer=点(target_monomer.png)、aoe=线(target_aoe.png)。
const TARGET_IDS: Array[String] = ["front_monomer", "front_aoe", "back_monomer", "back_aoe"]

## 各目标组合的「点线/线点」并排顺序（"monomer"=点在前 / "aoe"=线在前）。
##   front_monomer → 线点（线在前）  front_aoe → 点线（点在前）
##   back_monomer  → 点线（点在前）  back_aoe  → 线点（线在前）
const TARGET_ORDER: Dictionary = {
	"front_monomer": ["aoe", "monomer"],
	"front_aoe":     ["monomer", "aoe"],
	"back_monomer":  ["monomer", "aoe"],
	"back_aoe":      ["aoe", "monomer"],
}
## 各目标组合的激活元素（取 COLOR_INTENT；另一元素取 COLOR_INACTIVE）。
##   单体(monomer)攻击 → 点激活；范围(aoe)攻击 → 线激活（前/后排一致）。
const TARGET_ACTIVE: Dictionary = {
	"front_monomer": "monomer",
	"front_aoe":     "aoe",
	"back_monomer":  "monomer",
	"back_aoe":      "aoe",
}

## 意图类型图标 / 目标激活元素统一色（9c660a = 0.61176, 0.4, 0.03922）。
const COLOR_INTENT: Color = Color(0.61176, 0.4, 0.03922)
## 目标非激活元素色（3f4447 = 0.24706, 0.26667, 0.27843）。
const COLOR_INACTIVE: Color = Color(0.24706, 0.26667, 0.27843)

## 三组定位偏移：均以 IntentRoot 局部原点为中心对齐。
@export var base_offset: Vector2 = Vector2.ZERO :
	set(v):
		base_offset = v
		_rebuild_layout()
@export var type_offset: Vector2 = Vector2.ZERO :
	set(v):
		type_offset = v
		_rebuild_layout()
## 意图目标组默认上移 37px（中心对齐后再上移：初版 15px → +17px → +3px → +2px）。
@export var target_offset: Vector2 = Vector2(0.0, -37.0) :
	set(v):
		target_offset = v
		_rebuild_layout()
## 整个意图组（底图+类型组+目标组）相对 IntentRoot 锚点的整体位移。
## 默认上移 120px（相对 UnitRoot 给出的 intent_offset_y 锚点）。
@export var group_offset: Vector2 = Vector2(0.0, -120.0) :
	set(v):
		group_offset = v
		_rebuild_layout()
## 数值文字（格式 NxM，N=次数/M=伤害）字号与描边。颜色固定 COLOR_INTENT（与类型图标一致）。
@export var value_font_size: int = 24 :
	set(v):
		value_font_size = v
		_refresh_value_font()
@export var value_outline_size: int = 4 :
	set(v):
		value_outline_size = v
		_refresh_value_font()

var _base: TextureRect
var _type_group: Node2D
var _type_icons: Dictionary = {}        # id: String -> TextureRect
var _target_group: Node2D
var _target_icons: Dictionary = {}      # "monomer"/"aoe" -> TextureRect（固定两个图标）
var _active_type: String = ""
var _active_target: String = ""
var _active_value: String = ""
var _value_label: Label
var _faction: String = "player"

func _ready() -> void:
	_build()
	visible = false  # 默认隐藏，set_intent + 阵营为敌人后显示

func _build() -> void:
	# ① 底图
	_base = TextureRect.new()
	_base.name = "IntentBase"
	_base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_base)
	_try_load_base()
	# ② 意图类型组（含全部类型图标，统一着色 COLOR_INTENT）
	_type_group = Node2D.new()
	_type_group.name = "IntentTypeGroup"
	add_child(_type_group)
	for id in TYPE_IDS:
		var tr := TextureRect.new()
		tr.name = "Type_" + id
		tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_try_load(tr, "type_" + id + ".png", Color(0.3, 0.6, 1.0, 0.6))
		tr.modulate = COLOR_INTENT   # 覆盖颜色为 9c660a
		tr.visible = false
		_type_group.add_child(tr)
		_type_icons[id] = tr
	# 数值文字（格式 NxM：N=次数/M=伤害）：挂到类型组，活动图标正下方、水平居中于底图；空串时隐藏。
	_value_label = Label.new()
	_value_label.name = "IntentValue"
	_value_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_value_label.visible = false
	_value_label.add_theme_color_override("font_color", COLOR_INTENT)
	var font := load(FONT_PATH) as Font
	if font != null:
		var ls := LabelSettings.new()
		ls.font = font
		ls.font_size = value_font_size
		ls.outline_size = value_outline_size
		ls.outline_color = Color(0.0, 0.0, 0.0, 1.0)
		ls.font_color = COLOR_INTENT   # 字体颜色与类型图标一致（9c660a），LabelSettings 优先于 theme 覆盖
		_value_label.label_settings = ls
	else:
		push_warning("IntentRoot: 数值字体加载失败 %s，将用默认字体" % FONT_PATH)
	_type_group.add_child(_value_label)
	# ③ 意图目标组（固定两个图标：monomer=点, aoe=线；组合顺序与激活色由 TARGET_ORDER/TARGET_ACTIVE 决定）
	_target_group = Node2D.new()
	_target_group.name = "IntentTargetGroup"
	add_child(_target_group)
	for id in ["monomer", "aoe"]:
		var tr := TextureRect.new()
		tr.name = "Target_" + id
		tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_try_load(tr, "target_" + id + ".png", Color(1.0, 0.55, 0.3, 0.6))
		tr.visible = false
		_target_group.add_child(tr)
		_target_icons[id] = tr
	_rebuild_layout()

## 设置单位阵营（由 UnitRoot 转发）。仅敌人(enemy)显示意图组。
func set_faction(faction: String) -> void:
	_faction = faction
	_apply_visibility()

## 设置意图并显示：type_id 类型、target_id 目标组合（见 TARGET_IDS）、value 数值文字（格式 NxM，可空）。
## 类型组仅显示活动类型图标（着色 COLOR_INTENT，居中于底图），数值文字(NxM)位于类型图标下方并上移40px、同样居中于底图（字体色同 COLOR_INTENT）；
## 目标组显示「点+线」组合（排序由 target_id 决定，激活元素着色 COLOR_INTENT、另一着色 COLOR_INACTIVE）。
func set_intent(type_id: String, target_id: String, value: String = "") -> void:
	_active_type = type_id
	_active_target = target_id
	_active_value = value
	for id in TYPE_IDS:
		if _type_icons.has(id):
			_type_icons[id].visible = (id == type_id)
	# 目标组：点(单体)与线(范围)同时显示（组合成「点线/线点」），无目标时整组隐藏。
	var has_target: bool = (target_id != "") and _target_icons.has("monomer") and _target_icons.has("aoe")
	if _target_icons.has("monomer"):
		_target_icons["monomer"].visible = has_target
	if _target_icons.has("aoe"):
		_target_icons["aoe"].visible = has_target
	# 数值文字：空串隐藏；think 类型下强制隐藏（环境/思考类意图不显示数值）。
	if is_instance_valid(_value_label):
		_value_label.text = value
		_value_label.visible = (value != "") and (type_id != "think")
		if value != "":
			_value_label.size = _value_label.get_minimum_size()
	_apply_visibility()
	_rebuild_layout()

## 显隐规则：仅当阵营为敌人且已设置意图类型时显示整个意图组。
func _apply_visibility() -> void:
	visible = (_faction == "enemy") and (_active_type != "")

## 读取当前意图（供外部系统联动，如 ATB 部件复用同一意图图标）。返回 {type, target, value}。
func get_intent() -> Dictionary:
	return {"type": _active_type, "target": _active_target, "value": _active_value}

## 安全加载：仅当资源已导入（存在 .import）才 load()，避免未导入 PNG 在 headless 下
## 触发 Godot 即时导入——导入需写临时文件再 rename，而 A: 盘 OS 锁禁止 rename 时会崩溃。
## 未导入则回退占位色块，待用户释放锁、编辑器正常导入后自动显示真实美术。
func _try_load_base() -> void:
	_try_load(_base, BASE_FILE, Color(0.6, 0.6, 0.6, 0.35), Vector2(160.0, 48.0))

func _try_load(rect: TextureRect, file: String, placeholder: Color, fallback_size: Vector2 = Vector2(32.0, 32.0)) -> void:
	var full := INTENT_DIR + file
	if FileAccess.file_exists(full + ".import"):
		var tex := load(full) as Texture2D
		if tex != null:
			rect.texture = tex
			rect.size = tex.get_size()
			rect.modulate = Color(1.0, 1.0, 1.0, 1.0)
			return
	rect.texture = null
	rect.size = fallback_size
	rect.modulate = placeholder

## 刷新数值文字字号/描边（F6 改 export 即时生效）。
func _refresh_value_font() -> void:
	if is_instance_valid(_value_label) and _value_label.label_settings != null:
		_value_label.label_settings.font_size = value_font_size
		_value_label.label_settings.outline_size = value_outline_size
		if _active_value != "":
			_value_label.size = _value_label.get_minimum_size()
		_rebuild_layout()

## 布局：三组均以各自 offset 为原点居中。
func _rebuild_layout() -> void:
	if is_instance_valid(_base):
		_base.position = -_base.size * 0.5 + base_offset + group_offset
	if is_instance_valid(_type_group):
		_type_group.position = type_offset + group_offset
		_layout_type_unit()
	if is_instance_valid(_target_group):
		_target_group.position = target_offset + group_offset
		_layout_target_unit()

## 类型组：活动图标居中于组原点（即与底图中心对齐）；数值文字(NxM)位于图标正下方、水平居中于底图中心。
## 类型图标与数值文字各自独立居中（X 均对齐底图中心），不互相并排。无数值时空 label 隐藏、仅图标居中。
func _layout_type_unit() -> void:
	var icon: TextureRect = _type_icons.get(_active_type)
	if icon == null or not icon.visible:
		return
	# 类型图标居中（中心对齐组原点 = 底图中心）
	icon.position = Vector2(-icon.size.x * 0.5, -icon.size.y * 0.5)
	# 数值文字：位于图标正下方，水平居中于底图中心（X=0 即组原点 X）；再整体上移 40px 与图标收紧
	if is_instance_valid(_value_label) and _value_label.visible and _active_value != "":
		var val_size: Vector2 = _value_label.get_minimum_size()
		var gap_v: float = 4.0
		_value_label.position = Vector2(-val_size.x * 0.5, icon.size.y * 0.5 + gap_v - 44.0)

## 目标组：点(单体)与线(范围)并排组合成「点线」或「线点」，二者 Y 轴居中对齐。
## 排序由 TARGET_ORDER 决定；激活元素取 COLOR_INTENT，另一取 COLOR_INACTIVE（见 TARGET_ACTIVE）。
func _layout_target_unit() -> void:
	var dot: TextureRect = _target_icons.get("monomer")    # 点
	var line: TextureRect = _target_icons.get("aoe")       # 线
	if dot == null or line == null:
		return
	var order: Array = TARGET_ORDER.get(_active_target, ["monomer", "aoe"])
	# think 状态：点线均无明确攻击目标，二者皆灰色未激活（COLOR_INACTIVE）。
	var active_id: String = "think" if _active_type == "think" else TARGET_ACTIVE.get(_active_target, "")
	# 着色：激活=COLOR_INTENT，另一=COLOR_INACTIVE；think 下二者皆未激活。
	if active_id == "think":
		dot.modulate = COLOR_INACTIVE
		line.modulate = COLOR_INACTIVE
	else:
		dot.modulate = COLOR_INTENT if active_id == "monomer" else COLOR_INACTIVE
		line.modulate = COLOR_INTENT if active_id == "aoe" else COLOR_INACTIVE
	# 并排：按 order 决定先后的图标（"aoe"=线在前 / "monomer"=点在前）
	var first_is_line: bool = (order[0] == "aoe")
	var first: TextureRect = line if first_is_line else dot
	var second: TextureRect = dot if first_is_line else line
	var gap: float = 3.0
	var total_w: float = dot.size.x + line.size.x + gap
	var x0: float = -total_w * 0.5
	first.position = Vector2(x0, -first.size.y * 0.5)
	second.position = Vector2(x0 + first.size.x + gap, -second.size.y * 0.5)

## 生成随机意图数值文字（格式 NxM：N=次数 1~3、M=伤害 1~12）。
## 用于尚未接入真实「单位战斗意图」数据前临时填充；接入后应由意图数据算出具体值并经 set_intent 传入。
static func random_intent_value() -> String:
	var times := randi_range(1, 3)
	var dmg := randi_range(1, 12)
	return "%dx%d" % [times, dmg]

class_name UnitHp
extends Node2D

## 单位血条组件（Step 1 · 6b）。三层 TextureProgressBar（实心/底槽/外框）+ 居中数值 + 护盾叠层。
## 居中铁律：本组件内部所有零件以父节点(UnitRoot)原点为基准，整体 x 居中于 0。护盾为叠层，出现/消失不推血条。

const HP_FILL_PATH: String = "res://assets/Unit UI/unit_hud/hp_bar_fill.png"
const HP_BG_PATH: String = "res://assets/Unit UI/unit_hud/hp_bar_bg.png"
const HP_FRAME_PATH: String = "res://assets/Unit UI/unit_hud/hp_bar_frame.png"
const HP_SHIELD_PATH: String = "res://assets/Unit UI/unit_hud/hp_shield.png"
const FONT_PATH: String = "res://assets/fonts/DouyinSansBold.otf"

signal hp_changed(new_current: float, new_max: float)
signal shield_changed(new_value: float)

## 护盾图标相对血条右端的偏移（叠层，不推血条）
@export var shield_icon_offset_x: float = 6.0 :
	set(value):
		shield_icon_offset_x = value
		_refresh_shield_position()

## HP 数值与护盾数值的字体大小（原始基础 16，可按观感微调）
@export var hp_font_size: int = 20 :
	set(value):
		hp_font_size = value
		_refresh_label_font()

## HP 数值与护盾数值的描边粗细（原始基础 2，可按观感微调）
@export var hp_outline_size: int = 6 :
	set(value):
		hp_outline_size = value
		_refresh_label_font()

var _bar: TextureProgressBar
var _hp_text: Label
var _shield: Node2D
var _shield_icon: TextureRect
var _shield_text: Label
var _bar_size: Vector2 = Vector2.ZERO

var _max_hp: float = 100.0
var _cur_hp: float = 100.0
var _shield_val: float = 0.0

func _ready() -> void:
	_build()

func _build() -> void:
	var fill_tex := load(HP_FILL_PATH) as Texture2D
	var bg_tex := load(HP_BG_PATH) as Texture2D
	var frame_tex: Texture2D = null
	if ResourceLoader.exists(HP_FRAME_PATH):
		frame_tex = load(HP_FRAME_PATH) as Texture2D
	var shield_tex := load(HP_SHIELD_PATH) as Texture2D

	if fill_tex == null or bg_tex == null:
		push_warning("UnitHp: 血条美术缺失 %s / %s" % [HP_FILL_PATH, HP_BG_PATH])
		return

	_bar_size = fill_tex.get_size()

	# 三层血条：texture_progress=实心血 / texture_under=损失后暗轨 / texture_over=外框
	_bar = TextureProgressBar.new()
	_bar.name = "HpBar"
	_bar.fill_mode = TextureProgressBar.FILL_LEFT_TO_RIGHT
	_bar.texture_progress = fill_tex
	_bar.texture_under = bg_tex
	if frame_tex != null:
		_bar.texture_over = frame_tex
	_bar.min_value = 0.0
	_bar.max_value = _max_hp
	_bar.value = _cur_hp
	_bar.size = _bar_size
	_bar.position = Vector2(-_bar_size.x * 0.5, 0.0)
	add_child(_bar)

	_hp_text = Label.new()
	_hp_text.name = "HpText"
	_hp_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_hp_text.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_hp_text.text = _hp_label()
	var font := load(FONT_PATH) as Font
	if font != null:
		var ls := LabelSettings.new()
		ls.font = font
		ls.font_size = hp_font_size
		ls.outline_size = hp_outline_size
		ls.outline_color = Color.BLACK
		_hp_text.label_settings = ls
	_hp_text.size = _bar_size
	# 仅本次：HP 文字整体下移 2px（独立调整，不与护盾文字捆绑）
	_hp_text.position = Vector2(-_bar_size.x * 0.5, 2.0)
	add_child(_hp_text)

	# 护盾叠层（靠右，不占血条布局；护盾=0 时隐藏）
	_shield = Node2D.new()
	_shield.name = "ShieldOverlay"
	_shield.visible = _shield_val > 0.0
	add_child(_shield)

	if shield_tex != null:
		var icon_size := shield_tex.get_size()
		_shield_icon = TextureRect.new()
		_shield_icon.name = "ShieldIcon"
		_shield_icon.texture = shield_tex
		_shield_icon.size = icon_size
		_shield_icon.position = Vector2(0.0, -icon_size.y * 0.5)
		_shield.add_child(_shield_icon)
		_shield_text = Label.new()
		_shield_text.name = "ShieldText"
		_shield_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		_shield_text.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		_shield_text.text = str(int(_shield_val))
		if font != null:
			var sls := LabelSettings.new()
			sls.font = font
			sls.font_size = hp_font_size
			sls.outline_size = hp_outline_size
			sls.outline_color = Color.BLACK
			_shield_text.label_settings = sls
		_shield_text.size = Vector2(60.0, icon_size.y)
		# 仅本次对齐：护盾文字上移半个自身框高，使其字形中心落在 bar 垂直中心（与 HP 文字同 Y）。
		# 注意——这是一次性位置对齐，不引入"护盾/HP 共用高度"参数，二者高度后续可独立调整。
		# 仅本次：护盾文字相对图标额外左移 30px（只动文字、不动图标；一次性调整，不进导出参数）
		# 仅本次：护盾文字整体下移 2px（独立调整，不与 HP 文字捆绑）
		_shield_text.position = Vector2(icon_size.x + 2.0 - 45.0, -icon_size.y * 0.5 + 2.0)
		_shield.add_child(_shield_text)
	else:
		push_warning("UnitHp: 护盾图标缺失 %s" % HP_SHIELD_PATH)

	_refresh_shield_position()

func setup_stats(max_v: float, cur_v: float, shield_v: float) -> void:
	_max_hp = maxf(max_v, 1.0)
	_cur_hp = clampf(cur_v, 0.0, _max_hp)
	_shield_val = maxf(shield_v, 0.0)
	if is_instance_valid(_bar):
		_bar.max_value = _max_hp
		_bar.value = _cur_hp
	if is_instance_valid(_hp_text):
		_hp_text.text = _hp_label()
	if is_instance_valid(_shield):
		_shield.visible = _shield_val > 0.0
	if is_instance_valid(_shield_text):
		_shield_text.text = str(int(_shield_val))
	hp_changed.emit(_cur_hp, _max_hp)
	shield_changed.emit(_shield_val)

func set_hp(v: float) -> void:
	_cur_hp = clampf(v, 0.0, _max_hp)
	if is_instance_valid(_bar):
		_bar.value = _cur_hp
	if is_instance_valid(_hp_text):
		_hp_text.text = _hp_label()
	hp_changed.emit(_cur_hp, _max_hp)

func set_max_hp(v: float) -> void:
	_max_hp = maxf(v, 1.0)
	if is_instance_valid(_bar):
		_bar.max_value = _max_hp
		_bar.value = _cur_hp
	if is_instance_valid(_hp_text):
		_hp_text.text = _hp_label()
	hp_changed.emit(_cur_hp, _max_hp)

func set_shield(v: float) -> void:
	_shield_val = maxf(v, 0.0)
	if is_instance_valid(_shield):
		_shield.visible = _shield_val > 0.0
	if is_instance_valid(_shield_text):
		_shield_text.text = str(int(_shield_val))
	shield_changed.emit(_shield_val)

func _hp_label() -> String:
	return "%d/%d" % [int(_cur_hp), int(_max_hp)]

func _refresh_shield_position() -> void:
	if not is_instance_valid(_shield):
		return
	var right_edge := _bar_size.x * 0.5
	# 护盾整体(图标+文字)相对原位置左移 30px（一次性视觉调整，不进导出参数；图标文字作为整体一起移）
	_shield.position = Vector2(right_edge + shield_icon_offset_x - 30.0, _bar_size.y * 0.5)

func _refresh_label_font() -> void:
	for lbl: Label in [_hp_text, _shield_text]:
		if not is_instance_valid(lbl) or lbl.label_settings == null:
			continue
		lbl.label_settings.font_size = hp_font_size
		lbl.label_settings.outline_size = hp_outline_size

extends Node2D

## 6c 自检场景：实例化两个 UnitRoot（玩家方 player 居左 + 敌方 enemy 居右），摆放在屏幕两侧（类似 Battle 槽位），
## 验证阵营相关的组件开关：玩家方启用升级组(经验条+升级特效)且不显示意图；敌方显示意图且关闭升级组。
## 顶部按钮：触发 buff / 升级 / 切换血条经验 / 随机意图（敌方意图常态默认打开，无需显示按钮）。

## 测试用 buff 池（与 #BuffInfo.xlsx 当前两行一致；生产环境应改由数据表加载）
const BUFF_POOL: Array[Dictionary] = [
	{"id": "buff001", "name": "士气", "tone": 1, "desc": "攻击卡牌为额外造5点伤害。"},
	{"id": "buff002", "name": "流血", "tone": 2, "desc": "回合结束时受到5点伤害，并且层数减半。"},
]

var _unit_player: UnitRoot
var _unit_enemy: UnitRoot
var _dim_on: bool = false   # 黑幕开关：true=两侧单位美术均已变纯黑剪影

func _ready() -> void:
	_unit_player = UnitRoot.new()
	_unit_player.unit_id = "Zhouzhou"
	_unit_player.unit_faction = "player"   # 玩家方：启用升级组（经验条+升级特效），不显示意图
	_unit_player.current_hp = 50.0
	_unit_player.shield = 30.0
	_unit_player.position = Vector2(480.0, 510.0)   # 左侧（类似 Battle 玩家槽位）
	add_child(_unit_player)

	_unit_enemy = UnitRoot.new()
	_unit_enemy.unit_id = "Banner"
	_unit_enemy.unit_faction = "enemy"   # 敌方：显示意图，关闭升级组（经验条+升级特效）
	_unit_enemy.current_hp = 80.0
	_unit_enemy.position = Vector2(1120.0, 510.0)   # 右侧（类似 Battle 敌方槽位）
	add_child(_unit_enemy)

	_add_random_button()

func _add_random_button() -> void:
	# 按钮是 Control 节点，直接挂 Node2D 下渲染不可靠（常不显示）。
	# 放进独立 CanvasLayer，确保画布层级正确、不受 UnitRoot 变换影响。
	var layer := CanvasLayer.new()
	layer.layer = 128
	add_child(layer)
	var panel := Control.new()
	panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(panel)
	var btn := Button.new()
	btn.text = "随机获得一层 Buff"
	btn.custom_minimum_size = Vector2(220.0, 48.0)
	btn.size = Vector2(220.0, 48.0)
	btn.position = Vector2((1600.0 - 220.0) * 0.5, 20.0)  # 顶部居中（视口 1600×900）
	panel.add_child(btn)
	btn.pressed.connect(_on_random_buff_pressed)
	var btn_upgrade := Button.new()
	btn_upgrade.text = "升级"
	btn_upgrade.custom_minimum_size = Vector2(220.0, 48.0)
	btn_upgrade.size = Vector2(220.0, 48.0)
	btn_upgrade.position = Vector2((1600.0 - 220.0) * 0.5, 76.0)  # 顶部居中，随机按钮正下方
	panel.add_child(btn_upgrade)
	btn_upgrade.pressed.connect(_on_upgrade_pressed)
	var btn_toggle := Button.new()
	btn_toggle.text = "切换(血条/经验)"
	btn_toggle.custom_minimum_size = Vector2(220.0, 48.0)
	btn_toggle.size = Vector2(220.0, 48.0)
	btn_toggle.position = Vector2((1600.0 - 220.0) * 0.5, 132.0)  # 升级按钮正下方
	panel.add_child(btn_toggle)
	btn_toggle.pressed.connect(_on_toggle_pressed)
	# 随机意图按钮：随机组合类型/目标/数值文字，演示意图组随机切换（敌方常态已默认打开意图，此处可打乱验证阵营门控）。
	var btn_random_intent := Button.new()
	btn_random_intent.text = "随机意图"
	btn_random_intent.custom_minimum_size = Vector2(220.0, 48.0)
	btn_random_intent.size = Vector2(220.0, 48.0)
	btn_random_intent.position = Vector2((1600.0 - 220.0) * 0.5, 188.0)  # 切换按钮正下方（原「显示意图」位，敌方默认已开）
	panel.add_child(btn_random_intent)
	btn_random_intent.pressed.connect(_on_random_intent_pressed)
	# 黑幕开关：打开/关闭两侧单位美术的纯黑剪影（set_dimmed）。用于隔离验证选靶黑幕视觉，不依赖手牌流程。
	var btn_dim := Button.new()
	btn_dim.text = "黑幕开关"
	btn_dim.custom_minimum_size = Vector2(220.0, 48.0)
	btn_dim.size = Vector2(220.0, 48.0)
	btn_dim.position = Vector2((1600.0 - 220.0) * 0.5, 244.0)  # 随机意图按钮正下方
	panel.add_child(btn_dim)
	btn_dim.pressed.connect(_on_dim_toggle_pressed)
	print("UnitTest: 两侧单位已放置（左=玩家方 Zhouzhou, 右=敌方 Banner）；敌方默认意图已开，5 个按钮已加至顶部居中（含黑幕开关）")

## 从 buff 池随机抽一个，两侧单位各获得一层（带数据表名称，触发 toast）
func _on_random_buff_pressed() -> void:
	if BUFF_POOL.is_empty():
		return
	var item := BUFF_POOL[randi() % BUFF_POOL.size()]
	if is_instance_valid(_unit_player):
		_unit_player.add_buff(item["id"], 1, item["tone"], item["name"], item["desc"])
	if is_instance_valid(_unit_enemy):
		_unit_enemy.add_buff(item["id"], 1, item["tone"], item["name"], item["desc"])

## 升级按钮：仅玩家方有升级组（敌方已关闭升级组，add_xp 为 no-op）。
## 不直接 emit 参数——真正的升级触发入口在 UnitRoot.add_xp() 内部。
var _show_xp_bar: bool = false

func _on_upgrade_pressed() -> void:
	if is_instance_valid(_unit_player):
		_unit_player.add_xp(1.0)
		var info := _unit_player.get_xp_info()
		print("UnitTest: 玩家方升级 → Lv.%d, XP %d/%d（敌方升级组已关闭，无效果）" % [info["level"], int(info["current"]), int(info["max"])])

## 切换按钮：互斥显示血条或经验条（仅玩家方有意义；敌方无经验条）。
func _on_toggle_pressed() -> void:
	_show_xp_bar = not _show_xp_bar
	if is_instance_valid(_unit_player):
		_unit_player.toggle_bar_display(_show_xp_bar)
	var mode := "经验条" if _show_xp_bar else "血条"
	print("UnitTest: 玩家方切换显示 → %s（敌方无经验条）" % mode)

## 随机意图：两侧都随机组合类型/目标/数值文字，演示意图组随机切换与阵营门控。
func _on_random_intent_pressed() -> void:
	var type_pool: Array[String] = IntentRoot.TYPE_IDS
	var target_pool: Array[String] = IntentRoot.TARGET_IDS
	var rtype: String = type_pool[randi() % type_pool.size()]
	var rtarget: String = target_pool[randi() % target_pool.size()]
	var rvalue: String = IntentRoot.random_intent_value()
	if is_instance_valid(_unit_player):
		_unit_player.set_intent(rtype, rtarget, rvalue)
	if is_instance_valid(_unit_enemy):
		_unit_enemy.set_intent(rtype, rtarget, rvalue)
	print("UnitTest: 随机意图 → 类型=%s, 目标=%s, 数值=%s（敌方可见, 玩家方不显示）" % [rtype, rtarget, rvalue])

## 黑幕开关：翻转两侧单位美术的纯黑剪影（set_dimmed 仅作用于美术 Sprite，不影响血条/意图条）。
## 用于隔离验证选靶黑幕视觉效果，无需进入手牌流程。
func _on_dim_toggle_pressed() -> void:
	_dim_on = not _dim_on
	if is_instance_valid(_unit_player):
		_unit_player.set_dimmed(_dim_on)
	if is_instance_valid(_unit_enemy):
		_unit_enemy.set_dimmed(_dim_on)
	print("UnitTest: 黑幕开关 → %s（两侧单位美术%s）" % ["开" if _dim_on else "关", "已变纯黑剪影" if _dim_on else "已恢复"])

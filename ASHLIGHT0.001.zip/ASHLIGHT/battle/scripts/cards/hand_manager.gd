class_name HandManager
extends Node2D

## 手牌系统（仅手牌部分，见【卡牌部件·手牌部分·逻辑提取】）：
## 数据模型 + 模块化组装(CardRoot) + 飞入 + 排列 + 悬停查看 + 回收动画 + 按角色分组排序。
## 1+1 选择状态机（可选同费配对）：点第一张→同费卡不下沉、异费下沉；可再点第二张同费卡(任意组)作为材料配对，
##
## 抽牌/牌库系统尚未实现，故用两个矩形占位代表「抽牌出发点(左)」与「弃牌回收点(右)」。
## 悬停用每帧权威命中（与 ATB/单位组一致），规避 Godot mouse_exited 在快速移动时漏发导致的残留高亮。
##
## 分组规则（用户确立）：三个角色(周周/艾琳/火炮)各抽 per_role 张，按 battle 单位【槽位】映射为
## 左/中/右三区（周周=左、艾琳=中、火炮=右，不看具体 x 数值）。组内排序：低费→高费、即时(蓝)→执行(橙)。
## 组内用小于卡宽的间距叠放：索引 0(左=低费即时) → 末位(右=高费执行)，右卡在顶层；悬停时抬到最前完整查看。
## 三组作为一个整体水平居中、组间仅留 group_gap。
##
## 抽牌顺序（用户确立 2026-09-04）：按槽位从右→左 —— 炮炮(右)→艾琳(中)→周周(左)。
## 每个角色初始卡牌以随机顺序飞入，不预先排牌序；待该角色 4 张全部飞入后，对该组排一次序，
## 并刷新一次「右→左」层级(z 越大层级越高，故右组始终压在左组之上)。
## 关键修复：layout() 必须同步写 c.z_index = c.base_z，否则抽牌后层级不生效(只能靠悬停 unhover 修正)。

## battle 已有三角色（卡面来源）：周周 / 艾琳 / 火炮(Rocket)。顺序即左/中/右三区顺序。
const ROLES: Array[String] = ["Zhouzhou", "Irene", "Rocket"]
## 抽牌顺序：按【槽位】从右→左（炮炮→艾琳→周周）。
const DRAW_ORDER: Array[String] = ["Rocket", "Irene", "Zhouzhou"]
## 角色 → 布局槽位(0=左/1=中/2=右)，与 ROLES 索引一致。
const ROLE_SLOT: Dictionary = {"Zhouzhou": 0, "Irene": 1, "Rocket": 2}


@export_group("Layout")
@export var hand_scale: float = 0.42
@export var hand_y: float = 810.0            # 手牌基准 Y（整组下移 20px）
@export var card_step: float = 70.0          # 组内相邻卡中心间距(px)：正=向右展开；小于卡宽即叠放
@export var group_gap: float = 30.0          # 组与组之间的间距(px)
@export var hover_lift: float = 75.0          # 悬停时卡牌上移(px)
@export var hover_scale: float = 1.4

@export_group("Grouping")
@export var per_role: int = 4                # 每个角色抽几张

@export_group("Animation")
@export var anim_dur: float = 0.35
@export var stagger_ms: float = 80.0
@export var sound_lead_ms: float = 60.0        # 抽牌音相对卡牌飞入的前置量：让"抽到"的听感抢在视觉之前，消除滞后感（需 < stagger_ms 以免声音挤成一团）

@export_group("Test")
@export var auto_draw_test: bool = true

@export_group("Debug")
## 调试预览：非空(如 "Zhouzhou")→强制该角色组为「激活」(原色+展开)、其余组显示「未激活」压暗，
## 便于 battle 测试场景目测压暗效果；"" 走正常 ATB 聚光框驱动。生产置空。
@export var debug_preview_inactive_role: String = ""

@export_group("Zones (debug)")
@export var show_zones: bool = true


var _cards: Array[HandCard] = []
var _groups: Array = []     # 与 ROLES 同序，每组内部已排序（GDScript 2.0 不支持嵌套类型数组，故用 Array）
var _draw_zone: ColorRect
var _discard_zone: ColorRect
var _hovered: HandCard = null


## 每张卡当前活跃的位移/缩放 tween（值为普通 Array，可同时存「位置 tween」与「缩放回弹 tween」）。
## 严格模式下 Dictionary 不能存 typed Array[Tween]，故 kill 时逐元素 as Tween 转换。
## 切换悬停/弃牌前 kill 全部，避免多个 tween 抢同一属性导致位置/缩放被覆盖。
var _card_tweens: Dictionary = {}
## 高亮框内玩家单位对应角色（该组间距 +20，其余组 -20；空串=均用 card_step）。
var _expanded_role: String = ""
## 防重入：重新发牌/回收动画进行中不重复触发 redraw。
var _redrawing: bool = false
## ATB 轨道引用缓存（preview_cost_for 用），经 group 取得避免硬编码路径。
var _atb_cache: AtbTrack = null

## ── 选牌状态机（点击打出流程的过程层；效果实装由外部接 card_used 信号）──
## 当前选中的卡（非 null = 已进入「选靶」态）。
var _selected: HandCard = null
## 1+1 配对：选第一张后，可再点一张「同费」卡作为材料（不触发效果），成功打出后随主卡进弃牌堆。
var _paired_card: HandCard = null
## 选靶时，除选中卡外所有手牌临时下移量(px)。
const SELECT_SHIFT_Y: float = 120.0
## 选靶黑幕用：从卡面 effects_text 解析的行标签优先级顺序（先出现者生效）。
const _ROW_TAGS: Array[String] = ["前排", "后排", "同排", "异排", "全部"]
## 特殊开关：允许点击「未激活」手牌组。默认 false（未激活组不可选）；选第一张后临时置 true，
## 使 1+1 的第二张同费卡可来自任意组(含未激活)；clear_selection / redraw 时复位 false。
var allow_inactive_selection: bool = false

## 卡牌被选中（已进入选靶态）。
signal card_selected(hc: HandCard)
## 选靶取消（右键取消 / 打出后重置），手牌临时位移应取消。
signal card_deselected()
## 选中卡对单位碰撞箱完成「使用」点击（当前无效果，仅过程；后续接效果在此信号）。
signal card_used(hc: HandCard, unit: UnitRoot)

## 选中高亮框（呼吸灯）配色：第一张按费用菱形色（即时蓝 COST_INSTANT / 执行橙 COST_EXECUTE）区分，由 select_card 计算；
## 第二张统一灰色。WHITE_* 仅作历史调色板常量保留（当前第一张已改用费用色），无害不影响逻辑。
const COLOR_SELECT_WHITE_A: Color = Color(1.0, 1.0, 1.0, 1.0)
const COLOR_SELECT_WHITE_B: Color = Color(0.45, 0.85, 1.0, 1.0)
const COLOR_SELECT_GRAY_A: Color = Color(0.62, 0.62, 0.66, 1.0)
const COLOR_SELECT_GRAY_B: Color = Color(0.35, 0.5, 0.95, 1.0)


func _ready() -> void:
	add_to_group("hand_manager")   # 同步入组：BattleRoot._ready 发 framed_changed 时本节点已在组，信号不丢
	_build_zones()
	if auto_draw_test:
		# 延迟一帧再发牌：先让空场景渲染一帧，使「回合开始(F6载入)才发牌」可视化清晰，
		# 避免发牌动画在首帧前就跑完、看起来像卡牌已就位未发牌。
		await get_tree().process_frame
		redraw()


## ── 调试占位区：抽牌出发点=左(与预览一致) / 弃牌回收点=右 ──
func _build_zones() -> void:
	if not show_zones:
		return
	var vsize := get_viewport_rect().size
	_draw_zone = _make_zone(Color(0.2, 0.5, 0.9, 0.35), "抽牌")
	_draw_zone.position = Vector2(130.0, vsize.y - 140.0)
	_discard_zone = _make_zone(Color(0.9, 0.3, 0.2, 0.35), "弃牌")
	_discard_zone.position = Vector2(vsize.x - 130.0, vsize.y - 140.0)
	add_child(_draw_zone)
	add_child(_discard_zone)


func _make_zone(col: Color, label: String) -> ColorRect:
	var r := ColorRect.new()
	r.size = Vector2(150.0, 220.0)
	r.position = -r.size * 0.5
	r.color = col
	var lbl := Label.new()
	lbl.text = label
	lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	lbl.size = r.size
	lbl.position = -r.size * 0.5
	r.add_child(lbl)
	return r


## ── 重新发牌：先回收当前所有手牌(飞向弃牌区)，待回收动画结束后再从抽牌矩形重新发牌（顺序化，避免新旧并发叠飞）──
## 整个事务（回收 + 发牌动画）期间 _redrawing=true，手牌交互（悬停查看 / 点击选牌）均锁定。
func redraw() -> void:
	if _redrawing:
		return
	_redrawing = true
	# 先杀掉所有在跑的卡牌 tween（含初始发牌 deal tween），避免与新回收 tween 抢同一 position → 飞入飞出被覆盖、看不到。
	for arr in _card_tweens.values():
		for t in arr:
			var tw := t as Tween
			if is_instance_valid(tw):
				tw.kill()
	_card_tweens.clear()
	var old := _cards.duplicate()
	_cards.clear()
	_groups.clear()
	_hovered = null
	_selected = null   # 重新发牌：丢弃任何进行中的选靶态，避免指向即将 free 的卡
	_paired_card = null
	allow_inactive_selection = false
	if old.is_empty():
		_draw_grouped()
		await _unlock_after_deal()
		return
	# 回收顺序：从右往左（home_pos.x 由大到小），最右卡先收回、逐张向左；
	# 每张从当前大小缩小并飞入弃牌矩形（recycle_card 内 tween scale→小、position→弃牌区），错峰非同时。
	var recycle_order: Array[HandCard] = old.duplicate()
	recycle_order.sort_custom(func(a: HandCard, b: HandCard) -> bool:
		return a.home_pos.x > b.home_pos.x)
	var step: float = 0.06
	var i: int = 0
	for c in recycle_order:
		recycle_card(c, float(i) * step)
		i += 1
	# 等最后一张回收动画彻底结束后再从抽牌矩形重新发牌（顺序化：先收完，再发；绝不同时）。
	var total: float = anim_dur + float(i - 1) * step + 0.05
	await get_tree().create_timer(total).timeout
	_card_tweens.clear()   # 回收 tween 已结束/随卡 free，清掉死键避免误杀新发牌 tween
	_draw_grouped()
	await _unlock_after_deal()


## 等发牌动画彻底结束再解锁手牌交互（抽牌动画进行中同样禁止悬停查看 / 点击）。
func _unlock_after_deal() -> void:
	var n: int = _cards.size()
	var deal_total: float = float(maxi(n - 1, 0)) * stagger_ms / 1000.0 + anim_dur + 0.05
	await get_tree().create_timer(deal_total).timeout
	_redrawing = false


## 抽牌顺序按 DRAW_ORDER(右→左)：炮炮 → 艾琳 → 周周。
## 每个角色抽 per_role 张，初始以随机顺序飞入；该角色 4 张全部飞入后对该组排一次序(低费→高费、即时→执行)，
## 并刷新一次「右→左」层级(layout 写入 z_index)。槽位布局固定(ROLE_SLOT)，抽牌过程中不左右跳动。
func _draw_grouped() -> void:
	# 按布局槽位(0左/1中/2右)初始化三组空数组，保证抽牌过程中槽位固定。
	_groups = []
	for i in ROLES.size():
		_groups.append([])

	for role in DRAW_ORDER:
		var slot: int = int(ROLE_SLOT[role])
		var group: Array[HandCard] = []
		# 从 CardDatabase 取该角色卡（文档自动生成的数据），自动填名字/费用/类型/效果/卡面。
		var pool: Array[CardData] = CardDatabase.new().get_by_role(role)
		var take: int = mini(per_role, pool.size())
		for k in take:
			var cd: CardData = pool[k]
			var hc := _spawn_card_for_role(cd, role)
			hc.scale = Vector2.ONE * hand_scale * 0.5
			hc.position = _flyin_origin()
			_cards.append(hc)
			group.append(hc)
		# 该角色初始卡牌抽取结束 → 排一次序(先费用类型即时→执行，再费用值低→高)。
		group.sort_custom(func(a: HandCard, b: HandCard) -> bool:
			if a.card.cost_type != b.card.cost_type:
				return a.card.cost_type < b.card.cost_type
			return a.card.cost_value < b.card.cost_value)
		_groups[slot] = group
	# 三组全部抽完后，一次性从右往左连续发牌(右→左全局 stagger)：
	# 避免逐组布局导致前两组被瞬间落位、只剩最左组带动画，使发牌割裂/看似从左往右。
	layout(true)
	_refresh_inactive()   # 初始发牌时按当前高亮框玩家单位决定各组「未激活」压暗（无高亮则全部原色）


## 由 CardData 构造一张 HandCard 入树（STATE_HAND），不做定位/分组（由调用方负责位置与 _cards/_groups 登记）。
func _spawn_card_for_role(cd: CardData, role: String) -> HandCard:
	var card := CardRoot.new()
	card.card_name = cd.card_name
	card.card_type = cd.card_type
	card.cost_type = cd.cost_type
	card.cost_value = cd.cost_value
	card.rarity = cd.rarity
	card.enhanced = cd.enhanced
	card.card_effect = cd.effects_text      # 卡面显示标签（【前排】【单体】等）
	card.card_desc = cd.description
	if cd.art_id != "":
		card.set_face_by_file(cd.art_id)    # 文档 art_id 即卡面文件名
	var hc := HandCard.new()
	hc.setup(card, _cards.size(), role)
	hc.data = cd                            # 关联静态数据，打出时解析用
	add_child(hc)            # 此时 card 入树、_ready 构建节点树（含已设字段）
	hc.state = HandCard.STATE_HAND
	return hc

## 1+1 抽牌：根据第二张同费卡的角色归属，从 CardDatabase 该角色池随机抽一张（当前允许与手牌重复；
## 待正式牌库系统实现后再接轨取牌规则）。新卡从抽牌矩形飞入、加入对应角色组，layout 接管定位动画。
func _draw_one_for_role(role: String) -> HandCard:
	if not ROLES.has(role):
		return null
	var slot: int = int(ROLE_SLOT[role])
	var pool: Array[CardData] = CardDatabase.new().get_by_role(role)
	if pool.is_empty():
		return null
	var idx_r: int = randi() % pool.size()
	var cd: CardData = pool[idx_r]
	var hc := _spawn_card_for_role(cd, role)
	hc.scale = Vector2.ONE * hand_scale * 0.5
	hc.position = _flyin_origin()    # 从抽牌矩形出发，layout 会 tween 到 home（飞入感）
	(_groups[slot] as Array).append(hc)
	_cards.append(hc)
	print("[HM] draw_one_for_role role=%s name=%s (随机抽，待牌库接轨)" % [role, cd.card_name])
	return hc

## 飞入出发点：抽牌矩形中心（无占位区时退化为左下角）。
func _flyin_origin() -> Vector2:
	if is_instance_valid(_draw_zone):
		return _draw_zone.global_position
	return Vector2(130.0, hand_y)


## ── 排列：三组按槽位 0左→1中→2右排成一整块、组间留 group_gap、整体水平居中；
## 组内索引 0(左=低费即时)→末位(右=高费执行)，步长向右为正，右卡层级高(顶层)。
## 发牌动画按 DRAW_ORDER(右→左)做全局连续 stagger，使发牌视觉从右往左流动、不割裂。
## 高亮框内玩家单位对应角色组步长 +20、其余组 -20（_expanded_role 为空则均用 card_step）。 ──
func layout(animated: bool = true, play_sounds: bool = true, sound_cards: Array[HandCard] = []) -> void:
	var active: Array[HandCard] = _cards.filter(func(c: HandCard): return is_instance_valid(c) and c.state == HandCard.STATE_HAND)
	if active.is_empty():
		return
	var vsize := get_viewport_rect().size
	var card_w := _native_width() * hand_scale

	# 三组装成一块，组间留 group_gap，整体水平居中（保持槽位 0左→1中→2右顺序）。
	var total_w: float = 0.0
	for g in _groups.size():
		var role: String = ROLES[g] if g < ROLES.size() else ""
		var step: float = card_step
		var er := _effective_role()
		if er != "":
			step += 20.0 if role == er else -20.0
		var span := maxf(card_w + float(per_role - 1) * step, card_w)
		total_w += span
	total_w += group_gap * maxf(float(_groups.size() - 1), 0.0)
	var cursor: float = (vsize.x - total_w) * 0.5

	# 右→左全局发牌延迟索引（炮炮→艾琳→周周），使整段发牌从右往左连续流动、不割裂。
	var deal_idx: Dictionary = {}
	var gi: int = 0
	for role in DRAW_ORDER:
		var slot: int = int(ROLE_SLOT[role])
		var grp: Array = _groups[slot]
		for c in grp:
			deal_idx[c] = gi
			gi += 1

	for g in _groups.size():
		var grp: Array = _groups[g]
		var n: int = grp.size()
		# 本组有效步长：高亮框玩家单位对应角色 +20，其余组 -20（_expanded_role 为空则均用 card_step）。
		var role: String = ROLES[g] if g < ROLES.size() else ""
		var step: float = card_step
		var er := _effective_role()
		if er != "":
			step += 20.0 if role == er else -20.0
		# 跨度按满编 per_role 计算（保证抽牌过程中整体宽度恒定、不左右跳动）。
		var span: float = maxf(card_w + float(per_role - 1) * step, card_w)
		if n > 0:
			var center_x: float = cursor + span * 0.5
			var left: float = center_x - span * 0.5 + card_w * 0.5
			for i in n:
				var c := grp[i] as HandCard
				var x: float = left + float(i) * step
				# 索引大=右侧=费用高，层级高 → 右卡盖左卡（叠放层级从右往左）。
				c.base_z = 10 + g * 100 + i
				c.z_index = c.base_z          # 关键：同步写真实 z_index，抽牌后层级立即生效
				c.home_pos = Vector2(x, hand_y)
				# 注入稳定悬停命中框参数（基于 home_pos，不含上移/放大），断开悬停动画的命中正反馈。
				c.set_hit_params(hand_scale, hover_lift)
				var delay: float = float(deal_idx.get(c, 0)) * stagger_ms / 1000.0
				var tw: Tween
				var anim_delay: float = delay
				if animated:
					tw = create_tween().set_parallel(true)
					# 仅列出的卡(1+1 新抽)立即飞入、与抽牌音同步；其余卡按 deal_idx stagger 静默重排。
					if not sound_cards.is_empty() and sound_cards.has(c):
						anim_delay = 0.0
					tw.tween_property(c, "position", c.home_pos, anim_dur).set_delay(anim_delay)
					tw.tween_property(c, "scale", Vector2.ONE * hand_scale, anim_dur).set_delay(anim_delay)
					# 抽牌音随飞入错峰播放：play_sounds 且（sound_cards 空=全量发牌/redraw 全响；非空=仅列出的卡）响。随机取 4 种之一。
					# 声音前置 sound_lead_ms：抢在卡牌飞入之前触发，消除"卡动了才响"的滞后感（首张/1+1 已为 0 不再提前）。
					if play_sounds and (sound_cards.is_empty() or sound_cards.has(c)):
						var snd_delay: float = maxf(0.0, anim_delay - sound_lead_ms / 1000.0)
						tw.tween_callback(SfxManager.play_random_draw).set_delay(snd_delay)
					_card_tweens[c] = [tw]
				else:
					c.position = c.home_pos
					c.scale = Vector2.ONE * hand_scale
		# 空组也推进光标，槽位固定（右侧组始终在最右、层级最高）。
		cursor += span + group_gap


## 高亮框(第0格)玩家单位变化时：该单位对应角色手牌组间距 +20px，其余组 -20px；非玩家则复原。
## uid 即角色名（与 ROLES 一致）。重排生效。
func apply_framed_role(uid: String, is_player: bool) -> void:
	if is_player and ROLES.has(uid):
		_expanded_role = uid
	else:
		_expanded_role = ""
	layout(false)
	_refresh_inactive()   # 高亮框玩家单位→对应组原色、其余组「未激活」(0.3暗灰50%+0黑40%，费用组排除)

## 解析「当前生效的激活角色」：调试预览优先，否则用 ATB 聚光框驱动的 _expanded_role。
## layout 间距与 _refresh_inactive 压暗共用，保证调试预览同时影响展开与压暗。
func _effective_role() -> String:
	if debug_preview_inactive_role != "":
		return debug_preview_inactive_role
	return _expanded_role

## 刷新所有在手牌的「未激活」压暗状态（驱动 card_root.set_inactive / set_dim）：
## 高亮框在玩家单位(_expanded_role 非空) → 该角色组保持原色、其余组套「未激活」；
## 无玩家高亮(空串/敌方) → 全部保持原色。费用组由 card_root 全局排除，不在此处理。
func _refresh_inactive() -> void:
	var er := _effective_role()
	for c in _cards:
		if is_instance_valid(c) and c.state == HandCard.STATE_HAND and is_instance_valid(c.card):
			if er != "" and c.owner_group != er:
				c.card.set_inactive()
			else:
				c.card.set_dim(0.0)


## 取得 ATB 轨道引用（经 group，避免硬编码路径）；供悬停卡牌时联动预览标记。
func _get_atb() -> AtbTrack:
	if _atb_cache == null or not is_instance_valid(_atb_cache):
		_atb_cache = get_tree().get_first_node_in_group("atb_track") as AtbTrack
	return _atb_cache


## 回收：错峰 delay 后飞向弃牌矩形并缩小，结束后移除（先收完再重发由 redraw 的 await 保证顺序）。
func recycle_card(hc: HandCard, delay: float = 0.0) -> void:
	if not is_instance_valid(hc):
		return
	if _hovered == hc:
		_hovered = null
	hc.state = HandCard.STATE_PLAYED
	_kill_card_tween(hc)
	var dest := _discard_zone.global_position if is_instance_valid(_discard_zone) else Vector2(get_viewport_rect().size.x - 130.0, hand_y)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(hc, "position", dest, anim_dur).set_delay(delay)
	tw.tween_property(hc, "scale", Vector2.ONE * hand_scale * 0.3, anim_dur).set_delay(delay)
	# 关键：parallel 模式下 tween_callback 默认 delay=0 会在 t=0 立即触发 → 卡牌当帧 queue_free，
	# 回收动画根本来不及播（表现=手牌瞬间消失、随后才重发）。必须显式延迟到「该卡动画结束」才 free。
	tw.tween_callback(hc.queue_free).set_delay(delay + anim_dur)
	_card_tweens[hc] = [tw]   # 跟踪以便后续 redraw 杀掉（卡 free 后 tween 失效，由 is_instance_valid 兜底）

## 打出一张卡：从手牌列表移除并飞向弃牌矩形后销毁（q-2：仅飞入弃牌区消失，不做堆积弃牌堆）。
## 必须在 clear_selection 之前调用，确保 _restore_all 不再 tween 本卡（已从 _cards 移除），避免与飞牌抢 position。
func _discard_card(hc: HandCard) -> void:
	if not is_instance_valid(hc):
		return
	_cards.erase(hc)
	for g in _groups:
		if g is Array:
			(g as Array).erase(hc)
	if _hovered == hc:
		_hovered = null
	# 注意：此处不可置 _selected = null —— notify_used_on_unit 在 _discard_card 之后才调 clear_selection()，
	# 若提前清空，clear_selection 的 `if _selected == null: return` 守卫会直接跳过手牌复位与黑幕清除。
	# _selected 由 clear_selection() 统一清空（且 discard 已把 hc 移出 _cards，_restore_all 不会误 tween 本卡）。
	hc.state = HandCard.STATE_PLAYED
	_kill_card_tween(hc)
	var dest := _discard_zone.global_position if is_instance_valid(_discard_zone) else Vector2(get_viewport_rect().size.x - 130.0, hand_y)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(hc, "position", dest, anim_dur)
	tw.tween_property(hc, "scale", Vector2.ONE * hand_scale * 0.3, anim_dur)
	# parallel 下 tween_callback 默认 delay=0 会当帧 free → 飞牌动画丢失；必须显式延迟到动画结束。
	tw.tween_callback(hc.queue_free).set_delay(anim_dur)
	_card_tweens[hc] = [tw]


## ── 悬停：每帧权威命中，仅变化时刷新（规避 mouse_exited 漏发残留）──
func _process(_delta: float) -> void:
	if _redrawing:
		return   # 抽牌/回收动画进行中：锁定悬停查看，动画结束前不可检视手牌
	var gp := get_global_mouse_position()
	if _selected != null:
		return   # 选靶中：冻结悬停态切换，保持选中卡抬起/其余下沉
	var hit: HandCard = null
	for c in _cards:
		if is_instance_valid(c) and c.state == HandCard.STATE_HAND and c.is_point_inside(gp):
			if hit == null or c.base_z > hit.base_z:
				hit = c
	if hit != _hovered:
		_set_hover(hit)




func _set_hover(hc: HandCard) -> void:
	if is_instance_valid(_hovered):
		_unhover_card(_hovered)
	_hovered = hc
	if is_instance_valid(hc):
		_hover_card(hc)
		# 悬停卡牌 → 联动 ATB 插入预览标记：移动到「该角色插图当前格 + 费用」格。
		var atb := _get_atb()
		if is_instance_valid(atb):
			atb.preview_cost_for(hc.cost, hc.owner_group)
	else:
		# 离开卡牌 → 预览标记退回框内单位默认插入位。
		var atb := _get_atb()
		if is_instance_valid(atb):
			atb.clear_preview()


## 杀掉该卡当前活跃 tween（切换悬停/弃牌/重抽前调用），杜绝多个 tween 抢同一属性。
func _kill_card_tween(hc: HandCard) -> void:
	if _card_tweens.has(hc):
		# Dictionary 值本质是普通 Array（严格模式下不能存/转 typed Array[Tween]），逐元素 as Tween 才是安全写法。
		for t in _card_tweens[hc]:
			var tw := t as Tween
			if is_instance_valid(tw):
				tw.kill()
		_card_tweens.erase(hc)


## 悬停：仅被悬停的卡牌抬到最前(z=1000)、放大并上移 hover_lift(px)。
## 邻卡保持原位、不推动——悬停卡压在最前完整可见，鼠标移开即回到原位。
## 先 kill 该卡其它 tween（尤其是发牌 deal tween），保证上移/放大不被同属性的发牌 tween 覆盖。
func _hover_card(hc: HandCard) -> void:
	_kill_card_tween(hc)
	# 位置：独立 tween 平滑抬升，与缩放回弹并发。
	var pos_tw := create_tween()
	pos_tw.tween_property(hc, "position", Vector2(hc.home_pos.x, hand_y - hover_lift), 0.18)
	# 缩放：两段式手动过冲（先冲过 ~15% 再落定），纯 EASE_OUT 只过冲一次、不回振，幅度介于 BACK(10%) 与 ELASTIC(30%) 之间。
	var scale_tw := create_tween()
	var over_scale := Vector2.ONE * hand_scale * hover_scale * 1.15
	var settle_scale := Vector2.ONE * hand_scale * hover_scale
	scale_tw.tween_property(hc, "scale", over_scale, 0.14).set_ease(Tween.EASE_OUT)
	scale_tw.tween_property(hc, "scale", settle_scale, 0.2).set_ease(Tween.EASE_OUT)
	_card_tweens[hc] = [pos_tw, scale_tw]
	hc.z_index = 1000


func _unhover_card(hc: HandCard) -> void:
	_kill_card_tween(hc)
	# 位置：独立 tween 平滑回落，与缩放回弹并发。
	var pos_tw := create_tween()
	pos_tw.tween_property(hc, "position", hc.home_pos, 0.18)
	# 缩放：两段式手动过冲（先缩过 ~20% 再弹回），纯 EASE_OUT 不回振（移出版本3）。
	var scale_tw := create_tween()
	var under_scale := Vector2.ONE * hand_scale * 0.8
	var settle_scale := Vector2.ONE * hand_scale
	scale_tw.tween_property(hc, "scale", under_scale, 0.14).set_ease(Tween.EASE_OUT)
	scale_tw.tween_property(hc, "scale", settle_scale, 0.22).set_ease(Tween.EASE_OUT)
	_card_tweens[hc] = [pos_tw, scale_tw]
	hc.z_index = hc.base_z


## 选中/配对卡的统一「抬起」视觉：上移 hover_lift、放大 hover_scale、置顶 z(1000)。
## 第一张与第二张同费卡共用，使两张被选中的卡都清晰可见（放大比例 / 位移距离与悬停一致）。
## 高亮框由调用方在 _raise_card 之后按「第一张/第二张」分别 set_select_frame；此处先清旧高亮框防御。
func _raise_card(hc: HandCard) -> void:
	hc.clear_select_frame()
	_kill_card_tween(hc)
	var pos_tw := create_tween()
	pos_tw.tween_property(hc, "position", Vector2(hc.home_pos.x, hand_y - hover_lift), 0.18)
	# 缩放：选牌不抖——平滑线性放大到设定比例（无 ELASTIC 回弹）。
	var scale_tw := create_tween()
	scale_tw.tween_property(hc, "scale", Vector2.ONE * hand_scale * hover_scale, 0.18)
	_card_tweens[hc] = [pos_tw, scale_tw]
	hc.z_index = 1000


## 复位单卡到「待选」基准态：回到 home_pos、基准缩放、基准 z。并清选中高亮框。
## 取消选靶 / 打出后、以及切换配对卡时，把卡牌从「抬起」态还原（含缩放复位，避免 hover_scale 残留）。
func _lower_card(c: HandCard) -> void:
	_kill_card_tween(c)
	var pos_tw := create_tween()
	pos_tw.tween_property(c, "position", c.home_pos, 0.2)
	# 缩放：取消选牌不抖——平滑回基准缩放（无 ELASTIC 回弹）。
	var scale_tw := create_tween()
	scale_tw.tween_property(c, "scale", Vector2.ONE * hand_scale, 0.2)
	_card_tweens[c] = [pos_tw, scale_tw]
	c.z_index = c.base_z
	c.clear_select_frame()


## ── 选牌 / 选靶流程（过程层，无效果实装）──
## 鼠标输入：左键点已激活组卡牌=选中；选靶中左键忽略(留给 BattleRoot 点单位)；右键=取消。
func _input(event: InputEvent) -> void:
	if _redrawing:
		return   # 抽牌/回收动画进行中：锁定所有手牌操作（含右键取消 / 左键选牌）
	if not (event is InputEventMouseButton):
		return
	var mb := event as InputEventMouseButton
	if not mb.pressed:
		return
	if mb.button_index == MOUSE_BUTTON_RIGHT:
		if _selected != null:
			clear_selection()
		return
	if mb.button_index == MOUSE_BUTTON_LEFT:
		if _selected != null:
			# 选靶中：左键优先尝试「配对第二张同费卡」；点到同费卡→配对，点到异费卡→无法点击(忽略)，
			# 点到空白处→视为点单位(交给 BattleRoot 处理，本节点不处理)。
			var hit := _pick_topmost_card(get_global_mouse_position())
			if is_instance_valid(hit) and hit != _selected and hit.state == HandCard.STATE_HAND:
				if hit.cost == _selected.cost:
					_pair_second(hit)
				# 异费卡：无法点击 → 忽略
			return
		if not is_instance_valid(_hovered):
			return
		# [DEBUG] 选靶黑幕排查探针
		var _er := _effective_role()
		var _hn := "?"
		if is_instance_valid(_hovered.card):
			_hn = _hovered.card.card_name
		print("[HM] 左键点卡 name=%s owner_group=%s effective_role=%s allow_inactive=%s" % [_hn, _hovered.owner_group, _er, allow_inactive_selection])
		# Req1：未激活组不可选（除非 allow_inactive_selection 特殊开关）
		if not allow_inactive_selection and _hovered.owner_group != _er:
			print("[HM] ⛔ 闸门拦截：未激活组不可选（无激活组？effective_role 为空）")
			return
		select_card(_hovered)


## 配对第二张同费卡：记录为材料卡（不触发效果），并抬到同费卡之上作高亮提示。
## 视觉与第一张一致（上移+放大+置顶），使两张被选中的卡都清晰可见。
func _pair_second(hc: HandCard) -> void:
	if is_instance_valid(_paired_card) and _paired_card != hc:
		_lower_card(_paired_card)   # 复位旧配对卡到「待选」基准态（同费卡：留在原位移、基准缩放、基准 z）
	_paired_card = hc
	_raise_card(hc)   # 第二张：与第一张一致的「抬起」视觉，清晰标示已被选
	hc.set_select_frame(true, COLOR_SELECT_GRAY_A, COLOR_SELECT_GRAY_B)   # 第二张：灰色呼吸灯（不变色）
	print("[HM] pair_second name=%s owner_group=%s cost=%d" % [hc.card.card_name if is_instance_valid(hc.card) else "?", hc.owner_group, hc.cost])

## 取鼠标全局坐标命中的「最上层」在手牌（与 _process 悬停命中同规则），供配对点击复用。
func _pick_topmost_card(global_pos: Vector2) -> HandCard:
	var hit: HandCard = null
	for c in _cards:
		if is_instance_valid(c) and c.state == HandCard.STATE_HAND and c.is_point_inside(global_pos):
			if hit == null or c.base_z > hit.base_z:
				hit = c
	return hit


## 选中一张卡：记录选中态，其余手牌下移 SELECT_SHIFT_Y，广播 card_selected；并按卡面行标签对非目标单位(自身除外)盖黑幕剪影。
func select_card(hc: HandCard) -> void:
	if not is_instance_valid(hc):
		return
	_selected = hc
	allow_inactive_selection = true   # 1+1：第二张同费卡可来自任意组(含未激活)
	_apply_selection_shift()
	_raise_card(hc)   # 第一张：统一「抬起」视觉（上移+放大+置顶），与悬停一致
	# 第一张：呼吸灯染色 = 费用菱形颜色（即时蓝 00a1ff / 执行橙 ff8c33），据卡片 cost_type 区分费用类型；
	# 第二张卡保持灰（见 _pair_second）。无双色流动，单色状态区分干净。
	var _tint: Color = CardRoot.COST_INSTANT if (is_instance_valid(hc.card) and hc.card.cost_type == 0) else CardRoot.COST_EXECUTE
	hc.set_select_frame(false, _tint, _tint)
	card_selected.emit(hc)
	# [DEBUG] 选靶黑幕排查探针
	var _cn := "?"
	if is_instance_valid(hc.card):
		_cn = hc.card.card_name
	var _et := hc.data.effects_text if (is_instance_valid(hc.data)) else "<data null>"
	print("[HM] select_card name=%s owner_group=%s effects_text=%s" % [_cn, hc.owner_group, _et])
	# 选靶黑幕：按卡面行标签对非目标单位(自身 owner_group 对应单位除外)盖黑幕剪影。
	var br := _get_battle_root()
	print("[HM] battle_root valid=%s" % is_instance_valid(br))
	if is_instance_valid(br):
		var tag := _card_row_tag(hc)
		print("[HM] row_tag=%s" % tag)
		if tag != "":
			br.set_target_dim(tag, hc.owner_group)
		else:
			print("[HM] ⚠ 无行标签(前排/后排/同排/异排/全部) → 不盖黑幕")


## 取当前选中卡（BattleRoot 点单位时调用）。
func get_selected() -> HandCard:
	return _selected


## 选中卡对单位碰撞箱完成「使用」点击（BattleRoot 检测后调用）。
## 触发顺序：应用卡牌效果(BattleRoot) → 广播 card_used(供外部) → 弃牌飞走 → 清选复位。
func notify_used_on_unit(unit: UnitRoot) -> void:
	# 演出（插入特效）播放中：串行化，避免动画未结束就二次出牌导致 ATB 推进软锁。
	if _cutscene_playing:
		return
	if _selected == null or not is_instance_valid(unit):
		return
	var hc := _selected
	var tag := _card_row_tag(hc)
	var scope := _card_scope(hc)
	var cost := hc.cost   # 悬停预览用的同一费用字段，保证实际插队落点 = 预览落点
	var br := _get_battle_root()
	if is_instance_valid(br):
		br.apply_card_effect(hc, unit, tag, scope)
	card_used.emit(hc, unit)
	# 1+1：第二张同费卡不触发效果，成功打出后随主卡一起进弃牌堆；并按其角色随机抽一张。
	var paired := _paired_card
	var paired_role: String = ""
	if is_instance_valid(paired):
		paired_role = paired.owner_group
		_draw_one_for_role(paired_role)   # 按第二张卡角色随机抽一张飞入该角色组（返回新卡或 null）
		# 1+1 抽牌音：抽牌动作必响，不再绑定「是否真抽到新卡」——修正之前只有新卡才响的逻辑。
		SfxManager.play_random_draw()
		_discard_card(paired)
		_discard_card(hc)
		layout(true, false)   # 剩余手牌(含刚抽入的)静默重排，抽牌音已在上方播过
		_refresh_inactive()   # 新抽入的卡需按当前高亮框角色重算未激活压暗
	else:
		_discard_card(hc)
		# 普通打出（无抽牌）：剩余手牌仅静默重排，不播抽牌音。
		layout(true, false)
	# 有费用的卡：推进 ATB 高亮框内施法者单位——按费用插入悬停预览落点、结束其回合、轮到下一单位入框。
	# 0 费卡(即时)不插队、不推进（与「有费用的卡牌」规则一致）。
	clear_selection()
	# 播放插入演出：先构建施法者(主目标)+受击者(次目标)美术，交给 CutsceneController 编排
	# （A/B 方块滑入→中央慢速对位→触发帧特效+震动）；演出结束后再推进 ATB 高亮框内施法者单位。
	# 注意：clear_selection() 已把 _selected 置空，故用上方捕获的局部 hc 传入，避免 null。
	_play_insert_cutscene(hc, unit, cost)


## 播放插入演出（选中目标打出卡后触发）：构建施法者(主目标)+受击者(次目标)美术字典，
## 交由 CutsceneController（group "cutscene_controller"）编排 A/B 方块滑入+中央帧特效+震动。
## 演出结束（CutsceneController.finished）回调里再推进 ATB。找不到控制器则立即推进，避免回合卡死。
var _pending_cost: int = 0
## 插入演出播放中标记：置 true 期间拦截新的「选靶打出」，保证演出与 ATB 推进串行、不软锁。
var _cutscene_playing: bool = false

## 施法者美术态：攻击卡→Attack / 状态卡→Cast / 防御卡→Charge（与 CardData.card_type 对齐）。
func _caster_art_state(hc: HandCard) -> int:
	if not is_instance_valid(hc) or not is_instance_valid(hc.data):
		return 0   # IDLE
	match hc.data.card_type:
		0: return 1   # ATTACK
		1: return 2   # CAST
		2: return 4   # CHARGE
	return 0

## 受击者美术态：被攻击卡(0)命中→Hit；状态/防御卡命中→Idle（常态）。
func _target_art_state(hc: HandCard) -> int:
	if is_instance_valid(hc) and is_instance_valid(hc.data) and hc.data.card_type == 0:
		return 3   # HIT
	return 0   # IDLE

func _play_insert_cutscene(hc: HandCard, unit: UnitRoot, cost: int) -> void:
	var ctrl := get_tree().get_first_node_in_group("cutscene_controller") as CutsceneController
	if not is_instance_valid(ctrl):
		_advance_after_cutscene(cost)
		return
	# 施法者（主目标）= 卡牌归属角色对应的玩家单位（与 battle_root.apply_card_effect 同惯例）。
	var br := _get_battle_root()
	var caster := br._find_unit(hc.owner_group) if is_instance_valid(br) else null
	var caster_dict: Dictionary = {}
	if is_instance_valid(caster):
		caster_dict = {"id": caster.unit_id, "faction": caster.unit_faction, "state": _caster_art_state(hc)}
	# 次目标：被点击单位（自施法 target_type=Self 或点中自身时仅显示施法者）。
	var target_dict: Dictionary = {}
	var is_self: bool = (is_instance_valid(unit) and unit == caster) or (is_instance_valid(hc.data) and hc.data.target_type == "Self")
	if is_instance_valid(unit) and unit != caster and not is_self:
		target_dict = {"id": unit.unit_id, "faction": unit.unit_faction, "state": _target_art_state(hc)}
	if not ctrl.finished.is_connected(_on_cutscene_finished):
		ctrl.finished.connect(_on_cutscene_finished)
	_pending_cost = cost
	_cutscene_playing = true
	ctrl.play(caster_dict, target_dict, "player", cost)   # 玩家出牌 → 我方方向（不翻转）


## 演出结束回调：按暂存费用推进 ATB 高亮框内施法者单位。
func _on_cutscene_finished() -> void:
	_cutscene_playing = false
	_advance_after_cutscene(_pending_cost)
	_pending_cost = 0


## 推进 ATB：仅 cost>0 的卡（即时 0 费不插队、不推进，与「有费用的卡牌」规则一致）。
func _advance_after_cutscene(cost: int) -> void:
	var atb := _get_atb()
	if is_instance_valid(atb) and cost > 0:
		atb.advance_framed(cost)


## 取消选靶：清选中态、复位所有手牌位移、清 ATB 预览、清除选靶黑幕、广播 card_deselected。
func clear_selection() -> void:
	if _selected == null:
		return
	_selected = null
	_paired_card = null
	_hovered = null
	allow_inactive_selection = false   # 复位：恢复「未激活组不可选」
	_restore_all()
	var atb := _get_atb()
	if is_instance_valid(atb):
		atb.clear_preview()
	var br := _get_battle_root()
	if is_instance_valid(br):
		br.clear_all_dim()
	card_deselected.emit()


## 选中第一张后：所有「不同费」手牌下移 SELECT_SHIFT_Y；同费卡(含选中卡自身与其他同费卡)保持原位。
func _apply_selection_shift() -> void:
	if _selected == null:
		return
	var sel_cost: int = _selected.cost
	for c in _cards:
		if not (is_instance_valid(c) and c.state == HandCard.STATE_HAND):
			continue
		if c.cost == sel_cost:
			continue   # 同费卡牌不下移（1+1：可与第一张一起保持抬起）
		_shift_card_to(c, c.home_pos + Vector2(0.0, SELECT_SHIFT_Y))


## 所有在手牌复位到「待选」基准态（取消 / 打出后调用）。含缩放复位，避免抬起态的 hover_scale 残留。
func _restore_all() -> void:
	for c in _cards:
		if not (is_instance_valid(c) and c.state == HandCard.STATE_HAND):
			continue
		_lower_card(c)


## 把单卡 tween 到目标位置（杀掉旧 tween 避免抢 position），并复位 z 层级。
func _shift_card_to(c: HandCard, target: Vector2) -> void:
	_kill_card_tween(c)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(c, "position", target, 0.2)
	_card_tweens[c] = [tw]
	c.z_index = c.base_z


## 选靶黑幕用：从卡面 effects_text 解析首个行标签（前排/后排/同排/异排/全部）。无则空串(不盖黑幕)。
func _card_row_tag(hc: HandCard) -> String:
	if not is_instance_valid(hc) or hc.data == null:
		return ""
	for t in _ROW_TAGS:
		if hc.data.effects_text.contains("【%s】" % t):
			return t
	return ""

## 选靶效果用：从卡面 effects_text 解析范围标签（群体/单体）。无则默认 单体。
const _SCOPE_TAGS: Array[String] = ["群体", "单体"]
func _card_scope(hc: HandCard) -> String:
	if not is_instance_valid(hc) or hc.data == null:
		return "单体"
	for t in _SCOPE_TAGS:
		if hc.data.effects_text.contains("【%s】" % t):
			return t
	return "单体"

## 取得 BattleRoot（经 group，避免硬编码路径），用于触发/清除选靶黑幕。
func _get_battle_root() -> BattleRoot:
	return get_tree().get_first_node_in_group("battle_root") as BattleRoot


func _native_width() -> float:
	for c in _cards:
		if is_instance_valid(c):
			return c.get_native_width()
	return 256.0

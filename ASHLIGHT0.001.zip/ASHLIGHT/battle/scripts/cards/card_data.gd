class_name CardData
extends Resource

## 单张卡牌的静态数据（由 CardBaseInfo.xlsx 经 card_data_gen.gd 自动生成，运行时只读）。
## 字段命名对齐 CardBaseInfo.xlsx；数值类型对齐 CardRoot 的 @export（card_type/cost_type/rarity 均为 int）。

@export var id: String = ""
@export var card_name: String = ""
@export var belong_to: String = ""            # Zhouzhou / Irene / Rocket
@export var card_type: int = 0                # 0=攻击 1=状态 2=防御（对齐 CardRoot.card_type）
@export var cost_type: int = 0                # 0=即时(蓝) 1=执行(橙)（对齐 CardRoot.cost_type）
@export var cost_value: int = 1
@export var target_type: String = "SingleEnemy"   # SingleEnemy/AllEnemy/Self/SingleAlly/AllAlly
@export var target_row: String = "前排"        # 前排/后排/全部/同排/异排（静态近似，解析以 effects_text 为准）
@export var relative_row: bool = false        # 异排=true（命中与施法者相反排）
@export var rarity: int = 1                    # 1/2/3
@export var enhanced: bool = false
@export var art_id: String = ""                # 卡面文件名（无下划线，如 Zhouzhou001.png）
@export var effects_text: String = ""          # 效果标签原文，如 【前排】【单体】——解析权威来源
@export var keywords: String = ""
@export var description: String = ""

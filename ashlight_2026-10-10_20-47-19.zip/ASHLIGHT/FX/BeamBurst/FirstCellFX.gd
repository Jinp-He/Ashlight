extends BeamBurst
class_name FirstCellFX

## 首格特效组（First-Cell Effect）：基于 BeamBurst（白色光束扩散）旋转 90° 的变体。
## 单位格进入 ATB 首格（cell0）时触发：竖向光束自单位格中心向上/下爆开 + 粒子竖向迸发。
##
## 与 BeamBurst 完全一致，仅两处差异（均为「首格进入即一次性播放」语义）：
##   · angle_deg 默认 90.0  —— 横向光束 → 竖向光束（整组旋转 90°：光束 Sprite 旋转 + 粒子轴向随之变竖向）
##   · loop      默认 false —— 单次播放；播放结束本节点自动 queue_free()，无需手动 stop()
## 其余参数 / 数学 / 像素化 / 加法混合 全部继承自 BeamBurst（详见同目录 README_BeamBurst.md）。
##
## 集成（atb2_track 已在「单位进入 cell0」时自动实例化并 play；此处为独立使用说明）：
##   var fx := preload("res://FX/BeamBurst/FirstCellFX.tscn").instantiate() as FirstCellFX
##   get_parent().add_child(fx)
##   fx.global_position = unit_center_global_pos   # 单位格中心（世界坐标）
##   fx.play()
## 播放结束本节点自动释放，不残留。

func _ready() -> void:
	angle_deg = 90.0
	loop = false
	super._ready()


func _process(delta: float) -> void:
	super._process(delta)
	# 单次播放结束（loop=false → 父级 _process 把 _playing 置 false，且已播过至少一帧 _t>0）后自释放，避免节点残留。
	if not _playing and _t > 0.0:
		queue_free()

extends BeamBurst
class_name FirstCellEchoFX

## 首格特效组（回声·小版本）：基于 BeamBurst 的变体，专供【小回声格(EchoCell, 50×30)】使用。
##
## 与基础版 FirstCellFX（单位格，旋转 90° 竖向爆开）的差异：
##   · angle_deg 默认 0.0  —— 【不】旋转 90°：保持横向光束（与基础版的竖向相反），贴合小回声条「宽而薄」的形态。
##   · loop      默认 false —— 单次播放；播放结束本节点自动 queue_free()，无残留。
##   · 整体尺寸由 EchoCell.play_echo_fx 设为 0.5（缩小 50%）—— 不在此脚本内，由调用方对节点 scale 处理。
##
## 触发条件与基础版【不同】（核心区别）：
##   基础版 FirstCellFX：单位格「移动到首格(cell0)」时即触发（atb2_track._set_front 限流）。
##   本特效：小回声【不】在「移动到首格」时触发；只有当【堆叠上方的单位格（基础版回声 / UnitCell）】
##           播放执行其效果后，由轨道层链式触发其「演出 + 本特效」（见 atb2_track._chain_echo_fx）。
##   即「上方单位格演完 → 下方小版本回声随后爆开」的链式演出，而非独立的首格进入即播。

func _ready() -> void:
	angle_deg = 0.0
	loop = false
	super._ready()


func _process(delta: float) -> void:
	super._process(delta)
	# 单次播放结束（loop=false → 父级 _process 把 _playing 置 false，且已播过至少一帧 _t>0）后自释放，避免节点残留。
	if not _playing and _t > 0.0:
		queue_free()

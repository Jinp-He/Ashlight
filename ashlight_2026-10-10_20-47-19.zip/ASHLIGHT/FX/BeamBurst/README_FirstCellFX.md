# 首格特效组 · 单位进入首格竖向光束爆开（像素风）

基于 `BeamBurst`（白色光束扩散特效）旋转 **90°** 的变体，专用于「单位格进入 ATB 首格（cell0）」时的反馈特效。文件与 `BeamBurst` 同目录。

## 文件
- `FirstCellFX.gd` —— 主节点脚本（`Node2D`，`class_name FirstCellFX`，`extends BeamBurst`）
- `FirstCellFX.tscn` —— 已挂脚本的场景，节点名「首格特效组」，直接拖进场景树即可
- `README_FirstCellFX.md` —— 本说明

## 与 BeamBurst 的关系
首格特效组 = **BeamBurst 旋转 90°**。所有绘制 / 数学 / 像素化 / 加法混合逻辑完全继承自 `BeamBurst`，仅在两处改为「首格进入即一次性播放」语义：

| 项 | BeamBurst 默认 | 首格特效组 | 说明 |
|----|---------------|-----------|------|
| `angle_deg` | 0 | **90.0** | 横向光束 → 竖向光束（整组旋转 90°：光束 Sprite `rotation_degrees=90` + 粒子轴向随之变竖向迸发） |
| `loop` | true | **false** | 单次播放；播放结束本节点自动 `queue_free()`，不残留 |

> 旋转 90° 后：原本「横向、向左右两端爆开」的光束变为「竖向、向上下两端爆开」；粒子从「左右轴向」变为「上下轴向」。`length` 沿光束轴向（现为竖直方向）、`thickness` 为垂直厚度（现为水平方向），二者数值含义不变。

> **修正记录（2026-10-01）**：随 `BeamBurst` 一并修正了光束遮罩换算 bug（旧版光束中心发暗、两边亮 = 空心发灰，与网页不符）。修正后为**实心亮带 + 更亮的中心热核**，竖向预览见同目录 `Preview_BeamBurst_FirstCell_Vertical.png`。

## 集成方式

### 1. 自动触发（已收编为单位格模块化子节点）
首格特效组**不再**挂在 `Atb2Track` 上，而是作为「单位格自身」的模块化组成部分：

- `unit_cell.gd` 持有 `FIRST_CELL_FX_SCENE` 预加载常量，并提供方法 `play_first_cell_fx()`：
  每次调用都**重新实例化**一个 `FirstCellFX` 作为本单位格的**子节点**，`position = Vector2.ZERO`（即单位格居中共享锚点 = 单位格中心），`z_index = -2`（绘制于背景(-1)/美术(0)/边框(1) 之下，光束自单位格后方透出），然后 `play()`。
- `atb2_track.gd` 的 `_set_front` 在检测到「新单位（玩家 / 敌方，非回声 / 天气）进入 cell0」时，直接调用 `(e.node as UnitCell).play_first_cell_fx()`。
- 特效**随单位格一起移动 / 重排 / 移除**，居中对齐天然成立（无需再追踪单位全局坐标）。
- `FirstCellFX` 自身 `loop=false`，播放结束（约 `duration_ms`=800ms）自动 `queue_free()`；`UnitCell` 保留 `_first_cell_fx` 引用，再次进入 cell0 时先释放旧实例、再重建，保证**可重复触发**。
- 初次 `build_roster` 期间 `_loading=true` 不触发，避免进场即播；仅当单位**后续真正进入 cell0** 才播一次。

### 2. 手动使用（独立）
```gdscript
# 方式 A：挂在任意节点上（如旧 atb 轨道节点）
var fx := preload("res://FX/BeamBurst/FirstCellFX.tscn").instantiate() as FirstCellFX
get_parent().add_child(fx)
fx.global_position = unit.global_position   # 单位格中心（世界坐标）
fx.play()                                     # 播放结束自动 queue_free

# 方式 B：作为某单位格的模块化子特效（推荐，随单位格移动 / 重排）
unit_cell.play_first_cell_fx()
```

## 可调参数（@export，与 BeamBurst 完全一致）
| 参数 | 默认 | 说明 |
|------|------|------|
| `pixel_size` | 5 | 像素块大小，量化网格，越大越像素风 |
| `angle_deg` | 90 | 旋转角度（度）；首格特效固定竖向，一般不必改 |
| `length` | 100 | 最大长度（光束轴向全长，px） |
| `thickness` | 25 | 垂直厚度（全厚，px） |
| `burst` | 10 | 扩散缓动，越大首爆越快 |
| `duration_ms` | 800 | 持续时间（ms） |
| `alpha` | 1.0 | 整体亮度 |
| `core` | 0.29 | 核心加亮（中心亮线权重 0~1） |
| `particle_count` | 10 | 粒子数量（开场一次性迸发） |
| `particle_speed` | 0.60 | 粒子速度倍率 |
| `particle_bias` | 0.0 | 0=全向点缀，1=强轴向(上下)扩散 |

运行时改参数后下一次 `play()` 生效。渲染 / 数学 / 像素化 / 性能等细节同 `README_BeamBurst.md`（光束程序生成 `Image`+`ADD` 混合；粒子 `_draw` 方块 + `ADD`）。

## 未验证项
- 建议在引擎内打开 `FirstCellFX.tscn` 确认无报错（首次打开自动生成 `.uid`）。
- 真实观感（竖向爆开 + 粒子）需编辑器实机 playtest；headless 不跑 `_process`/tween，无法验证动画与自释放时序。

---

# 首格特效组（回声·小版本）· 横向光束爆开（小格专用）

基于 `BeamBurst` 的变体，专供【小版本回声块（EchoCell，50×30）】使用。与基础版 `FirstCellFX`（单位格 / 基础版回声，旋转 90° 竖向）是**平行的两个变体**，主要差异在「角度 / 尺寸 / 层级 / 触发时机」。

## 文件
- `FirstCellEchoFX.gd` —— 主节点脚本（`Node2D`，`class_name FirstCellEchoFX`，`extends BeamBurst`）
- `FirstCellEchoFX.tscn` —— 已挂脚本的场景，节点名「首格特效组_回声小版本」

## 与基础版 FirstCellFX 的差异（核心区别）

| 项 | 基础版 FirstCellFX（单位格） | 小版本 FirstCellEchoFX（回声·小版本） |
|----|------------------------------|----------------------------------------|
| `angle_deg` | **90.0**（竖向爆开） | **0.0**（横向爆开，【不】旋转 90°，贴合小回声条宽而薄形态） |
| 整体尺寸 | 1.0（原尺寸） | **1.0**（完整设计尺寸，不再缩小 50%；由 `EchoCell.play_echo_fx` 对节点 `scale` 处理，除以自身 scale 抵消 cell0 首格回声组 1.2 放大，保证视觉尺寸一致） |
| `z_index` | -2（绘制于单位格之下） | -2（绘制于回声块之下） |
| 触发时机 | 「**移动到首格(cell0)**」即触发（`atb2_track._set_front` 限流） | **【不】在移动到首格时触发**；当「**堆叠上方的回声（基础版 / 小版本）演完其「演出组」**」之后，由轨道层 `_play_and_remove_echoes` 连锁循环**链式触发**其演出 + 本特效 |
| 承载节点 | `UnitCell.play_first_cell_fx()` | `EchoCell.play_echo_fx()` |

## 链式触发逻辑（区别于基础版的关键）
- 基础版回声（以 `UnitCell` 尺寸渲染、`is_echo_override=true`，堆叠在列最上方）进入首格 → `_set_front` 触发其 `play_first_cell_fx()`（竖向光束）。
- 当该首格进入「回声自动播放」（`_maybe_auto_play` → `_play_and_remove_echoes`），轨道层按【列 → 列内自上而下（基础版 i=0 → 堆叠小版本 i≥1）】逐格演出：
  - 基础版（i==0）只演出其「演出组」（黑色矩形占位，见下），其首格特效已在进入首格时播过，此处不重复。
  - **堆叠小版本（i≥1，EchoCell）：必须等「本格上方（i-1）回声演完其演出组（`_perform_effect` 完成）后」**，才调用 `play_echo_fx()`（横向光束、完整尺寸、绘制于回声之下），并紧接演出其自己的「演出组」。
  - 由此形成「上一格演完 → 下一格爆开 + 演出」的链式演出；小版本**绝不**因「自身进入首格」而触发——它只在上方回声的演出组结束后才被带动。
- 仅在首格确实为「基础版回声（含下方小版本堆叠）」时触发；普通单位 / 敌方 / 天气进首格不会触发此链路（它们下方没有小版本回声）。

## 演出组占位（黑色矩形）
- 当前演出组**尚未接入**真实演出，`atb2_track._perform_effect(e)` 以「黑色矩形 1s」占位模拟：在演出目标上生成 `ColorRect`（尺寸 1.3× 目标、居中、`z_index=-3` 置于回声块之下，不遮挡上方光束），持续 1s 后 `queue_free()`。
- 真实演出接入时，把该黑色矩形占位替换为：按 `e` 的类型 / uid 触发对应演出并 `await` 演出完成即可；所有演出调用点（回声基础版 / 堆叠小版本 / 敌方 / 天气）统一走 `_perform_effect` 这一端口。

## 集成方式
- `echo_cell.gd` 持有 `ECHO_FX_SCENE` 预加载常量，并提供方法 `play_echo_fx()`：
  重新实例化 `FirstCellEchoFX` 作为本回声格子节点，`position=Vector2.ZERO`、`z_index=-2`、`scale=Vector2(1.0,1.0)/maxf(scale.x,0.001)`（抵消 cell0 首格回声组 1.2 放大，保证视觉尺寸一致），然后 `play()`。`FirstCellEchoFX` 自身 `loop=false` 播完自 `queue_free()`。

## 未验证项（同基础版）
- 真实观感（横向爆开 + 链式时序 + 完整尺寸 + 后方透出）需编辑器实机 playtest；headless 不跑 `_process`/tween/timer，无法验证动画与链式延时时序。

class_name MonsterDatabase
extends RefCounted

## 怪物数据表（单一来源）：每个怪物 unit_id → 数据字典。
## 接入点：BattleRoot._collect_roster_into_atb 初始化敌方单位时读取，赋值 HP 并装配意图袋。
##
## 字段说明：
##   max_hp      最大生命（初始化时赋值给 UnitRoot.max_hp / current_hp）。
##   intent_mode 意图袋抽取模式：
##                 "fixed" = 按 deck 顺序循环（战1单招固定用此）；
##                 "bag"   = 洗牌不连发（战2+ 多招怪物用此，两重击不相邻）；
##                 "random"= 回落旧的随机重掷占位（未配置数据表或 deck 为空时兼容）。
##   intent_deck 意图序列（Array[Dictionary]），每个意图的键对应 UnitRoot.set_intent 参数：
##                 {type, target_id, value, target_faction, target_range, scope, value_base}
##   speed_tier  速度档（行动后重入 ATB 的等待格数区间）："fast"=2-3 / "medium"=4-5 / "slow"=5-6
##                 （见「怪物设计总表」速度段；故意不含速度1，避免新回合即动）。
##                 初始化时由 BattleRoot 读入并赋值 UnitRoot.enemy_speed_tier。
##
## 数值以「怪物设计总表」为准（玩家基线 HP=100 / 输出4 / 护甲5 / Speed=3 为标尺，教学怪刻意压低）；本表与 A:\ASHlight\ai\调试文档\怪物设计总表.md 同步。
## 文档源：A:\ASHlight\ai\调试文档\怪物设计总表.md（统一模块化表格，所有怪物一行；通用规则只写一次）。

const MONSTERS: Dictionary = {
	# ── UID 001 · Remy（教学第一怪）──
	# 定位：引导玩家理解两个最基础的动词——「攻击造成伤害」「护盾抵挡伤害」。
	# 意图池：fixed 循环 [攻击, 防御]，telegraph 完全可预测，专用于教学读意图。
	# 数值取自总表示例（HP30 / 攻击5 / 护盾5），可后续按数值标尺微调。
	"Remy": {
		"max_hp": 30.0,                        # 教学第一怪：低血不可败，引导玩家体验首次掉血与护盾吸收
		"speed_tier": "fast",                   # 速度档：快（行动后等待 2-3 格，教学第一怪节奏明快）
		"intent_mode": "fixed",                 # 意图池轮流使用（顺序循环，完全可预测，专用于教学读意图）
		"intent_deck": [
			# 意图1·攻击：对玩家侧(敌方)单体造成 5 点伤害。telegraph 显形→教「攻击 = 造成伤害」。
			{"type": "att", "target_id": "front_monomer", "value": "1*5", "target_faction": "敌方", "target_range": 2, "scope": "单体", "value_base": ""},
			# 意图2·防御：自身(我方)获得 5 点护盾。telegraph 显形→教「护盾 = 抵挡伤害」（玩家攻击有盾目标时被吸收）。
			{"type": "shield", "target_id": "back_monomer", "value": "5", "target_faction": "我方", "target_range": 0, "scope": "单体", "value_base": ""},
		],
	},
	# ── UID 002 · Wangg（赃物 / 偷盾 教学怪）──
	# 定位：教玩家「赃物干扰手牌」与「敌人互偷盾」。条件式 AI（非随机）：计数器(意图1 用 2 次→出 2) + 事件旗(友方获盾→出 3)。
	# 美术：wangg；HP 30（占位，待数值标尺）；速度档 中（行动后等待 4-5 格）。
	# 意图池：conditional（裁决见 BattleRoot._wangg_pick_intent：优先级 3 偷盾 > 2 赃物 > 1 攻击）。
	# intent_key 由 BattleRoot._resolve_wangg_intent 解析专属行为：atk(攻击) / apply_loot(赃物不重复) / steal_shield(净转移护盾)。
	# 数值（攻击/层数）为占位，待数值标尺校准。
	"Wangg": {
		"max_hp": 30.0,                         # 占位：教学怪血量，待数值标尺定稿
		"speed_tier": "medium",                  # 速度档：中（行动后等待 4-5 格）
		"intent_mode": "conditional",            # 条件式：counter + event，见 _wangg_pick_intent
		"intent_deck": [
			# 意图2·施加赃物（开局必出）：沙漏A 敌对(单体) 2 层（跳过已持有赃物单位，不重复/不刷新）；计数器达 2 时再次出，用后清零计数。
			{"type": "state", "target_id": "loot_monomer", "value": "2", "target_faction": "敌方", "target_range": -1, "scope": "单体", "value_base": "", "intent_key": "apply_loot", "display": "单体，施加 %VALUE% 层赃物"},
			# 意图1·攻击：沙漏3 敌对(单体) 伤害。常态默认意图；每次使用 +1 计数器（累计达 2 → 下次出意图2）。
			{"type": "att", "target_id": "front_monomer", "value": "1*5", "target_faction": "敌方", "target_range": 3, "scope": "单体", "value_base": "", "intent_key": "atk", "display": "单体，造成 %VALUE% 点伤害"},
			# 意图3·偷取护盾：沙漏A 友方(非自身·单体) = 友方护盾量（净转移，不凭空生成）。友方获盾事件触发，用后消费旗。
			{"type": "state", "target_id": "friend_shielded_monomer", "value": "0", "target_faction": "我方", "target_range": -1, "scope": "单体", "value_base": "", "intent_key": "steal_shield", "display": "单体，夺取友方全部护盾"},
		],
	},
	# ── UID 003 · Grey（通用支援怪）──
	# 定位：通用支援怪，可在任意组合出现（不绑定赃物或特定搭档）。给全场（含玩家）范围1 护盾，
	# 玩家可"白嫖"护盾（刻意设计的收益窗口）；同时喂养 002(Wangg) 的偷盾（友军获盾）。
	# 美术：grey（Idle/Attack/Cast/Hit 四态 + ATB 占位 已就绪）；HP 待定（占位 40）；速度档 中。
	# 意图池：bag 洗牌不连发（三意图轮换：护盾 / 攻击单体 / 攻击群体）。数值（护盾值/伤害）为占位，待数值标尺。
	"Grey": {
		"max_hp": 40.0,                         # 占位：普通怪血量（设计标注待定），待数值标尺定稿
		"speed_tier": "medium",                  # 速度档：中（与 002 同速，给推拉教学反应时间）
		"intent_mode": "bag",                    # 意图池洗牌不连发（三意图轮换）
		"intent_deck": [
			# 意图1·护盾：沙漏1+ 全场（范围1 内所有单位含玩家都获护盾，玩家可白嫖）；设计刻意留的玩家收益窗口。
			{"type": "shield", "target_id": "", "value": "5", "target_faction": "全场", "target_range": 1, "scope": "群体", "value_base": "", "display": "全体，提供 %VALUE% 点护盾"},
			# 意图2·攻击：沙漏2 敌方(单体) 伤害。
			{"type": "att", "target_id": "front_monomer", "value": "1*5", "target_faction": "敌方", "target_range": 2, "scope": "单体", "value_base": "", "display": "单体，造成 %VALUE% 点伤害"},
		# 意图3·攻击：沙漏2+ 敌方(群体) 伤害；命中时若目标护盾不足以完全抵消（受到真实掉血=有效伤害），将该玩家【击退1格】（远离 cell0，行动延后）。
		# 群体伤害数值不变（1*4）；击退由 BattleRoot._resolve_enemy_intent 通过 intent_key 识别后调用 Atb2Track.retreat_unit 实现。
		{"type": "att", "target_id": "", "value": "1*4", "target_faction": "敌方", "target_range": 2, "scope": "群体", "value_base": "", "intent_key": "atk_range2_group_knock", "display": "群体，造成 %VALUE% 点伤害；未挡满者被击退1格"},
		],
	},
	# ── UID 004 · Mafe（精英）──
	# 定位：赃物/中毒体系的「施压者」。被动把场上已存在的【赃物】转化为【中毒】压力；自身靠【上毒】滚雪球。
	# 美术：mafe；HP 99（占位，待数值标尺定稿）；速度档 中（行动后等待 4-5 格）。
	# 意图池：bag 洗牌不连发；加权选择见 BattleRoot._mafe_pick_intent（无赃物时意图2 加权、有上毒时意图3 降权、避免连发）。
	# 意图键（intent_key）由 BattleRoot._resolve_mafe_intent 解析专属行为：被动/上毒加成/意图2 播种/意图4 前进。
	# 数值（伤害/层数）为占位，待数值标尺校准。
	"Mafe": {
		"max_hp": 99.0,                         # 占位：精英血量，待数值标尺定稿
		"speed_tier": "medium",                  # 速度档：中（行动后等待 4-5 格）
		"intent_mode": "bag",                    # 意图池洗牌不连发（四意图条件加权，见 _mafe_pick_intent）
		"intent_deck": [
		# 意图1·打队列最末端敌对单体（等待最久的玩家）。telegraph 全场弧（range -1）提示「会打一个玩家」。
		{"type": "att", "target_id": "backmost_hostile", "value": "3*2", "target_faction": "敌方", "target_range": -1, "scope": "单体", "value_base": "", "intent_key": "atk_backmost", "display": "单体，造成 %VALUE% 点伤害（锁定队尾玩家）"},
		# 意图2·范围2 敌对群体伤害 + 每个目标播种 1 层【赃物】（喂养被动/意图4；无赃物时加权至 3）。
		{"type": "att", "target_id": "", "value": "1*4", "target_faction": "敌方", "target_range": 2, "scope": "群体", "value_base": "", "intent_key": "atk_range2_loot", "display": "群体，造成 %VALUE% 点伤害，并为每个目标播种 1 层赃物"},
			# 意图3·自buff：自身 +5【中毒】 + 2【上毒】。telegraph 在 Mafe 自身预告【上毒】（有上毒时降权至 0.2）。
			{"type": "state", "target_id": "", "value": "", "target_faction": "", "target_range": 0, "scope": "单体", "value_base": "", "intent_key": "self_poison_up", "display": "自身，施加 5 层【中毒】与 2 层【上毒】"},
		# 意图4·范围3 敌对单体伤害；若目标带【赃物】，Mafe 自身前进 2（execute_end 消费 pending_atb_advance）。
		{"type": "att", "target_id": "", "value": "2*2", "target_faction": "敌方", "target_range": 3, "scope": "单体", "value_base": "", "intent_key": "atk_range3_loot_advance", "display": "单体，造成 %VALUE% 点伤害；若目标带赃物则自身前进 2"},
		],
	},
}

## 取怪物数据；未登记返回空字典（调用方据此回落到旧随机占位）。
static func get_data(id: String) -> Dictionary:
	if MONSTERS.has(id):
		return MONSTERS[id]
	return {}

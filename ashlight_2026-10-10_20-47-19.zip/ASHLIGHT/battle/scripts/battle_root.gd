class_name BattleRoot
extends Node2D

## 战斗场景根节点（战斗场景骨架）。
## 当前职责：持有三层背景节点（Background / Midground / Foreground）的引用，并在 _ready 统一设置各层 z_index，
## 确保绘制顺序为 Background（最底）→ Midground → Foreground（最顶）。
## 单位放置逻辑（原单位槽位）已按需求移除；后续由用户指定放置方案后再接入。

# 三层背景的 z_index：Background 在最底、Foreground 在最顶。
const Z_FAR: int = -20
const Z_MID: int = 0
const Z_NEAR: int = 20

## ════════════════════════════════════════════════════════════════
## 战场规则（BattlefieldRule）
##  - RULE_1_FRONT_BACK【已归档·规则一】：前后排逻辑标签定位（UnitRoot.is_back_row）。
##    单位的【物理 x 槽位】不随前后排改变；is_back_row 仅驱动 ① 索敌(前排/后排/同排/异排)
##    ② 敌方意图选靶 ③ move 卡翻转前后排。规则二下整套不再被调用（见各 [规则一·已归档] 区块）。
##  - RULE_2_ATB_ORDER【当前启用·规则二】：单位物理槽位 1-6 随 ATB 队列顺序实时排列——
##    我方 3→2→1、敌方 4→5→6（3/4 最靠近中线、面对面）；仅在该阵营 ATB 出现位移时触发重排、平滑滑动。
##    纯物理重排，与 is_back_row 完全解耦（规则二不读 is_back_row 做任何判定）。
## ════════════════════════════════════════════════════════════════
enum BattlefieldRule { RULE_1_FRONT_BACK, RULE_2_ATB_ORDER }
const ACTIVE_BATTLEFIELD_RULE: BattlefieldRule = BattlefieldRule.RULE_2_ATB_ORDER

## 规则二物理槽位：我方左 1/2/3（3 最靠敌方中线）、敌方右 4/5/6（4 最靠我方中线）。
## x 严格沿用现有 6 个 UnitRoot 槽位值、间距不变；y 沿用各单位当前 y（重排时仅改 x）。
const SLOT_X: Dictionary = {
	1: 310.0, 2: 480.0, 3: 650.0,
	4: 950.0, 5: 1120.0, 6: 1290.0,
}

## ── 🔥 全队共享连锁预算池（规则2·火计数）──
## 战斗内资源（随 Battle 场景重置，不进 Autoload）。所有玩家角色共用同一池：
## 花 🔥 减共享池、回复加共享池；🔥_MAX 默认 3，仅升级/条件提高。
const FIRE_MAX: int = 3
## 士气每层加成：加到「攻击牌」基础关键数值的增量（每1层 +1 点，用户 2026-10-06 确立）。
## 调参集中在此常量：想改成「士气2层→+1」就把 MORALE_PER_LAYER 设为 0 并改用 layers/2 等公式。
const MORALE_PER_LAYER: int = 1
## 团队共享 🔥 变化信号（remaining, max），供 HUD 实时刷新 pip。
signal fire_changed(remaining: int, max_val: int)
var _team_fire: int = FIRE_MAX
## 每单位「上回合结束后的等待格数」(= 该回合打出总费用和)，供其下次新回合激活时按 ceil(/3) 回复 🔥。
var _last_play_pos: Dictionary = {}
## 待结算效果队列（规则2·即时卡延后结算）：蓝卡(即时卡)在点牌瞬间只入队、不立即扣血，
## 待玩家演出组 finished（演出结束后）由 flush_deferred_effects() 统一结算，实现「掉血延后到演出后生效」。
## 每个元素为 {"stat","value","hits","targets"(Array[UnitRoot]),"caster"}，value 已含连锁倍率 M(n)。
var _pending_effects: Array[Dictionary] = []
## 特殊卡待结算队列：special 标识的卡走专属逻辑（位移/集士气/记录伤害等），与即时卡同帧在演出结束后统一落点。
## 每个元素为 {"cd":CardData,"caster":UnitRoot,"target":UnitRoot,"mult":float}。
var _pending_special: Array[Dictionary] = []
## 本场战斗「同名卡最高伤害记录」（E2 十步杀一人滚雪球用）：key=卡 id，value=历史最高伤害。
var _damage_record: Dictionary = {}

## 演出组容器（独立 CutsceneController + CutsceneInsert，播完自毁）。
## 敌方 ATB 回合驱动时 spawn 一个，按怪物意图随机组合单位播放视觉演出。
const CUTSCENE_GROUP_SCRIPT := preload("res://battle/scripts/cutscene/cutscene_group.gd")
## 演出组串行调度器（方案甲）：四路生成点统一过它，保证同一时刻仅一个演出组在播。
const CUTSCENE_DIRECTOR_SCRIPT := preload("res://battle/scripts/cutscene/cutscene_director.gd")
## 触发提示组（真实「出血」触发 + DEV 测试按钮共用）。
const TRIGGER_PROMPT_SCRIPT := preload("res://battle/scripts/units/trigger_prompt.gd")
## 触发提示组图层：高于战斗世界(默认0)、低于手牌 UI(≈2000)。出血等真实触发与 DEV 调试共用。
const TRIGGER_LAYER: int = 70

@onready var layer_far: Node2D = get_node("Background") as Node2D
@onready var layer_mid: Node2D = get_node("Midground") as Node2D
@onready var layer_near: Node2D = get_node("Foreground") as Node2D
@onready var atb_track: Atb2Track = get_node("ATB/AtbTrack") as Atb2Track
## 演出组串行调度器实例（_ready 内创建），四路演出生成点统一过它，杜绝同帧多组叠放。
var cutscene_director: CutsceneDirector

## 单位组容器引用（_collect_roster_into_atb 中缓存，供 _process 每帧命中测试）。
var _units: Node2D
## 当前「聚光」单位 uid（每帧权威重算，见 _process）。空串=无聚光，全部彩色。
var _spot_uid: String = ""

const FIRE_HUD_SCRIPT := preload("res://battle/scripts/fire_hud.gd")
## 🔥 HUD 绘制层级：置于所有战斗元素之上（背景 -20~20 / 手牌 0 / 按钮 100 之下为常理，
## 此处取极大值确保恒在最顶，不被手牌或按钮遮挡）。
const FIRE_HUD_Z: int = 3000

func _ready() -> void:
	add_to_group("battle_root")   # 供 HandManager 经 group 取得本节点（与 hand_manager 组对称），避免硬编码路径
	_apply_layer_order()
	# 牌库初始化（先于 ATB 回合抽牌）：收集玩家角色，为每个角色建 抽/弃 牌堆。
	var hm_pre := get_tree().get_first_node_in_group("hand_manager") as HandManager
	if is_instance_valid(hm_pre):
		var proles: Array[String] = []
		var units_pre := get_node_or_null("Units")
		if units_pre != null:
			for u in units_pre.get_children():
				if u is UnitRoot and u.unit_faction == "player" and not proles.has(u.unit_id):
					proles.append(u.unit_id)
		if proles.is_empty():
			proles = ["Zhouzhou"]   # 兜底：场景至少有一个玩家单位
		hm_pre.init_decks(proles)
		# 同步发开局手牌（在 ATB start_turn 抽首回合牌之前，_cards 仍为空 → 走干净的开局分支，无 timer await 卡死）。
		hm_pre.draw_opening()
	_collect_roster_into_atb()
	_damage_record.clear()   # 新一场战斗：清空「同名卡最高伤害」记录（E2 滚雪球）
	# [规则一·已归档] 仅规则一随机前后排；规则二下定位由 ATB 队列顺序驱动，不调用。
	if ACTIVE_BATTLEFIELD_RULE == BattlefieldRule.RULE_1_FRONT_BACK:
		_randomize_unit_rows()
	_spawn_fire_hud()
	_spawn_dev_trigger_button()   # [DEV] 临时调试：随机触发单位的触发提示组（上线前移除）
	# 演出组串行调度器：四路生成点统一过它，保证同一时刻仅一个演出组在播。
	var dir := CUTSCENE_DIRECTOR_SCRIPT.new() as CutsceneDirector
	if is_instance_valid(dir):
		add_child(dir)
		cutscene_director = dir

## [DEV] 临时调试按钮：点击随机触发一个在场单位的触发提示组（上线前移除）。
func _spawn_dev_trigger_button() -> void:
	var layer := CanvasLayer.new()
	layer.name = "TriggerLayer"
	layer.layer = TRIGGER_LAYER
	add_child(layer)
	var btn := Button.new()
	btn.name = "DevTriggerButton"
	btn.text = "随机触发提示"
	btn.position = Vector2(20.0, 840.0)
	btn.size = Vector2(200.0, 44.0)
	btn.pressed.connect(_on_dev_trigger_pressed)
	layer.add_child(btn)

## [DEV] 随机取一个在场单位，随机用「被动 / 出血」触发条件生成提示组（上线前移除）。
func _on_dev_trigger_pressed() -> void:
	var units := _get_units()
	if units.is_empty():
		return
	var u: UnitRoot = units[randi() % units.size()]
	var t := TriggerPrompt.TriggerType.PASSIVE if randi() % 2 == 0 else TriggerPrompt.TriggerType.BLEED
	_spawn_trigger_prompt(u.unit_id, t, u.unit_faction)

## 生成并弹出一个触发提示组（真实「出血」触发 与 DEV 调试按钮共用）。
## unit_id 取该单位 02 美术；trigger_type 决定文本（被动！/出血！）；faction 决定滑入方向（我方左/敌方右）。
## 加进 TriggerLayer（layer=TRIGGER_LAYER，高于战斗世界、低于手牌 UI）。
func _spawn_trigger_prompt(unit_id: String, trigger_type: TriggerPrompt.TriggerType, faction: String) -> void:
	var prompt := TRIGGER_PROMPT_SCRIPT.new() as TriggerPrompt
	if not is_instance_valid(prompt):
		return
	prompt.setup(unit_id, trigger_type, faction)
	var layer := get_node_or_null("TriggerLayer") as CanvasLayer
	if layer == null:
		layer = CanvasLayer.new()
		layer.name = "TriggerLayer"
		layer.layer = TRIGGER_LAYER
		add_child(layer)
	layer.add_child(prompt)

## 引导/执行卡打出时的「触发提示」：显示施法者 02 美术 + 卡名，作为「本卡已排队、待生效回合才播演出组」的提示。
## 加进 TriggerLayer（与出血/中毒真实触发提示共用图层）。faction 决定滑入方向（我方左/敌方右）。
func _spawn_card_played_prompt(unit_id: String, card_name: String, faction: String) -> void:
	var prompt := TRIGGER_PROMPT_SCRIPT.new() as TriggerPrompt
	if not is_instance_valid(prompt):
		return
	prompt.setup_card(unit_id, card_name, faction)
	var layer := get_node_or_null("TriggerLayer") as CanvasLayer
	if layer == null:
		layer = CanvasLayer.new()
		layer.name = "TriggerLayer"
		layer.layer = TRIGGER_LAYER
		add_child(layer)
	layer.add_child(prompt)

## 创建 🔥 共享池 HUD（3 pip 火焰动画；美术 = assets/Unit UI/Fire_Chain.png，白色剪影 modulate 染火橙），锚定屏幕左上角。
## 仅规则2·🔥火计数 需要此 HUD；规则1·同色or同费 无 🔥 池，不生成（"去除🔥组"）。
func _spawn_fire_hud() -> void:
	var hm := get_tree().get_first_node_in_group("hand_manager") as HandManager
	if is_instance_valid(hm) and hm.chain_rule != HandManager.ChainRule.FIRE:
		return
	var hud := FireHud.new()
	hud.z_index = FIRE_HUD_Z
	add_child(hud)

## 统一设置三层背景的绘制层级（单一真相来源，避免散落在 .tscn 里）。
func _apply_layer_order() -> void:
	if is_instance_valid(layer_far):
		layer_far.z_index = Z_FAR
	if is_instance_valid(layer_mid):
		layer_mid.z_index = Z_MID
	if is_instance_valid(layer_near):
		layer_near.z_index = Z_NEAR


## 收集 Units 子节点的 UnitRoot 节点，喂给 ATB 轨道，使 ATB 插图与战斗单位联动。
## 联动方向：Units（单一真相来源）→ AtbTrack.start_turn，避免两份硬编码名册。
## 联动后：逐一对【敌方】单位读取其意图（type/target/value），经 AtbTrack.apply_enemy_intent
## 同步给对应 ATB 部件，使 ATB 的敌人意图图标与 battle 单位的意图图标完全一致。
func _collect_roster_into_atb() -> void:
	if not is_instance_valid(atb_track):
		return
	var units := get_node_or_null("Units") as Node2D
	if units == null:
		return
	_units = units
	var nodes: Array = []
	for u in units.get_children():
		if u is UnitRoot:
			nodes.append(u)
	# 高亮框(第0格)占据单位变化 → 转发给 HandManager 动态扩/缩手牌组间距（连接一次，防重复）。
	if not atb_track.framed_changed.is_connected(_on_atb_framed_changed):
		atb_track.framed_changed.connect(_on_atb_framed_changed)
	# 敌方 ATB 回合信号 → 播放怪物演出组（连接一次，防重复）。
	if not atb_track.enemy_action_started.is_connected(_on_enemy_action_started):
		atb_track.enemy_action_started.connect(_on_enemy_action_started)
	# 战场规则二：ATB 队列位移信号 → 重排该阵营物理槽位（连接一次，防重复）。
	if not atb_track.queue_reorder.is_connected(_on_atb_reorder):
		atb_track.queue_reorder.connect(_on_atb_reorder)
	# 引导卡回声真实演出回调（atb2 版）：回声进 cell0 首格时经本信号回调播真实 CutsceneGroup + 结算，
	# 完成后 BattleRoot 调 complete_echo_effect() 唤醒 atb2 继续淡出 + 推进（取代 atb1 的 _trigger_guide_echo 分支）。
	if not atb_track.echo_effect_requested.is_connected(_on_echo_effect_requested):
		atb_track.echo_effect_requested.connect(_on_echo_effect_requested)
	# 队列「前进一格」信号 → 逐格结算 DoT（如出血）：单位每次从 cellN 前移到 cellN-1 即触发一次。
	if not atb_track.units_advanced.is_connected(_on_units_advanced):
		atb_track.units_advanced.connect(_on_units_advanced)
	atb_track.start_turn(nodes)
	# 敌方意图联动：
	# ① 初始同步；② 信号绑定 UnitRoot.intent_changed → AtbTrack.apply_enemy_intent，
	#    之后战斗单位意图实时变更时，ATB 对应部件自动跟随（向上广播、向下不依赖 parent）。
	for u in units.get_children():
		if u is UnitRoot:
			var root := u as UnitRoot
			# 死亡信号：单位血条清零 → 从 ATB 移除对应单位格并触发站位重排（玩家 / 敌方均连接）。
			if not root.died.is_connected(_on_unit_died):
				root.died.connect(_on_unit_died)
			# buff 变化信号（含士气增减）→ 实时刷新该角色手牌上的攻击牌数值显示。
			if not root.buffs_changed.is_connected(_on_unit_buffs_changed):
				root.buffs_changed.connect(_on_unit_buffs_changed)
			if root.unit_faction == "enemy":
				# 怪物数据驱动初始化：从 MonsterDatabase 读 HP 与意图袋（取代旧随机占位）。
				var md: Dictionary = MonsterDatabase.get_data(root.unit_id)
				if not md.is_empty():
					var mhp: float = md.get("max_hp", root.max_hp)
					root.max_hp = mhp
					root.current_hp = mhp
					var deck: Array = md.get("intent_deck", [])
					if not deck.is_empty():
						root.set_intent_deck(deck, md.get("intent_mode", "fixed"))
					# 速度档：从数据库读入并写入 UnitRoot（驱动行动后重入 ATB 的等待格数区间）。
					root.enemy_speed_tier = md.get("speed_tier", "medium")
				var info: Dictionary = root.get_intent()
				if info.get("type", "") != "":
					atb_track.apply_enemy_intent(root.unit_id, info["type"], info["target"], info["value"])
				if is_instance_valid(atb_track):
					root.intent_changed.connect(atb_track.apply_enemy_intent)
	# 联动 hover 改由 BattleRoot._process 每帧权威命中测试驱动（见 _process / _apply_spot），
	# 不再依赖各部件/单位的 mouse_entered/exited（快速移动会漏发 exit，导致高亮卡死）。


## ── 战场规则二：ATB 队列顺序 → 物理槽位 1-6 映射 ──
## 仅在 ACTIVE_BATTLEFIELD_RULE == RULE_2_ATB_ORDER 时生效；规则一下此函数直接 return。
## faction="all" 重算双方；否则仅重算发生位移的阵营（互不干扰）。
func _recompute_battlefield_positions(faction := "all", animate := true) -> void:
	if ACTIVE_BATTLEFIELD_RULE != BattlefieldRule.RULE_2_ATB_ORDER:
		return
	if not is_instance_valid(atb_track):
		return
	if faction == "all" or faction == "player":
		_assign_faction_slots(atb_track.get_faction_order("player"), [3, 2, 1], animate)
	if faction == "all" or faction == "enemy":
		_assign_faction_slots(atb_track.get_faction_order("enemy"), [4, 5, 6], animate)

## order: 该阵营 unit_id【前→后】；slots: 对应物理槽位号（我方 [3,2,1] / 敌方 [4,5,6]）。
## 仅改 x（槽位间距/值沿用），y 保持单位当前值；animate=true 平滑滑动、false 瞬移。
func _assign_faction_slots(order: Array[String], slots: Array[int], animate: bool) -> void:
	for i in order.size():
		if i >= slots.size():
			break   # 当前每阵营固定 3 单位；溢出者保持原位
		var unit := _find_unit(order[i])
		if not is_instance_valid(unit):
			continue   # 测试场景 ATB 含无对应战斗单位的部件 → 跳过
		var target_x: float = SLOT_X.get(slots[i], unit.position.x)
		var dest := Vector2(target_x, unit.position.y)
		if animate:
			var tw := create_tween()
			tw.tween_property(unit, "position", dest, 0.35).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
		else:
			unit.position = dest

## ATB 队列位移 → 规则二重排该阵营物理槽位（仅位移方重算，互不干扰）。
func _on_atb_reorder(faction: String) -> void:
	_recompute_battlefield_positions(faction, true)


## 战斗是否已进入结束态（胜负判定一次性触发，避免重复）。
var _battle_ended: bool = false

## 单位死亡回调（UnitRoot.died 信号）：从 ATB 队列按 uid 移除对应单位格，并重排该阵营物理槽位。
func _on_unit_died(uid: String) -> void:
	if is_instance_valid(atb_track):
		atb_track.remove_unit_by_uid(uid)
	# 单位在其自身回合演出期间死亡（如出血致死）：取消其演出组，避免其结算回调(execute_end) 在
	# remove_unit_by_uid 已推进 ATB 并重新框定下一位之后，再去误动当前框定单位导致队列错位 / 卡死。
	# 精准按 uid 命中，不影响其它单位正在播放的演出组。
	if is_instance_valid(cutscene_director):
		cutscene_director.cancel_for_uid(uid)
	_check_battle_end()   # 任意单位死亡后检测胜负（敌方全灭→胜 / 玩家全灭→败）

## 最小胜负判定（教程/通用）：敌方全灭→胜、玩家全灭→败。已结束则跳过。
## 注意：死亡单位节点仍留在 Units 下（仅从 ATB 移除），故按 current_hp>0 过滤存活。
func _check_battle_end() -> void:
	if _battle_ended:
		return
	var units := _get_units()
	var enemy_alive := 0
	var player_alive := 0
	for u in units:
		if not (u is UnitRoot):
			continue
		var ur := u as UnitRoot
		if not is_instance_valid(ur) or ur.get_current_hp() <= 0.0:
			continue
		if ur.unit_faction == "enemy":
			enemy_alive += 1
		else:
			player_alive += 1
	if enemy_alive == 0:
		_battle_ended = true
		_on_battle_won()
	elif player_alive == 0:
		_battle_ended = true
		_on_battle_lost()

## 战斗胜利（敌方全灭）。最小切片仅打印 + 暂停 ATB；后续接结算/经验/UI。
func _on_battle_won() -> void:
	print("[Battle] 战斗胜利：敌方单位全灭。")
	if is_instance_valid(atb_track) and atb_track.has_method("pause_turn"):
		atb_track.pause_turn()

## 战斗失败（玩家全灭）。最小切片仅打印 + 暂停 ATB；教程战1 因低伤设计不可达。
func _on_battle_lost() -> void:
	print("[Battle] 战斗失败：玩家单位全灭。")
	if is_instance_valid(atb_track) and atb_track.has_method("pause_turn"):
		atb_track.pause_turn()


## 单位 buff 变化（含士气增减）→ 实时刷新该角色手牌上「攻击牌」的关键数值显示。
func _on_unit_buffs_changed(unit_id: String) -> void:
	var hm := get_tree().get_first_node_in_group("hand_manager") as HandManager
	if is_instance_valid(hm):
		hm.refresh_morale_text_for_role(unit_id)


## 队列「前进一格」回调：对本次前移的每一个单位各结算一次出血 DoT（逐格 tick）。
## advanced_uids 由 atb2 的 _shift_left 每左移一格发出（含进入 cell0 的单位；cell0 行动者已离场不在此列）。
## 对每个 uid 用 call_deferred 调 _tick_bleed，避免在 ATB _shift_left 信号栈内同步改动队列
## （若出血致死，死亡移除会触发 _advance_queue 重排，须等当前信号栈清空后再执行，防止重入死锁）。
func _on_units_advanced(advanced_uids: Array[String]) -> void:
	for uid in advanced_uids:
		var unit := _find_unit(uid)
		if is_instance_valid(unit):
			_tick_bleed.call_deferred(unit)


## 出血 DoT 结算：持有单位「前进一格」（从 cellN 移到 cellN-1，含进入 cell0）时，按当前出血层数受到伤害，并减少 1 层。
## 与攻击结算区分：出血伤害【不消耗士气】——走 UnitRoot.damage 直扣，不经 _apply_stat 的士气清除分支。
## 层数归零(无出血)直接 return；每次 tick 扣 1 层（层数≤1 时本 tick 后清零）；HP 清零 → 触发死亡演出。
## 由 _on_units_advanced(队列前进一格)经 call_deferred 调用，确保不卡在 ATB _shift_left 信号内（若出血致死，死亡移除会触发 _advance_queue 重排队列）。
func _tick_bleed(unit: UnitRoot) -> void:
	if not is_instance_valid(unit):
		return
	var stacks: int = unit.get_buff_stacks("bleed")
	if stacks <= 0:
		return
	var dealt := unit.damage(stacks)               # 护盾优先吸收，返回真实掉血量
	unit.spawn_tick_damage("出血", int(dealt))
	print("[BR-bleed] %s 出血结算：受到 %d 点伤害（层数=%d → 本 tick 后 -1）" % [unit.unit_id, int(dealt), stacks])
	# 出血触发提示组：单位前进(进高亮框)时按出血量受伤 → 弹出「出血！」（按阵营决定滑入方向）。
	_spawn_trigger_prompt(unit.unit_id, TriggerPrompt.TriggerType.BLEED, unit.unit_faction)
	unit.remove_buff_stacks("bleed", 1)   # 每次推进 -1 层
	if unit.get_current_hp() <= 0.0:
		unit.die()


## 中毒 DoT 结算：持有单位「每次行动后」（敌方=意图结算完毕 / 我方=角色打出卡并推进）按当前中毒层数受到伤害。
## 护盾 1:1 抵消层数：先以护盾吸收伤害，每吸收 1 点同时移除 1 层中毒（净转移——护盾点数直接抹掉等量层数）；
## 护盾不足覆盖的部分才转为血量伤害。中毒【不自动衰减】（层数仅由护盾抵消或受治疗/清除移除），
## 与出血（逐格 -1）形成差异：中毒是「持续压力、护盾为解药」，出血是「位移消耗、越走越淡」。
## 护盾耗尽后：剩余层数全额打血量（不再额外 -1，层数保持不变 → 下次行动仍按满层结算，直至被护盾/清除消解）。
## 由 _on_enemy_cutscene_done / HandManager.notify_used_on_unit 在「单位行动完毕」后调用。
func _tick_poison(unit: UnitRoot) -> void:
	if not is_instance_valid(unit):
		return
	var stacks: int = unit.get_buff_stacks("poison")
	if stacks <= 0:
		return
	var shield: float = unit.get_shield()
	var absorbed: int = mini(stacks, int(shield))
	if absorbed > 0:
		unit.reduce_shield(float(absorbed))          # 护盾 -absorbed
		unit.remove_buff_stacks("poison", absorbed)   # 中毒 -absorbed（1:1 抵消层数）
		stacks -= absorbed
		print("[BR-poison] %s 中毒结算：护盾抵消 %d 层（剩余层数=%d，护盾=%d）" % [unit.unit_id, absorbed, stacks, int(shield) - absorbed])
	if stacks > 0:
		var dealt := unit.damage(stacks)              # 护盾优先吸收，返回真实掉血量
		unit.spawn_tick_damage("中毒", int(dealt))
		print("[BR-poison] %s 中毒结算：受到 %d 点血量伤害（层数=%d）" % [unit.unit_id, int(dealt), stacks])
	# 中毒触发提示组：单位行动后中毒发作 → 弹出「中毒！」（按阵营决定滑入方向）。
	_spawn_trigger_prompt(unit.unit_id, TriggerPrompt.TriggerType.POISON, unit.unit_faction)
	if unit.get_current_hp() <= 0.0:
		unit.die()


## 每帧权威命中测试：决定当前「聚光」单位 uid（ATB 部件优先于单位组，二者视觉不重叠时取任一处）。
## 仅当聚光 uid 变化时才更新 ATB 压暗与单位组反向描边，避免每帧重启动画。
## 采用「每帧从头判定」而非信号，是因为 Godot 在鼠标快速移动时会漏发 mouse_exited，
## 导致离开的单位/部件卡在「高亮/黑叠」态——此处在每帧重算可彻底消除该残留。
func _process(_delta: float) -> void:
	if not is_instance_valid(atb_track) or not is_instance_valid(_units):
		return
	var mp := get_global_mouse_position()
	var uid := ""
	# ATB 部件（视觉在最高层 z=40）优先
	for p in atb_track.get_parts():
		if is_instance_valid(p) and p.is_point_inside(mp):
			uid = p.unit_uid
			break
	if uid == "":
		for u in _units.get_children():
			if u is UnitRoot and (u as UnitRoot).is_point_inside(mp):
				uid = (u as UnitRoot).unit_id
				break
	if uid != _spot_uid:
		_apply_spot(uid)


## 应用聚光变化：清除上一个单位的反向描边、点亮新单位（若有）、并刷新 ATB 压暗。
func _apply_spot(uid: String) -> void:
	if _spot_uid != "":
		var prev := _find_unit(_spot_uid)
		if is_instance_valid(prev):
			prev.set_external_highlight(false)
	_spot_uid = uid
	if uid != "":
		var cur := _find_unit(uid)
		if is_instance_valid(cur):
			cur.set_external_highlight(true)
	if is_instance_valid(atb_track):
		atb_track.set_spotlight(uid)


## 选靶中使用：选中卡后左键点单位碰撞箱(UnitRoot.is_point_inside，即 _spot_uid) → 触发「使用」过程。
## 当前无效果：仅通知 HandManager 完成一次使用（广播 card_used + 复位手牌位移）；效果实装由 card_used 信号接。
## 右键取消与位移复位在 HandManager 内处理，本节点不重复。
func _input(event: InputEvent) -> void:
	if not (event is InputEventMouseButton):
		return
	var mb := event as InputEventMouseButton
	if not mb.pressed or mb.button_index != MOUSE_BUTTON_LEFT:
		return
	var hm := get_tree().get_first_node_in_group("hand_manager") as HandManager
	if not is_instance_valid(hm):
		return
	if hm.get_selected() == null:
		return
	if _spot_uid == "":
		return
	var unit := _find_unit(_spot_uid)
	if not is_instance_valid(unit):
		return
	# 点中黑幕单位(非目标) → 不可作为卡牌作用对象，吞掉本次点击（与黑幕规则一致：黑幕=不可选）。
	if unit.is_dimmed():
		return
	hm.notify_used_on_unit(unit)


## ── 🔥 共享池查询 / 消耗 / 回复（规则2·火计数 §2/§5）──
func get_team_fire() -> int:
	return _team_fire

## 消耗 n 点 🔥（链环卡每张 1 点）。不足则返回 false（调用方据此拒绝加链）。
func spend_fire(n: int) -> bool:
	if n <= 0:
		return true
	if _team_fire < n:
		return false
	_team_fire -= n
	fire_changed.emit(_team_fire, FIRE_MAX)
	return true

## 退回 n 点 🔥 入共享池（取消选靶时把已花在链环上的 🔥 退回；本回合未实际打出）。
func refund_fire(n: int) -> void:
	if n <= 0:
		return
	_team_fire = clampi(_team_fire + n, 0, FIRE_MAX)
	fire_changed.emit(_team_fire, FIRE_MAX)

## 记录某单位本回合打出的总费用和（= ATB 等待格数），供其下次新回合按 ceil(/3) 回复 🔥。
func record_play_pos(uid: String, pos: int) -> void:
	_last_play_pos[uid] = pos

## 角色新回合(回到 cell0)时按「上回合等待格数」回复 🔥 入共享池。仅玩家阵营角色贡献（🔥 是玩家队资源）。
func _recover_fire_on_activate(uid: String) -> void:
	if not _last_play_pos.has(uid):
		return
	var pos: int = _last_play_pos[uid]
	var recover: int = clampi(int(ceilf(float(pos) / 3.0)), 0, FIRE_MAX)
	if recover <= 0:
		return
	_team_fire = clampi(_team_fire + recover, 0, FIRE_MAX)
	fire_changed.emit(_team_fire, FIRE_MAX)

## 按 unit_id 在 Units 子节点中查找对应 UnitRoot（联动的唯一真相来源，不缓存引用避免场景重置失效）。
func _find_unit(uid: String) -> UnitRoot:
	var units := get_node_or_null("Units") as Node2D
	if units == null:
		return null
	for u in units.get_children():
		if u is UnitRoot and (u as UnitRoot).unit_id == uid:
			return u as UnitRoot
	return null

## 返回战斗中所有 UnitRoot（缓存 _units 失效时回退重新查找）。供选靶黑幕枚举用。
func _get_units() -> Array[UnitRoot]:
	if not is_instance_valid(_units):
		_units = get_node_or_null("Units") as Node2D
	var out: Array[UnitRoot] = []
	if not is_instance_valid(_units):
		return out
	for u in _units.get_children():
		if u is UnitRoot:
			out.append(u as UnitRoot)
	return out

## 按 unit_id 查找场上单位（护盾预填 / 索敌辅助用）。找不到返回 null。
func _find_unit_by_id(uid: String) -> UnitRoot:
	for u in _get_units():
		if u.unit_id == uid:
			return u
	return null

## ── 规则2 攻击范围索敌（取代规则一前后排标签）──
## 相对施法者 caster 的 target_faction(敌方/我方/全场) + target_range(从 cell0 向前连续格数，-1=全场)。
## caster 即当前行动单位（恒在 ATB 第0格=高亮框），故 base = caster 所在 cell（通常为 0）；
## target_range<0 取该阵营全部单位；否则取 cells[base, base+range] 内符合 eff_faction 的单位。
## 返回解析出的候选 UnitRoot 列表（单体/群体 由调用方决定取其一或全取）。
func resolve_targets_by_range(caster: UnitRoot, target_faction: String, target_range: int, scope: String) -> Array[UnitRoot]:
	var out: Array[UnitRoot] = []
	if not is_instance_valid(caster) or not is_instance_valid(atb_track):
		return out
	var caster_faction: String = caster.unit_faction
	var eff_faction: String
	match target_faction:
		"敌方": eff_faction = "enemy" if caster_faction == "player" else "player"
		"我方": eff_faction = caster_faction
		"全场", _: eff_faction = ""   # 全部阵营
	var base: int = atb_track.get_unit_cell(caster.unit_id)
	var lo: int = base
	var hi: int
	if target_range < 0:
		hi = atb_track.cell_count - 1
	else:
		hi = mini(base + target_range, atb_track.cell_count - 1)
	var uids := atb_track.get_cell_unit_ids(lo, hi)
	for uid in uids:
		var u := _find_unit(uid)
		if not is_instance_valid(u):
			continue
		if eff_faction != "" and u.unit_faction != eff_faction:
			continue
		out.append(u)
	return out


## 选靶黑幕（规则2）：按攻击范围把「未命中单位」盖黑幕——候选(范围内目标阵营)亮、其余盖；施法者自身恒亮；
## target_range<0(全场)则全部亮（不盖）。scope 仅取 "群体" 以拿到该阵营范围内全部候选用于点亮。
func set_target_dim_by_range(target_faction: String, target_range: int, self_id: String) -> void:
	var caster := _find_unit(self_id)
	var candidates := resolve_targets_by_range(caster, target_faction, target_range, "群体")
	for u in _get_units():
		var ur := u as UnitRoot
		if not is_instance_valid(ur):
			continue
		var is_self: bool = is_instance_valid(caster) and ur == caster
		var lit: bool = is_self or target_range < 0 or candidates.has(ur)
		ur.set_dimmed(not lit)


## 【规则一·已归档】选靶黑幕：按 前排/后排/同排/异排/全部 标签判定，依赖 UnitRoot.is_back_row。
## 规则二下索敌体系需另起一套（见后续独立任务），此处保留原逻辑、不被规则二调用。
## row_tag ∈ {前排, 后排, 同排, 异排, 全部}（由 HandManager 从卡面 effects_text 解析得到）。
## 规则(v2.1, 用户确立 2026-09-07)：
##  - 统一定律：施法者自身恒为 lit（不盖黑幕）。
##  - 前排/后排：敌方按自身 is_back_row 绝对判定（前排→敌方前排 lit / 后排→敌方后排 lit）；我方除施法者外全部盖黑幕。
##  - 同排/异排：敌方全部盖黑幕；我方按施法者前后排相对判定（同排→同排队友 lit、异排队友盖；异排→异排队友 lit、同排队友盖）。
##  - 全部/未识别：全 lit（不盖）。
func set_target_dim(row_tag: String, self_id: String) -> void:
	var caster := _find_unit(self_id)
	var caster_back: bool = is_instance_valid(caster) and caster.is_back_row
	# [DEBUG] 选靶黑幕排查探针
	print("[BR] set_target_dim row_tag=%s self_id=%s caster_valid=%s caster_back=%s units=%d" % [row_tag, self_id, is_instance_valid(caster), caster_back, _get_units().size()])
	for u in _get_units():
		var ur := u as UnitRoot
		if not is_instance_valid(ur):
			continue
		var is_self: bool = is_instance_valid(caster) and ur == caster
		var lit: bool = is_self or _is_unit_target(ur, row_tag, caster, caster_back)
		print("[BR]   unit=%s faction=%s back=%s is_self=%s is_target=%s → %s" % [ur.unit_id, ur.unit_faction, ur.is_back_row, is_self, _is_unit_target(ur, row_tag, caster, caster_back), "亮(不盖)" if lit else "黑幕"])
		ur.set_dimmed(not lit)

## 清除全部单位黑幕（取消选靶 / 打出后调用）。
func clear_all_dim() -> void:
	for u in _get_units():
		var ur := u as UnitRoot
		if is_instance_valid(ur):
			ur.set_dimmed(false)

## 【规则一·已归档】单卡行标签 → 该单位是否属目标集合。依赖 is_back_row；规则二下待重设计。
## caster_back = 施法者是否后排；用于同排/异排的我方相对判定。
func _is_unit_target(ur: UnitRoot, row_tag: String, caster: UnitRoot, caster_back: bool) -> bool:
	var is_enemy: bool = ur.unit_faction == "enemy"
	match row_tag:
		"前排":
			# 敌方：前排(目标)亮、后排盖；我方：仅施法者亮(调用方已排除)，其余全盖
			return is_enemy and not ur.is_back_row
		"后排":
			# 敌方：后排(目标)亮、前排盖；我方：仅施法者亮，其余全盖
			return is_enemy and ur.is_back_row
		"同排":
			# 敌方全盖；我方：同排队友(目标)亮、异排队友盖
			if is_enemy:
				return false
			return ur.is_back_row == caster_back
		"异排":
			# 敌方全盖；我方：异排队友(目标)亮、同排队友盖
			if is_enemy:
				return false
			return ur.is_back_row != caster_back
		"全部", _:
			return true
	return true

## 卡牌「使用」后应用效果（连锁规则2·效果原型系统 + 规则2 攻击范围索敌）。
## 直接读 CardData.target_faction/target_range/scope（取代规则一前后排标签）。
## 数值落点统一走 _apply_stat(stat, value, hits, targets, caster)：
##   stat 由 cd.archetype_stat() 解析（8 原型 → damage/shield/heal/morale/bleed/move），
##   value = key_value × mult（mult = 连锁倍率 M(n)，基础 M(0)=1 → 不连锁即原值），
##   hits 仅多段攻击(damage_multi)用（每段同值 value）。
## 目标集 = resolve_targets_by_range 解析的「范围内目标阵营」候选；单体=被点单位(须为有效候选)，群体=候选全部。
## 候选为空且无全场 → 无有效目标，效果 no-op（卡牌恒可打出、不再整卡灰掉；选靶黑幕已按攻击范围盖黑非目标单位，此处兜底）。
## 实时刷新血条/护盾/buff（数值落点 = UnitRoot.damage/gain_shield/heal/add_buff）。
## 施法者当前士气提供的关键数值加成：士气层数 × MORALE_PER_LAYER（每1层+1点）。
## 用于攻击牌(damage)基础关键数值的预加成；非攻击牌 / 无施法者返回 0。
func _morale_bonus(caster: UnitRoot) -> int:
	if not is_instance_valid(caster):
		return 0
	return caster.get_buff_stacks("morale") * MORALE_PER_LAYER

## 计算一次效果的关键数值：攻击牌(card_type==0)先加施法者士气，再乘连锁倍率 M(n)；
## 其余分类(状态/防御)不受士气影响，仅基础值 × 连锁倍率。
## 公式（用户 2026-10-06）：有效关键数值 = 基础关键数值 + 士气加成，随后 × 连锁倍率（基础+士气 可再连锁增强）。
## 注：士气按「卡牌分类 tag」(攻击/状态/防御) 触发，而非按 stat 通道——故入参是 is_attack(由 cd.card_type==0 判定)。
func _compute_effect_value(base_key: int, is_attack: bool, caster: UnitRoot, mult: float) -> int:
	var effective_key: int = base_key
	if is_attack:
		effective_key += _morale_bonus(caster)
	return int(roundf(float(effective_key) * mult))

## 某角色当前士气提供的关键数值加成（每1层 +MORALE_PER_LAYER 点）。找不到单位/无士气返回 0。
## 供 HandManager 实时刷新攻击牌面数值使用。
func morale_bonus_for_role(role: String) -> int:
	var u := _find_unit(role)
	if not is_instance_valid(u):
		return 0
	return u.get_buff_stacks("morale") * MORALE_PER_LAYER

func apply_card_effect(hc: HandCard, unit: UnitRoot, target_faction: String, target_range: int, scope: String, mult: float = 1.0) -> void:
	if not is_instance_valid(hc) or not is_instance_valid(unit):
		return
	var cd := hc.data
	if cd == null:
		return
	var caster := _find_unit(hc.owner_group)
	# 特殊卡（effect_id 为空 + special 标识）：不走通用原型，入队待演出后由 _apply_special_card 专属结算。
	if cd.special != "":
		_pending_special.append({"cd": cd, "caster": caster, "target": unit, "mult": mult, "is_copy": hc.is_flashback})
		return
	# 攻击范围候选集（范围内符合目标阵营的全部单位）。
	var candidates: Array[UnitRoot] = resolve_targets_by_range(caster, target_faction, target_range, scope)
	var targets: Array[UnitRoot] = []
	if scope == "群体":
		targets = candidates
	else:
		# 单体：使用点选单位(须为有效候选)；无效则回退首候选；仍无则 no-op
		if is_instance_valid(unit) and candidates.has(unit):
			targets.append(unit)
		elif not candidates.is_empty():
			targets.append(candidates[0])
		# else: targets 保持空（no-op）

	if targets.is_empty():
		print("[BR-effect] 无有效目标，效果不生效（no-op）：faction=%s range=%d scope=%s" % [target_faction, target_range, scope])
		return

	# 关键数值 = (基础关键数值 + 士气加成) × 连锁倍率 M(n)；多段攻击 hits 段、每段同值。
	# 士气仅作用于「攻击」分类(card_type==0) 的卡牌关键数值，护盾/治疗/状态/位移不受影响。
	var stat: String = cd.archetype_stat()
	var is_attack: bool = cd.card_type == 0
	var value: int = _compute_effect_value(int(cd.key_value), is_attack, caster, mult)
	var hits: int = cd.hits if cd.hits > 0 else 1
	# 规则2·即时卡结算延后：仅入队，不立即扣血；待玩家演出组 finished（演出结束后）
	# 由 flush_deferred_effects() 统一结算 → 掉血延后到演出后生效（血条白残影也随后播放）。
	# 引导/执行卡走各自独立演出结束回调结算，不经过此队列。
	_pending_effects.append({"stat": stat, "value": value, "hits": hits, "targets": targets, "caster": caster})


## 按 stat 通道把数值落到目标/施法者。value 已含连锁倍率(×M)；hits 仅多段攻击用，其余为 1。
## 目标集 targets 已按行标签解析；自作用于施法者的通道(shield/heal)忽略 targets，直接作用于 caster。
func _apply_stat(stat: String, value: int, hits: int, targets: Array[UnitRoot], caster: UnitRoot) -> void:
	match stat:
		"damage":
			for t in targets:
				if not is_instance_valid(t):
					continue
				var total: int = value * maxi(hits, 1)
				t.damage(total)
				print("[BR-effect] 攻击: %s 受到 %d 点伤害（%d×%d）" % [t.unit_id, total, value, maxi(hits, 1)])
				# 血条清零 → 触发死亡演出（盖黑幕 + 0.2s 淡出）；die() 内部发 died 供 ATB 移除单位格 + 重排站位。
				if is_instance_valid(t) and t.get_current_hp() <= 0.0:
					t.die()
			# 士气消费：攻击行为结算后清空施法者士气层数（一次性消费，避免重复加成）；
			# 与「士气加成仅在攻击牌生效」对齐。无士气 / 非攻击施法者则 no-op。
			# 注：士气加成已在 effect 数值(value)中于出牌瞬间锁定，此处仅清标记，不影响本次已结算数值。
			if is_instance_valid(caster) and caster.get_buff_stacks("morale") > 0:
				caster.remove_buff("morale")
		"shield":
			if is_instance_valid(caster):
				caster.gain_shield(value)
				print("[BR-effect] 防御: %s 获得 %d 点护盾" % [caster.unit_id, value])
				# Wangg 偷盾事件：友方(敌方阵营, 非自身)获盾 → 武装 Wangg 的 steal_armed 旗（下一回合锁定意图3）。
				if caster.unit_faction == "enemy" and caster.unit_id != "Wangg":
					for u in _get_units():
						if u is UnitRoot and (u as UnitRoot).unit_id == "Wangg":
							(u as UnitRoot).ai_memory["steal_armed"] = true
							print("[BR-wangg] 友方 %s 获盾 → Wangg 偷盾已上膛" % caster.unit_id)
		"heal":
			if is_instance_valid(caster):
				caster.heal(value)
				print("[BR-effect] 治疗: %s 回复 %d 点血量" % [caster.unit_id, value])
		"morale":
			for t in targets:
				if not is_instance_valid(t):
					continue
				t.add_buff("morale", value, 1)   # 文案由 KeywordGlossary 按 buff_id 解析（与快照词条面板同源）
				print("[BR-effect] 状态: %s 获得 %d 层【士气】" % [t.unit_id, value])
		"bleed":
			for t in targets:
				if not is_instance_valid(t):
					continue
				t.add_buff("bleed", value, 2)   # 文案由 KeywordGlossary 按 buff_id 解析（与快照词条面板同源）
				print("[BR-effect] 状态: %s 造成 %d 层【出血】" % [t.unit_id, value])
		"poison":
			for t in targets:
				if not is_instance_valid(t):
					continue
				t.add_buff("poison", value, 2)   # 文案由 KeywordGlossary 按 buff_id 解析（与快照词条面板同源）
				print("[BR-effect] 状态: %s 造成 %d 层【中毒】" % [t.unit_id, value])
		"move":
			# 【规则一·已归档】翻转前后排：规则二下 is_back_row 不参与定位，此分支禁用（待索敌重设计）。
			if ACTIVE_BATTLEFIELD_RULE == BattlefieldRule.RULE_1_FRONT_BACK:
				for t in targets:
					if is_instance_valid(t):
						t.is_back_row = not t.is_back_row
						print("[BR-effect] 位移: %s 翻转前后排" % t.unit_id)
			else:
				print("[BR-effect] 位移(规则二·已禁用前后排翻转): 待索敌重设计")
		_:
			push_warning("[BR-effect] 未知 stat: %s" % stat)


## 结算待结算队列：演出组 finished（演出结束后）调用，把即时卡「点牌时入队」的 (stat,value,hits,targets,caster) 统一实扣。
## 引导/执行/敌方走各自独立回调，不经过此队列；此处为空时直接 no-op。
func flush_deferred_effects() -> void:
	if _pending_effects.is_empty():
		return
	for p in _pending_effects:
		_apply_stat(p.get("stat", ""), p.get("value", 0), p.get("hits", 1), p.get("targets", []), p.get("caster", null))
	_pending_effects.clear()
	# 若本帧仍有未清空的残留
	# 特殊卡专属结算（位移/集士气/记录伤害等）：与即时卡同帧在演出结束后统一落点。
	for p in _pending_special:
		_apply_special_card(p.get("cd", null), p.get("caster", null), p.get("target", null), p.get("mult", 1.0), p.get("is_copy", false))
	_pending_special.clear()  # （理论上不会）防御性清一次，避免下次 flush 重复结算。
	_pending_effects.clear()


## ATB 高亮框(第0格)占据单位变化 → 转发给 HandManager 动态扩/缩对应角色手牌组间距；
## 并在「角色新回合开始」时抽该角色一张牌（含开局首个被框到的玩家单位——用户 2026-09-21 明确要求每个新回合都抽，移除首回合不抽守卫）。
## uid = 占据单位 uid（玩家单位 uid 即角色名 ROLES 之一）；is_player = 是否玩家阵营。
## 【赃物】惩罚状态：最近一次被高亮框框定的玩家 uid（用于「玩家回合结束」触发弃牌惩罚）。
## 回声期不更新此值（回声非真实回合），使回声结束后的真实切换仍按上一名真实玩家判定，避免漏/重复触发。
var _last_framed_uid: String = ""
var _last_framed_is_player: bool = false

func _on_atb_framed_changed(uid: String, is_player: bool) -> void:
	# 规则2·引导卡回声：进高亮框的是回声 → 由 atb2 的 echo_effect_requested 信号回路处理（真实演出 + 结算 + 推进），
	# 不走角色手牌组 / 抽牌逻辑（atb1 的 _trigger_guide_echo 分支在此移除，改用信号回路）。
	var at := atb_track
	if is_instance_valid(at) and at.framed_echo_data().size() > 0:
		return
	# 【赃物】回合结束惩罚：本次框定「离开一名玩家」时，对该玩家结算（随机弃牌 + 清空赃物）。
	# 回声期不更新 _last_framed（上方 early-return 已跳过），故回声结束后的真实切换仍按上一名真实玩家判定。
	if _last_framed_is_player and _last_framed_uid != "" and _last_framed_uid != uid:
		_end_player_turn(_last_framed_uid)
	_last_framed_uid = uid
	_last_framed_is_player = is_player
	var hm := get_tree().get_first_node_in_group("hand_manager") as HandManager
	if not is_instance_valid(hm):
		return
	hm.apply_framed_role(uid, is_player)   # 始终展开对应角色手牌组（含开局首帧）
	# 角色新回合开始 → 抽该角色一张牌（每个玩家回合都抽，含首回合）。
	if is_player:
		_recover_fire_on_activate(uid)   # 该角色新回合：按上回合等待格数回复 🔥 入共享池
		# 规则2·执行卡挂起：角色新回合开始，若有挂起效果则自动演出+结算（不推回），随后清除。
		var unit := _find_unit(uid)
		if is_instance_valid(unit) and not unit.pending_execution_effect.is_empty():
			_trigger_execution(unit)
		hm.draw_one_for_role(uid)
	# ⚠️ 出血 DoT 已迁移到「队列前进一格」(units_advanced) 触发——见 _on_units_advanced / _tick_bleed。
	# 不再在此处（进高亮框）结算，避免「只在进入 cell0 才触发一次」的旧行为。


## ── 【赃物】惩罚系统（与王 gg UID002 / Mafe UID004 共用同一 buff，实时计数）──
## 规则（见 KeywordGlossary「赃物」词条）：
##   ① 玩家每次「连锁 +1」（加一环）→ 移出当前链主 1 层赃物（player_chain_ring_added）；
##   ② 玩家回合结束 → 随机丢弃等同赃物层数的手牌并清空赃物（_end_player_turn）。
##   取消选靶 → 把加链移出的赃物退回链主（refund_loot），与 🔥 退回同口径，避免误罚。

## 玩家回合结束：带赃物者随机弃牌（张数=赃物层数，不足则弃光）+ 清空赃物。
func _end_player_turn(uid: String) -> void:
	var unit := _find_unit(uid)
	if not is_instance_valid(unit) or unit.unit_faction != "player":
		return
	var stacks := unit.get_buff_stacks("loot")
	if stacks <= 0:
		return
	var hm := get_tree().get_first_node_in_group("hand_manager") as HandManager
	if is_instance_valid(hm):
		hm.discard_random_for_role(uid, stacks)   # 随机丢弃等同层数的手牌（内部按手牌数量封顶）
	unit.remove_buff("loot")                       # 清空赃物（弃牌惩罚后彻底移除）
	print("[BR-loot] %s 回合结束：丢弃至多 %d 张手牌并清空赃物" % [uid, stacks])

## 【赃物】连锁 +1：当前活动玩家（链主）每加一环，移出 1 层赃物（实时计数，供 Mafe 被动读取）。
func player_chain_ring_added(uid: String) -> void:
	var unit := _find_unit(uid)
	if not is_instance_valid(unit):
		return
	if unit.get_buff_stacks("loot") > 0:
		unit.remove_buff_stacks("loot", 1)
		print("[BR-loot] %s 连锁+1：移出 1 层赃物（剩余 %d）" % [uid, unit.get_buff_stacks("loot")])

## 【赃物】退回：取消选靶时把加链移出的赃物层数加回链主（与 🔥 退回同口径，避免误罚）。
func refund_loot(uid: String, n: int) -> void:
	if n <= 0:
		return
	var unit := _find_unit(uid)
	if not is_instance_valid(unit):
		return
	unit.add_buff("loot", n, 2)
	print("[BR-loot] %s 取消选靶：退回 %d 层赃物" % [uid, n])



## 卡牌类型→美术态（同 HandManager._caster_art_state）：攻击=Attack(1)/状态=Cast(2)/防御=Charge(4)。
func _card_cast_state(cd: CardData) -> int:
	if cd == null:
		return 0
	match cd.card_type:
		0: return 1
		1: return 2
		2: return 4
		_: return 0


## 规则2·执行卡(橙)调度：打出执行卡时把效果「挂起」到施法者 UnitRoot（不立即结算、不推回施法者——推回由打出流程统一做）。
## value 已含连锁倍率 M(n)（打出瞬间锁定，所有回声共用——执行卡仅一张，故即该值）。
## 字段结构见 UnitRoot.pending_execution_effect。每角色同时最多 1 张（按设计不堆叠）。
func arm_execution(anchor: HandCard, mult: float) -> void:
	var caster := _find_unit(anchor.owner_group)
	if not is_instance_valid(caster) or not is_instance_valid(anchor) or anchor.data == null:
		return
	var cd := anchor.data
	var stat: String = cd.archetype_stat()
	var is_attack: bool = cd.card_type == 0
	var value: int = _compute_effect_value(int(cd.key_value), is_attack, caster, mult)
	var hits: int = cd.hits if cd.hits > 0 else 1
	caster.pending_execution_effect = {
		"stat": stat, "value": value, "hits": hits,
		"target_faction": cd.target_faction, "target_range": cd.target_range, "scope": cd.scope,
		"cast_state": _card_cast_state(cd)
	}


## 规则2·引导卡(绿)调度：打出时按费用在 ATB 队列插 (cost-1) 个回声格（cell 1..cost-1，施法者自身推回到 cell cost）。
## 回声部件复用施法者插图，效果数值(含连锁 M(n))在打出瞬间锁定、写入每个回声 echo_data（所有回声共用）。
## 引导卡费用最低≥2（死规矩），故 cost-1≥1，至少 1 个回声。
func spawn_guide_echoes(anchor: HandCard, mult: float) -> void:
	var caster := _find_unit(anchor.owner_group)
	if not is_instance_valid(caster) or not is_instance_valid(anchor) or anchor.data == null or not is_instance_valid(atb_track):
		return
	var cd := anchor.data
	var stat: String = cd.archetype_stat()
	var is_attack: bool = cd.card_type == 0
	var value: int = _compute_effect_value(int(cd.key_value), is_attack, caster, mult)
	var hits: int = cd.hits if cd.hits > 0 else 1
	var cost: int = anchor.cost
	if cost < 2:
		return   # 引导卡费用死规矩≥2（cost-1≥1）；低于 2 不生成回声
	var ed: Dictionary = {
		"caster_uid": caster.unit_id, "stat": stat, "value": value, "hits": hits,
		"target_faction": cd.target_faction, "target_range": cd.target_range, "scope": cd.scope,
		"cast_state": _card_cast_state(cd)
	}
	# 批量同步插入 (cost-1) 个回声：cells 1..cost-1。
	# 修复：原逐格调用 spawn_echo 在循环里非 await → 被 _busy 门截断，只生成 1 个；
	# 现改为一次性批量插入（首格→基础版 UnitCell / 已有→小 EchoCell 堆叠），单段动画。
	# ⚠️ 必须 await：spawn_guide_echoes_batch 内部置 _busy=true 直到滑入动画结束；
	# 若不 await，notify_used_on_unit 会在 _busy 仍为真时同步调用 advance_framed → _act_front 的
	# 「if _busy: return」直接吞掉引导卡回合推进（bug：引导卡无法结束回合）。await 后 _busy 已归 false。
	if is_instance_valid(atb_track):
		await atb_track.spawn_guide_echoes_batch(caster.unit_id, cost, ed)


## 引导卡回声进高亮框(cell0)：atb2 在回声演出链环节经 echo_effect_requested 回调本函数，
## 播放真实演出组(施法者居右 + 目标居左)→ 结算 → 调 complete_echo_effect() 唤醒 atb2 继续淡出 + 推进。
## 找不到组/施法者则直接结算 + 兜底 complete_echo_effect（不在此手动 remove：atb2 内部淡出销毁 + 推进）。
func _on_echo_effect_requested(echo_data: Dictionary) -> void:
	if not is_instance_valid(atb_track):
		return
	var caster := _find_unit(echo_data.get("caster_uid", ""))
	if not is_instance_valid(caster):
		atb_track.complete_echo_effect()
		return
	var targets := resolve_targets_by_range(caster, echo_data.get("target_faction", ""), echo_data.get("target_range", -1), echo_data.get("scope", "单体"))
	if echo_data.get("scope", "单体") != "群体" and not targets.is_empty():
		var single: Array[UnitRoot] = []
		single.append(targets[0])
		targets = single
	var units: Array[Dictionary] = []
	units.append({"id": caster.unit_id, "faction": "player", "state": echo_data.get("cast_state", 0)})
	for t in targets:
		var tstate: int = UnitRoot.UnitArtState.HIT if echo_data.get("stat", "") == "damage" else UnitRoot.UnitArtState.IDLE
		units.append({"id": t.unit_id, "faction": t.unit_faction, "state": tstate})
	# 演出组「伤害数字 / buff 提示」对接：把回声效果(stat/value/hits)预填进 units 字典（纯预览，结算仍在 _on_echo_cutscene_done）。
	var echo_stat: String = echo_data.get("stat", "")
	if echo_stat != "":
		_enrich_units_fx(units, echo_stat, int(echo_data.get("value", 0)), int(echo_data.get("hits", 1)), caster.unit_id)
	# 演出期间串行化输入（避免玩家在回声演出中误出牌）：经 HandManager 锁。
	var hm := get_tree().get_first_node_in_group("hand_manager") as HandManager
	if is_instance_valid(hm):
		hm.set_cutscene_lock(true)
	# 统一过串行调度器：build 仅负责「建组+入树+开播」，finished 结算交 _on_echo_cutscene_done。
	if is_instance_valid(cutscene_director):
		var units_snap: Array[Dictionary] = units
		var echo_snap: Dictionary = echo_data
		var tgt_snap: Array[UnitRoot] = targets
		cutscene_director.enqueue(
			func() -> CutsceneGroup:
				var g := CUTSCENE_GROUP_SCRIPT.new() as CutsceneGroup
				if g == null:
					return null
				add_child(g)
				g.play_units(units_snap, "player", 0)
				return g,
			_on_echo_cutscene_done.bind(echo_snap, tgt_snap))
		return
	# 兜底：调度器未就绪，直接结算 + 推进，避免软锁
	_resolve_echo(echo_data, targets)
	atb_track.complete_echo_effect()
	if is_instance_valid(hm):
		hm.set_cutscene_lock(false)


func _on_echo_cutscene_done(echo_data: Dictionary, targets: Array[UnitRoot]) -> void:
	_resolve_echo(echo_data, targets)
	if is_instance_valid(atb_track):
		atb_track.complete_echo_effect()
	var hm := get_tree().get_first_node_in_group("hand_manager") as HandManager
	if is_instance_valid(hm):
		hm.set_cutscene_lock(false)


## 回声结算：按 echo_data 的 stat/value/hits 落到 targets（单体已取范围内 ATB 顺序第一个 / 群体全中）。
func _resolve_echo(echo_data: Dictionary, targets: Array[UnitRoot]) -> void:
	if echo_data.is_empty():
		return
	var caster := _find_unit(echo_data.get("caster_uid", ""))
	if targets.is_empty():
		print("[BR-guide] 回声无有效目标，效果不生效（no-op）：%s" % echo_data.get("target_faction", ""))
		return
	_apply_stat(echo_data.get("stat", ""), echo_data.get("value", 0), echo_data.get("hits", 1), targets, caster)


## 把一次效果结算的「视觉反馈数据」(伤害数字 payload / buff 提示) 预填到演出 units 字典，
## 使 CutsceneController 在滑入时挂载持久伤害数字 / buff 提示（与测试场景一致，纯预览层）。
## 与 _apply_stat 的落点逻辑对齐：damage/morale/bleed 作用于「非施法者」(目标)、shield/heal 作用于施法者自身；move 忽略。
## 仅填数据、不结算数值；真实结算仍由 _resolve_* / flush_deferred_effects 在演出结束后执行。
func _enrich_units_fx(units: Array[Dictionary], stat: String, value: int, hits: int, caster_id: String) -> void:
	if stat == "" or stat == "move":
		return
	var total: int = value * maxi(hits, 1)
	var self_stat: bool = (stat == "shield" or stat == "heal")
	for u in units:
		var uid: String = u.get("id", "")
		var is_caster: bool = (uid == caster_id)
		if self_stat and not is_caster:
			continue
		if not self_stat and is_caster:
			continue
		match stat:
			"damage":
				# 护盾优先吸收：按目标当前护盾预填 absorbed_amount，使飘字准确显示"吸收 N"。
				# 演出是伤害结算的预览（结算在演出结束后执行），此刻护盾值=实际结算时护盾值，预填一致。
				var absorbed: int = 0
				var tgt: UnitRoot = _find_unit_by_id(uid)
				if is_instance_valid(tgt):
					absorbed = mini(total, int(tgt.get_shield()))
				u["dmg_payload"] = {"type": "normal", "value": total, "absorbed_amount": absorbed}
			"heal":
				u["dmg_payload"] = {"type": "heal", "value": total}
			"shield":
				u["dmg_payload"] = {"type": "shield", "value": total}
			"morale":
				u["buff_name"] = "士气"
				u["buff_tone"] = 1
			"bleed":
				u["buff_name"] = "出血"
				u["buff_tone"] = 2


## 执行卡挂起效果在角色新回合开始触发：播放演出组(施法者居右 + 目标居左)→ 结算 → 清除(不推回)。
## 演出组 finished → _on_execution_done（结算+清挂起）。找不到组/施法者则直接结算+清除兜底。
func _trigger_execution(unit: UnitRoot) -> void:
	var ed: Dictionary = unit.pending_execution_effect
	if ed.is_empty():
		return
	var targets := resolve_targets_by_range(unit, ed.get("target_faction", ""), ed.get("target_range", -1), ed.get("scope", "单体"))
	if ed.get("scope", "单体") != "群体" and not targets.is_empty():
		var single: Array[UnitRoot] = []
		single.append(targets[0])
		targets = single
	var units: Array[Dictionary] = []
	units.append({"id": unit.unit_id, "faction": "player", "state": ed.get("cast_state", 0)})
	for t in targets:
		var tstate: int = UnitRoot.UnitArtState.HIT if ed.get("stat", "") == "damage" else UnitRoot.UnitArtState.IDLE
		units.append({"id": t.unit_id, "faction": t.unit_faction, "state": tstate})
	# 演出组「伤害数字 / buff 提示」对接：把执行效果(stat/value/hits)预填进 units 字典（纯预览，结算仍在 _on_execution_done）。
	var exec_stat: String = ed.get("stat", "")
	if exec_stat != "":
		_enrich_units_fx(units, exec_stat, int(ed.get("value", 0)), int(ed.get("hits", 1)), unit.unit_id)
	# 演出期间串行化输入（避免玩家在演出中误出牌）：经 HandManager 锁。
	var hm := get_tree().get_first_node_in_group("hand_manager") as HandManager
	if is_instance_valid(hm):
		hm.set_cutscene_lock(true)
	# 统一过串行调度器：build 仅负责「建组+入树+开播」，finished 结算交 _on_execution_done。
	if is_instance_valid(cutscene_director):
		var units_snap: Array[Dictionary] = units
		var unit_snap: UnitRoot = unit
		var tgt_snap: Array[UnitRoot] = targets
		cutscene_director.enqueue(
			func() -> CutsceneGroup:
				var g := CUTSCENE_GROUP_SCRIPT.new() as CutsceneGroup
				if g == null:
					return null
				add_child(g)
				g.play_units(units_snap, "player", 0)
				return g,
			_on_execution_done.bind(unit_snap, tgt_snap))
		return
	# 兜底：调度器未就绪，直接结算 + 清挂起，避免软锁
	_apply_stat(ed.get("stat", ""), ed.get("value", 0), ed.get("hits", 1), targets, unit)
	unit.pending_execution_effect = {}


func _on_execution_done(unit: UnitRoot, targets: Array[UnitRoot]) -> void:
	if is_instance_valid(unit):
		var ed: Dictionary = unit.pending_execution_effect
		_apply_stat(ed.get("stat", ""), ed.get("value", 0), ed.get("hits", 1), targets, unit)
		unit.pending_execution_effect = {}   # 清除挂起（不推回，回合继续）
	var hm := get_tree().get_first_node_in_group("hand_manager") as HandManager
	if is_instance_valid(hm):
		hm.set_cutscene_lock(false)


## 敌方 ATB 回合：播放怪物演出组（纯视觉，不结算数值，与玩家卡演出一致）+ 结束后推进 ATB 队列。
## 演出组单位：施法者 = 本怪物（真实美术，居右）；目标 = 按意图 target 类型随机挑选的合规战斗单位（居左）；
## 组合数量随机（单体=1，范围=2~3），达成「随机组合」的意图表现。direction=enemy（整组从右侧滑入）。
## 演出组 finished → atb_track.execute_end()：怪物插入随机格（_set_framed 已设为 randi_range），下一单位进高亮框。
## 若找不到怪物/组创建失败 → 直接 execute_end 兜底推进，避免回合卡死。
func _on_enemy_action_started(uid: String) -> void:
	if not is_instance_valid(atb_track):
		return
	var caster := _find_unit(uid)
	if not is_instance_valid(caster) or caster.unit_faction != "enemy":
		atb_track.execute_end()
		return
	# 选意：Mafe（UID004 精英）走专属加权袋（条件修正，见 _mafe_pick_intent）；
	# 其余怪物走数据驱动意图袋（MonsterDatabase），未设袋回落旧随机占位。
	var intent: Dictionary
	if caster.unit_id == "Mafe":
		# 意图已在「上一次行动结算后」生成并锁定（提前预告）；此处仅读取已锁定意图执行，
		# 不再实时重选——保证意图生成后至执行前不被推翻（与 Wangg 同策略）。
		intent = caster.current_deck_intent()
		if intent.is_empty():
			caster.take_next_intent()
			intent = caster.get_intent()
		else:
			# 应用选中的意图：更新 telegraph 显示，并缓存完整字典（含 intent_key）供结算/telegraph 识别专属意图。
			# 注意：UnitRoot.get_intent() 不回传 intent_key，Mafe 解析必须直接用 chosen 而非 get_intent()。
			pass   # 锁定意图已由 _on_enemy_cutscene_done 生成，执行时不再挑选
	elif caster.unit_id == "Wangg":
		# 意图已在「上一次行动结算后」生成并锁定（提前预告）；此处仅读取已锁定意图执行，
		# 不再实时重选——保证意图生成后至执行成功前不变（偷盾等高优先级意图须等下一个才生效）。
		intent = caster.current_deck_intent()
		if intent.is_empty():
			caster.take_next_intent()
			intent = caster.get_intent()
	else:
		# 非条件式敌人（fixed/bag：Remy/Grey 等）：意图在上一次结算后已由 cutscene_done 预推进并锁定，
		# 此处仅读取已锁定意图执行，不再实时抽取——保证「预告 = 即将执行」。
		intent = caster.current_deck_intent()
		if intent.is_empty():
			caster.take_next_intent()
			intent = caster.get_intent()
	var units: Array[Dictionary] = []
	# 施法者（怪物）状态按意图类型映射（att=攻击 / shield=蓄力 / state=施法 / think=待机）。
	var cstate: int = _enemy_cast_state(intent.get("type", ""))
	units.append({"id": caster.unit_id, "faction": "enemy", "state": cstate})
	# 目标单位（按意图 target 随机挑；att 受击态为 HIT，其余 IDLE）。
	var targets: Array[UnitRoot] = _pick_intent_targets(intent, caster)
	for t in targets:
		var tstate: int = UnitRoot.UnitArtState.HIT if intent.get("type", "") == "att" else UnitRoot.UnitArtState.IDLE
		units.append({"id": t.unit_id, "faction": t.unit_faction, "state": tstate})
	# 演出组「伤害数字 / buff 提示」对接：按意图类型预填 units（att=伤害打目标、shield=护盾给自身、state=按目标阵营 morale/bleed）。
	# 演出组「伤害数字 / buff 提示」对接：按意图类型预填 units（att=伤害 / shield=护盾 / state=按目标阵营 morale/出血）。
	# Mafe 意图3（self_poison_up）为自buff，需在 Mafe 自身预告【上毒】而非给敌人挂出血（否则 telegraph 会误显示）。
	if intent.get("intent_key", "") == "self_poison_up":
		for u in units:
			if u.get("id", "") == caster.unit_id:
				u["buff_name"] = "上毒"
				u["buff_tone"] = 1
	elif intent.get("type", "") == "att":
		_enrich_units_fx(units, "damage", _enemy_attack_damage(caster, intent), 1, caster.unit_id)
	elif intent.get("type", "") == "shield":
		_enrich_units_fx(units, "shield", _parse_intent_value(intent.get("value", "5")), 1, caster.unit_id)
	# Wangg 专属意图预告（type 同为 state，须在通用 state 分支前拦截）。
	elif caster.unit_id == "Wangg" and intent.get("intent_key", "") == "apply_loot":
		# 意图2·施加赃物：在【没有赃物】的玩家目标上预告【赃物】(减益)。
		for u in units:
			if u.get("id", "") != caster.unit_id and u.get("faction", "") != caster.unit_faction:
				u["buff_name"] = "赃物"
				u["buff_tone"] = 2
	elif caster.unit_id == "Wangg" and intent.get("intent_key", "") == "steal_shield":
		# 意图3·偷取护盾：在 Wangg 自身预告获盾（护盾走独立护盾层，不进 buff 提示器；此处仅给施法者预告）。
		for u in units:
			if u.get("id", "") == caster.unit_id:
				u["buff_name"] = "护盾"
				u["buff_tone"] = 1
	elif intent.get("type", "") == "state":
		for u in units:
			if u.get("id", "") == caster.unit_id:
				continue
			if u.get("faction", "") == caster.unit_faction:
				u["buff_name"] = "士气"
				u["buff_tone"] = 1
			else:
				u["buff_name"] = "出血"
				u["buff_tone"] = 2
	else:
		pass
	# 生成独立演出组（视觉），finished 接「结算+推进 ATB」。统一过串行调度器。
	if is_instance_valid(cutscene_director):
		var units_snap: Array[Dictionary] = units
		var uid_snap: String = uid
		var intent_snap: Dictionary = intent
		cutscene_director.enqueue(
			func() -> CutsceneGroup:
				var g := CUTSCENE_GROUP_SCRIPT.new() as CutsceneGroup
				if g == null:
					return null
				add_child(g)
				g.play_units(units_snap, "enemy", 0)
				return g,
			_on_enemy_cutscene_done.bind(uid_snap, intent_snap),   # 演出结束 → 结算意图 + 推进 ATB
			uid_snap)                                             # owner_uid：死亡时凭此精准取消本组（见 _on_unit_died）
		return
	# 兜底：调度器未就绪，直接结算 + 推进，避免软锁
	_resolve_enemy_intent(caster, intent)
	atb_track.execute_end()


## 演出组播完：结算怪物意图数值（实时刷新血条/护盾/buff），再推进 ATB 队列（怪物插入随机格）。
func _on_enemy_cutscene_done(uid: String, intent: Dictionary) -> void:
	var caster := _find_unit(uid)
	# 防御：caster 已死亡（如出血致死）→ 死亡已通过 remove_unit_by_uid 推进 ATB 并重新框定下一位，
	# 此处绝不再 execute_end（否则会误移除/重插当前框定单位，造成队列错位/卡死）。直接跳过结算+推进。
	if is_instance_valid(caster) and caster.get_current_hp() > 0.0:
		_resolve_enemy_intent(caster, intent)
		_tick_poison(caster)   # 敌方行动后结算【中毒】（护盾可 1:1 抵消层数）
		# Wangg（UID002）条件 AI：行动结算后基于「已结算」状态（攻击计数已+1 / 偷盾已消费）生成【下一个】意图并锁定预告，
		# 执行时(_on_enemy_action_started)只读取此锁定意图，不实时重选——保证意图生成后至执行前不被推翻。
		if caster.unit_id == "Wangg":
			var nxt: Dictionary = _wangg_pick_intent(caster)
			if not nxt.is_empty():
				caster._apply_intent_dict(nxt)
		elif caster.unit_id == "Mafe":
			# 行动结算后基于「已结算」状态（播种赃物已落地 / 自身上毒已叠 / 场上赃物/上毒变化）生成【下一个】意图并锁定预告，
			# 执行时(_on_enemy_action_started)只读取此锁定意图，不实时重选——保证意图生成后至执行前不被推翻。
			var nxt: Dictionary = _mafe_pick_intent(caster)
			if not nxt.is_empty():
				caster._apply_intent_dict(nxt)
		else:
			# 非条件式敌人（fixed/bag：Remy/Grey 等）：行动结算后预推进意图袋并锁定预告下一个意图，
			# 使「等待期」显示的意图即为即将执行的意图（与条件式敌人同一策略）。
			caster.take_next_intent()
		if is_instance_valid(atb_track):
			atb_track.execute_end()


## 怪物意图结算（与玩家卡共用 _apply_stat 数值落点）。
## att=解析 N*M 总伤害；shield=自身+2护盾；state=按目标阵营 士气(友方增益)/出血(敌方减益) 各2层；think=无。
## Mafe（UID004 精英）走专属逻辑：被动(赃物→中毒) / 上毒加成 / 意图2 播种赃物 / 意图4 自带前进。
func _resolve_enemy_intent(caster: UnitRoot, intent: Dictionary) -> void:
	if is_instance_valid(caster) and caster.unit_id == "Mafe":
		_resolve_mafe_intent(caster, intent)
		return
	if is_instance_valid(caster) and caster.unit_id == "Wangg":
		_resolve_wangg_intent(caster, intent)
		return
	var type_id: String = intent.get("type", "")
	var targets: Array[UnitRoot] = _pick_intent_targets(intent, caster)
	match type_id:
		"att":
			var total := _enemy_attack_damage(caster, intent)
			# Grey 意图3（atk_range2_group_knock）：群体伤害不变；命中时若目标护盾不足以完全抵消
			# （total > 当前护盾 = 真实掉血 = 有效伤害），将该玩家【击退1格】（远离 cell0，行动延后）。
			if intent.get("intent_key", "") == "atk_range2_group_knock" and is_instance_valid(atb_track):
				for t in targets:
					if not is_instance_valid(t):
						continue
					if total > t.get_shield():
						atb_track.retreat_unit(t.unit_id, 1)
						print("[BR-grey] 击退：%s 护盾(%d) 不足以挡满(%d)，被击退1格" % [t.unit_id, int(t.get_shield()), total])
			_apply_stat("damage", total, 1, targets, caster)
		"shield":
			_apply_stat("shield", _parse_intent_value(intent.get("value", "5")), 1, targets, caster)
		"state":
			for t in targets:
				if not is_instance_valid(t):
					continue
				if t.unit_faction == caster.unit_faction:
					_apply_stat("morale", 2, 1, [t], caster)
				else:
					_apply_stat("bleed", 2, 1, [t], caster)
		"think", _:
			pass


## ── UID004 Mafe 精英专属意图结算 ──
## 被动：攻击带【赃物】的单位时，额外造成等同【赃物】层数的【中毒】(已在 _mafe_attack_side_effects 内)。
## 上毒：攻击类行为额外造成 5 层中毒，每次攻击后 -1 层（层数=持续攻击次数）。
## 意图2 播种：范围2 群体攻击同时给每个目标 1 层【赃物】。
## 意图4：范围3 单体攻击，若目标有【赃物】则自身前进2（execute_end 消费 pending_atb_advance）。
func _resolve_mafe_intent(caster: UnitRoot, intent: Dictionary) -> void:
	var key: String = intent.get("intent_key", "")
	match key:
		"self_poison_up":
			# 意图3·自buff：自身 5 层中毒 + 2 层【上毒】（上毒=攻击额外+5中毒）。
			caster.add_buff("poison", 5, 2)
			caster.add_buff("up_poison", 2, 1)
			print("[BR-mafe] 意图3 自buff：%s +5 中毒 / +2 上毒" % caster.unit_id)
		"atk_backmost", "atk_range2_loot", "atk_range3_loot_advance":
			var targets := _pick_intent_targets(intent, caster)
			var total := _enemy_attack_damage(caster, intent)
			_apply_stat("damage", total, 1, targets, caster)
			_mafe_attack_side_effects(caster, targets, key)
			# 意图4：目标带赃物 → 自身前进2。
			if key == "atk_range3_loot_advance" and not targets.is_empty():
				if targets[0].get_buff_stacks("loot") > 0:
					caster.pending_atb_advance = 2
		_:
			pass

## Mafe 攻击类意图的附加效果：被动(赃物→中毒) + 上毒(+5中毒) + 上毒消耗(-1) + 意图2 播种赃物。
func _mafe_attack_side_effects(caster: UnitRoot, targets: Array[UnitRoot], key: String) -> void:
	var up := caster.get_buff_stacks("up_poison")
	for t in targets:
		if not is_instance_valid(t):
			continue
		# 被动：对带【赃物】的单位，额外造成等同赃物层数的中毒。
		var loot := t.get_buff_stacks("loot")
		if loot > 0:
			t.add_buff("poison", loot, 2)
			print("[BR-mafe] 被动：%s 带 %d 层赃物 → 额外 %d 层中毒" % [t.unit_id, loot, loot])
		# 上毒：攻击额外 +5 中毒（固定，与剩余上毒层数无关）。
		if up > 0:
			t.add_buff("poison", 5, 2)
	# 意图2 播种赃物：给每个目标 1 层赃物（喂养自身被动 / 意图4）。
	if key == "atk_range2_loot":
		for t in targets:
			if is_instance_valid(t):
				t.add_buff("loot", 1, 2)
				print("[BR-mafe] 播种赃物：%s +1 层赃物" % t.unit_id)
	# 上毒消耗：每次攻击类行为结束 -1 层。
	if up > 0:
		caster.remove_buff_stacks("up_poison", 1)

## Mafe 意图加权选择（bag 风格 + 条件修正）：
##  - 默认四意图等权；
##  - 场上无【赃物】层数时，意图2(播种) 加权至 3（优先播种赃物）；
##  - 自身有【上毒】层数时，意图3(自buff) 降权至 0.2；
##  - 避免与上一个意图完全相同（除非只剩它）。
func _mafe_pick_intent(caster: UnitRoot) -> Dictionary:
	var md: Dictionary = MonsterDatabase.get_data("Mafe")
	var deck: Array = md.get("intent_deck", [])
	if deck.is_empty():
		return {}
	# 场上赃物总量（玩家单位）。
	var field_loot := 0
	for u in _get_units():
		if u is UnitRoot and (u as UnitRoot).unit_faction == "player":
			field_loot += (u as UnitRoot).get_buff_stacks("loot")
	var up := caster.get_buff_stacks("up_poison")
	var last_key: String = caster.current_deck_intent().get("intent_key", "")
	var weights: Dictionary = {}
	for it in deck:
		var k: String = it.get("intent_key", "")
		var w := 1.0
		if k == "atk_range2_loot" and field_loot <= 0:
			w = 3.0
		elif k == "self_poison_up" and up > 0:
			w = 0.2
		weights[k] = w
	# 加权抽取（最多 6 次尝试避免与上次相同）。
	var chosen := {}
	for attempt in range(6):
		var total_w := 0.0
		for it in deck:
			total_w += weights[it.get("intent_key", "")]
		if total_w <= 0.0:
			break
		var r := randf() * total_w
		var acc := 0.0
		var pick_key := ""
		for it in deck:
			var k: String = it.get("intent_key", "")
			acc += weights[k]
			if r <= acc:
				pick_key = k
				break
		if pick_key == "":
			pick_key = (deck[0] as Dictionary).get("intent_key", "")
		if pick_key != last_key or attempt == 5:
			for it in deck:
				if it.get("intent_key", "") == pick_key:
					chosen = it
					break
			break
	if chosen.is_empty():
		chosen = deck[randi() % deck.size()]
	return chosen


## ── UID002 Wangg 条件式意图裁决 ──
## 设计（见 怪物设计总表 UID002 段）：非随机，优先级 3(偷盾) > 2(赃物) > 1(攻击)。
##   · 意图1(攻击) 每使用一次 → ai_memory["intent1_count"] += 1；
##   · 累计达 2 → 下次出 意图2(施加赃物)，用后计数清零（回到「再攒 2 次 1」）；
##   · 友方(敌方阵营非自身)获盾事件 → 置 ai_memory["steal_armed"] 旗，下次优先出 意图3(偷取护盾)，消费后清零；
##   两者并列共存、互不干扰。
func _wangg_pick_intent(caster: UnitRoot) -> Dictionary:
	var md: Dictionary = MonsterDatabase.get_data("Wangg")
	var deck: Array = md.get("intent_deck", [])
	if deck.is_empty():
		return {}
	var by_key: Dictionary = {}
	for it in deck:
		by_key[it.get("intent_key", "")] = it
	# 优先级 3：偷盾事件旗（最高）。
	# 注意：steal_armed 的【消费】移到 _resolve_wangg_intent 的 steal_shield 结算处，
	# 此处只据此决定「下一个意图」，不立即清零——保证意图生成后锁定、执行前不被推翻。
	if caster.ai_memory.get("steal_armed", false):
		if by_key.has("steal_shield"):
			return by_key["steal_shield"]
	# 优先级 2：意图1 用满 2 次 → 出赃物（用后清零，下次重新攒）。
	if caster.ai_memory.get("intent1_count", 0) >= 2:
		caster.ai_memory["intent1_count"] = 0
		if by_key.has("apply_loot"):
			return by_key["apply_loot"]
	# 默认 1：攻击。
	if by_key.has("atk"):
		return by_key["atk"]
	return deck[0]


## ── UID002 Wangg 专属意图结算 ──
## 意图1·攻击：解析 N*M 总伤害打敌对单体；结算后 意图1 计数器 +1（驱动「攒 2 次出赃物」）。
## 意图2·施加赃物：给【没有赃物】的玩家目标 2 层【赃物】（不重复/不刷新）；计数已在 _wangg_pick_intent 用前清零。
## 意图3·偷取护盾：取一个带护盾的友方(非自身)，移除其护盾并等量加给 Wangg（净转移，不凭空生成）；消费 steal_armed 旗。
func _resolve_wangg_intent(caster: UnitRoot, intent: Dictionary) -> void:
	var key: String = intent.get("intent_key", "")
	match key:
		"atk":
			var targets := _pick_intent_targets(intent, caster)
			var total := _enemy_attack_damage(caster, intent)
			_apply_stat("damage", total, 1, targets, caster)
			caster.ai_memory["intent1_count"] = caster.ai_memory.get("intent1_count", 0) + 1
			print("[BR-wangg] 意图1 攻击：%s 打出，intent1_count=%d" % [caster.unit_id, caster.ai_memory["intent1_count"]])
		"apply_loot":
			var targets := _pick_intent_targets(intent, caster)
			for t in targets:
				if is_instance_valid(t):
					t.add_buff("loot", 2, 2)   # 2 层赃物（loot buff 的 tone=2 减益）
					print("[BR-wangg] 意图2 施加赃物：%s +2 层赃物" % t.unit_id)
		"steal_shield":
			var friends := _pick_intent_targets(intent, caster)
			if not friends.is_empty():
				var f := friends[0] as UnitRoot
				var amt := f.get_shield()
				if amt > 0.0:
					f.reduce_shield(amt)
					caster.gain_shield(amt)
					print("[BR-wangg] 意图3 偷取护盾：从 %s 转移 %d 护盾到 %s" % [f.unit_id, int(amt), caster.unit_id])
			caster.ai_memory["steal_armed"] = false
		_:
			pass


## 怪物意图攻击总伤害 = 解析 N*M + 施法者士气加成（与玩家攻击牌同享「士气增强自身输出」逻辑）。
## 攻击者自身士气层数越高，其攻击牌 / 攻击意图造成的伤害关键数值越高。
func _enemy_attack_damage(caster: UnitRoot, intent: Dictionary) -> int:
	return _parse_intent_value(intent.get("value", "")) + _morale_bonus(caster)

## 解析意图数值文字：支持纯数字（"5"→5）与连击形式（"N*M"→N×M）；无法解析回退 2（保旧行为）。
func _parse_intent_value(value: String) -> int:
	var s := value.strip_edges()
	if s.is_valid_int():
		return s.to_int()
	var parts := s.split("*")
	if parts.size() == 2:
		var a := int(parts[0])
		var b := int(parts[1])
		if a > 0 and b > 0:
			return a * b
	return 2


## 怪物施法者美术态（按意图类型映射）：att=攻击(1) / shield=蓄力(4) / state=施法(2) / think=待机(0)。
func _enemy_cast_state(type_id: String) -> int:
	match type_id:
		"att": return UnitRoot.UnitArtState.ATTACK
		"shield": return UnitRoot.UnitArtState.CHARGE
		"state": return UnitRoot.UnitArtState.CAST
		"think", "?": return UnitRoot.UnitArtState.IDLE
		_: return UnitRoot.UnitArtState.ATTACK


## 按意图(规则2 攻击范围)挑选合规目标；怪物=范围内多名则取【ATB 队列顺序第一个】满足条件的目标(单体) / 全部(群体)。
## 数据来自意图的 target_faction(相对)/target_range(-1=全场)/scope，取代规则一前后排标签。
## think/shield 无 target_faction 时返回空（演出组仅怪物单体；shield 作用于自身不挑目标）。
## 选靶规则（用户 2026-09-27 确立）：范围内多名但只需一个时，**不再随机**——按 ATB 队列先后顺序取第一个满足条件的目标。
## resolve_targets_by_range 返回顺序即 cell0→队尾（前→后），故 candidates[0] 即「攻击范围从 ATB 队列先后选第一个」。
## 引导卡回声(待实现)与怪物意图共用同一条「取第一个」规则；玩家即时卡由玩家点选，不在此随机/取首。
func _pick_intent_targets(intent: Dictionary, caster: UnitRoot) -> Array[UnitRoot]:
	var out: Array[UnitRoot] = []
	# 特殊选靶：队列最末端敌对单体（ATB 队尾、等待最久的玩家单位）。忽略范围，全队列取 cell 最大者。
	if intent.get("target_id", "") == "backmost_hostile":
		var b := _pick_backmost_hostile(caster)
		if is_instance_valid(b):
			return [b]
		return out
	# 特殊选靶：施加赃物——锁定一个【没有赃物】的玩家单位（跳过已持有者；全场玩家均已有赃物 → no-op）。
	if intent.get("target_id", "") == "loot_monomer":
		for u in _get_units():
			if u is UnitRoot and (u as UnitRoot).unit_faction == "player" and (u as UnitRoot).get_buff_stacks("loot") <= 0:
				out.append(u as UnitRoot)
				break
		return out
	# 特殊选靶：偷取护盾——锁定一个【带护盾】的友方(同侧, 非自身)。
	if intent.get("target_id", "") == "friend_shielded_monomer":
		for u in _get_units():
			if u is UnitRoot:
				var ur := u as UnitRoot
				if ur.unit_faction == caster.unit_faction and ur.unit_id != caster.unit_id and ur.get_shield() > 0.0:
					out.append(ur)
					break
		return out
	var tf: String = intent.get("target_faction", "")
	var tr: int = intent.get("target_range", -1)
	var sc: String = intent.get("scope", "单体")
	if tf == "":
		return out
	var candidates := resolve_targets_by_range(caster, tf, tr, sc)
	if candidates.is_empty():
		return out
	if sc == "群体":
		return candidates
	# 单体：范围内多名→按 ATB 队列先后顺序取第一个满足条件的目标（非随机）；玩家即时卡才点选，怪物不点选。
	var first: Array[UnitRoot] = []
	first.append(candidates[0])
	return first

## 队列最末端敌对单体：返回 ATB 队列中 cell 索引最大（等待最久）的玩家单位；无则返回 null。
## 用于 Mafe 意图1（打最靠后的玩家）。
func _pick_backmost_hostile(caster: UnitRoot) -> UnitRoot:
	if not is_instance_valid(atb_track):
		return null
	var best: UnitRoot = null
	var best_cell := -1
	for u in _get_units():
		if u is UnitRoot:
			var ur := u as UnitRoot
			if ur.unit_faction == "player":   # 敌对 = 玩家（施法者为敌方 Mafe）
				var c := atb_track.get_unit_cell(ur.unit_id)
				if c > best_cell:
					best_cell = c
					best = ur
	return best




## 【规则一·已归档】随机为场上所有单位赋予前后排属性（仅规则一使用；规则二下由 _ready 跳过此调用）。
## 每个单位独立以 50% 概率落入后排(is_back_row=true)，其余为前排。
## 前后排由 UnitRoot.is_back_row 驱动（含后排渐变遮罩材质的自动切换）。
## 若后续需要「每边保证前后排数量平衡」，把此处的 randf() < 0.5 换成按阵营配额逻辑即可。
func _randomize_unit_rows() -> void:
	var units := get_node_or_null("Units") as Node2D
	if units == null:
		return
	for u in units.get_children():
		if u is UnitRoot:
			(u as UnitRoot).is_back_row = randf() < 0.5
	

## ── 周周（Zhouzhou）特殊卡专属结算 ─────────────────────────────────────────────
## 入场分发：按 CardData.special 调用对应专属逻辑。所有特殊卡均为 即时(蓝) 卡，
## 由 apply_card_effect 入队、本函数在演出结束后（flush_deferred_effects）统一落点。
## mult = 连锁倍率 M(n)，作用于「主数值」（位移/护盾格数等按文档放大细则处理）。
func _apply_special_card(cd: CardData, caster: UnitRoot, target: UnitRoot, mult: float, is_copy: bool = false) -> void:
	if cd == null or not is_instance_valid(caster):
		return
	match cd.special:
		"ZZ_youshen":   _special_youshen(cd, caster, target, mult, is_copy)
		"ZZ_wenyunshou":_special_wenyunshou(cd, caster, mult, is_copy)
		"ZZ_qianjun":   _special_qianjun(cd, caster, target, mult)
		"ZZ_yanluo":    _special_yanluo(cd, caster, mult, is_copy)
		"ZZ_qianli":    _special_qianli(cd, caster, mult, is_copy)
		"ZZ_shibu":     _special_shibu(cd, caster, target, mult)
		"ZZ_tage":      if not is_copy: _special_tage(caster)        # C3 踏歌：仅周周池闪回；副本不再生成
		"ZZ_guanqi":    if not is_copy: _special_guanqi(caster)      # R2 仙人观棋：全角色池闪回；副本不再生成
		_: push_warning("[BR-special] 未知 special 标识: %s" % cd.special)

## C3 踏歌：本回合获 1 张周周卡闪回（池=仅周周）。经 HandManager 生成临时副本，按原卡费用支付。
func _special_tage(caster: UnitRoot) -> void:
	_generate_flashback_for(caster, "zhouzhou", 1)

## R2 仙人观棋：获 2 闪回（池=全角色）。经 HandManager 生成临时副本，按原卡费用支付。
func _special_guanqi(caster: UnitRoot) -> void:
	_generate_flashback_for(caster, "all", 2)

## 经 HandManager 生成闪回临时副本（不入牌库、不减少原卡）；owner=施法者角色，按原卡费用支付。
## pool_scope: "zhouzhou"=仅周周池 / "all"=全角色池（按触发源参数化）。
func _generate_flashback_for(caster: UnitRoot, pool_scope: String, count: int) -> void:
	if not is_instance_valid(caster):
		return
	var hm := get_tree().get_first_node_in_group("hand_manager") as HandManager
	if not is_instance_valid(hm):
		return
	hm.generate_flashback(caster.unit_id, pool_scope, count)

## §1 被动·队列操盘者：周周造成【前进/后退】→ 自身 +1×精通 层士气（每张队列卡结算 1 次）。
## §9 被动·闪回：周周位移（敌/友/被位移）同时生成 1 张闪回（仅周周池）；is_copy=true（闪回副本打出）时跳过生成，防无限循环。
## 仅周周拥有该被动；精通经 get_mastery() 读取（默认 1）。
func _trigger_zhouzhou_displace_passive(caster: UnitRoot, is_copy: bool = false) -> void:
	if not is_instance_valid(caster) or caster.unit_id != "Zhouzhou":
		return
	var m: int = 1
	if caster.has_method("get_mastery"):
		m = maxi(1, caster.get_mastery())
	caster.add_buff("morale", m, 1)
	print("[BR-passive] 周周造成位移 → 自身 +%d 层【士气】(精通=%d)" % [m, m])
	if not is_copy:
		_generate_flashback_for(caster, "zhouzhou", 1)   # §9：位移 → 生成 1 张闪回（仅周周池）

## 队列末端单位（任意阵营，含敌友）：取 cell 索引最大者。供 C5 问云手使用。
func _pick_backmost_any() -> UnitRoot:
	if not is_instance_valid(atb_track):
		return null
	var best: UnitRoot = null
	var best_cell := -1
	for u in _get_units():
		if u is UnitRoot:
			var ur := u as UnitRoot
			var c := atb_track.get_unit_cell(ur.unit_id)
			if c > best_cell:
				best_cell = c
				best = ur
	return best

## R1 千军借势·集士气：聚合其他角色身上的士气层数、移除原主、为周周添加同等层数。返回聚合层数。
func _collect_morale_to_caster(caster: UnitRoot) -> int:
	var total := 0
	for u in _get_units():
		if u is UnitRoot and (u as UnitRoot).unit_faction == "player" and u != caster:
			var s := (u as UnitRoot).get_buff_stacks("morale")
			if s > 0:
				total += s
				(u as UnitRoot).remove_buff("morale")
	if total > 0:
		caster.add_buff("morale", total, 1)
	return total

## C2 游身：选 1 单位（敌/友，沙漏2 内，不可对自身）后退 1 格；若目标为友方额外 +5 盾。触发 §1 被动。
func _special_youshen(cd: CardData, caster: UnitRoot, target: UnitRoot, mult: float, is_copy: bool = false) -> void:
	if not is_instance_valid(target) or target == caster:
		print("[BR-special] C2 游身：目标无效/不可对自身，no-op")
		return
	var is_ally: bool = (target.unit_faction == caster.unit_faction)
	atb_track.retreat_unit(target.unit_id, 1)
	if is_ally:
		var sh := int(roundf(5.0 * mult))
		target.gain_shield(sh)
		print("[BR-special] C2 游身：友方 %s 后退1 + %d 护盾" % [target.unit_id, sh])
	else:
		print("[BR-special] C2 游身：敌方 %s 后退1" % target.unit_id)
	_trigger_zhouzhou_displace_passive(caster, is_copy)

## C5 问云手：对队列末端单位（无论友敌）造成 2 伤并使其前进 1 格。触发 §1 被动。
func _special_wenyunshou(cd: CardData, caster: UnitRoot, mult: float, is_copy: bool = false) -> void:
	var t := _pick_backmost_any()
	if not is_instance_valid(t):
		print("[BR-special] C5 问云手：无末端单位，no-op")
		return
	var dmg := int(roundf(float(2 + _morale_bonus(caster)) * mult))
	t.damage(dmg)
	print("[BR-special] C5 问云手：末端 %s 受到 %d 伤并前进1" % [t.unit_id, dmg])
	if is_instance_valid(t) and t.get_current_hp() <= 0.0:
		t.die()
	atb_track.advance_unit(t.unit_id, 1)
	_trigger_zhouzhou_displace_passive(caster, is_copy)

## R1 千军借势：获取其他角色士气集中于周周；造成 6 伤；周周每 5 层士气再 +6 伤（不含全局士气加成，士气已转移消耗）。
func _special_qianjun(cd: CardData, caster: UnitRoot, target: UnitRoot, mult: float) -> void:
	var collected := _collect_morale_to_caster(caster)
	var extra := (collected / 5) * 6
	var base := 6 + extra
	var dmg := int(roundf(float(base) * mult))
	if is_instance_valid(target):
		target.damage(dmg)
		print("[BR-special] R1 千军借势：集 %d 士气 → 对 %s 造成 %d 伤" % [collected, target.unit_id, dmg])
		if target.get_current_hp() <= 0.0:
			target.die()
	else:
		print("[BR-special] R1 千军借势：无有效目标，no-op（集士气=%d）" % collected)

## R3 雁落京门：范围内（cell0）敌方击退 1 格；每击退 1 敌 +2 盾。触发 §1 被动。
func _special_yanluo(cd: CardData, caster: UnitRoot, mult: float, is_copy: bool = false) -> void:
	var enemies := resolve_targets_by_range(caster, "敌方", 0, "群体")
	var count := 0
	for e in enemies:
		if not is_instance_valid(e):
			continue
		atb_track.retreat_unit(e.unit_id, 1)
		count += 1
	if count > 0:
		var sh := int(roundf(2.0 * float(count) * mult))
		caster.gain_shield(sh)
		print("[BR-special] R3 雁落京门：击退 %d 敌 → 周周 +%d 盾" % [count, sh])
		_trigger_zhouzhou_displace_passive(caster, is_copy)
	else:
		print("[BR-special] R3 雁落京门：cell0 无敌方，no-op")

## E1 千里不留行：所有友方（不含自身）前进 2 格。触发 §1 被动。位移格数随连锁放大。
func _special_qianli(cd: CardData, caster: UnitRoot, mult: float, is_copy: bool = false) -> void:
	var steps := int(roundf(2.0 * mult))
	for u in _get_units():
		if u is UnitRoot and (u as UnitRoot).unit_faction == caster.unit_faction and u != caster:
			atb_track.advance_unit((u as UnitRoot).unit_id, steps)
	print("[BR-special] E1 千里不留行：友方（不含自身）前进 %d 格" % steps)
	_trigger_zhouzhou_displace_passive(caster, is_copy)

## E2 十步杀一人：造成 10 伤；伤害随本场同名卡牌最高伤害更新（含士气等临时 buff 滚雪球）。
func _special_shibu(cd: CardData, caster: UnitRoot, target: UnitRoot, mult: float) -> void:
	var base := 10
	if _damage_record.has(cd.id):
		base = maxi(10, _damage_record[cd.id])
	var dmg := int(roundf(float(base + _morale_bonus(caster)) * mult))
	if is_instance_valid(target):
		target.damage(dmg)
		print("[BR-special] E2 十步杀一人：对 %s 造成 %d 伤（记录上限=%d）" % [target.unit_id, dmg, base])
		if target.get_current_hp() <= 0.0:
			target.die()
		_damage_record[cd.id] = maxi(_damage_record.get(cd.id, 0), dmg)
	else:
		print("[BR-special] E2 十步杀一人：无有效目标，no-op")

class_name CardData
extends Resource

## 单张卡牌静态数据（由 CardBaseInfo.xlsx 经 card_data_gen.gd 自动生成，运行时只读）。
## 字段命名对齐 CardBaseInfo.xlsx；数值类型对齐 CardRoot 的 @export（card_type/cost_type/rarity 均为 int）。

@export var id: String = ""
@export var card_name: String = ""
@export var belong_to: String = ""            # Zhouzhou / Irene / Rocket
@export var card_type: int = 0                # 0=攻击 1=状态 2=防御/功能（仅供美术态/兜底；效果以 effect_id 为准）
@export var cost_type: int = 0                # 0=即时 1=执行（玩法字段，菱形色由 cost_color 驱动）
@export var cost_value: int = 1
@export var cost_color: int = 0                # 费用色(菱形色+1+1匹配轴)：0蓝(00a1ff) 1橙(ff8c33) 2绿(70ab3b)
@export var target_type: String = "SingleEnemy"   # 兼容性保留字段，解析以 target_faction/target_range+scope 为准
## ── 单一索敌标签（【规则一·已归档】取代旧 target_row+relative_row 双字段）──
## 前排/后排/同排/异排/全部。规则二下索敌改用下方 target_faction/target_range，本字段保留仅供兼容/兜底。
@export var target_tag: String = "全部"         # 【规则一·已归档】前排/后排/同排/异排/全部（单一）
@export var scope: String = "单体"             # 单体/群体
## ── 攻击范围（规则2 · 取代规则一前后排标签）──
## target_faction 相对施法者：敌方(对立阵营) / 我方(同阵营) / 全场(全部)。
## target_range：从「高亮框(第0格=行动单位)」向队列前方数的连续格数；覆盖 cells 0..range（含两端）；
##   -1 = 全场（忽略格数，取该阵营全部单位）。range 0 仅含 cell0（= 施法者自身）。
## 范围多名目标时：怪物=随机选一(att/bleed)；角色卡=玩家点选(蓝卡手动)；无有效目标→角色卡灰掉不可打(全场卡恒可打)。
@export var target_faction: String = "敌方"
@export var target_range: int = 1               # -1 = 全场
## ── 效果原型（规则2 可复用效果原型系统）──
## effect_id 指向 EFFECT_ARCHETYPES 中的原型 key；关键数值落在 key_value
## （攻击=威力/状态=层数/防御=护盾或血量/位移=格数）。hits 仅多段攻击(damage_multi)用，默认 1。
## effects_text 由 derived_effect_text() 自动重建，不再手填原始标签。
@export var effect_id: String = ""
@export var key_value: int = 2
@export var hits: int = 1
@export var rarity: int = 1                    # 1/2/3
@export var enhanced: bool = false
@export var art_id: String = ""                # 卡面文件名（无下划线，如 Zhouzhou001.png）
@export var effects_text: String = ""          # 效果标签（derived_effect_text 重建后的展示文案，解析兜底用）
@export var keywords: String = ""
@export var special: String = ""              # 特殊卡标识：非空时由 BattleRoot._apply_special_card 走专属逻辑（跳过通用效果原型 effect_id）
@export var description: String = ""

## 可复用效果原型（8 款式 + 衍生）。stat 决定 apply_card_effect 落到哪个数值通道。
## tpl：阵营/范围前缀为纯文本(不带【】)；关键数值位为纯数字(不带【】，由卡面加左右留空位+扁桃体放大)；
##   仅词条(伤害/护盾/血量/士气/出血…)保留【…】(黑色，不另上色)；damage_multi 用 %d(段数)+%s(每段威力含箭头)。
const EFFECT_ARCHETYPES: Dictionary = {
	"damage_single": {"ct": 0, "stat": "damage", "tpl": "对%s造成%s点【伤害】"},
	"damage_multi":  {"ct": 0, "stat": "damage", "tpl": "对%s造成%d次%s点【伤害】"},
	"damage_all":    {"ct": 0, "stat": "damage", "tpl": "对%s造成%s点【伤害】"},
	"shield":        {"ct": 2, "stat": "shield", "tpl": "获得%s点【护盾】"},
	"heal":          {"ct": 2, "stat": "heal",   "tpl": "回复%s点【血量】"},
	"move":          {"ct": 2, "stat": "move",   "tpl": "使单个目标前进%s格"},
	"morale":        {"ct": 1, "stat": "morale", "tpl": "为%s获得%s层【士气】"},
	"bleed":         {"ct": 1, "stat": "bleed",  "tpl": "对%s造成%s层【出血】"},
}

## 返回原型对应 stat（未知→"damage" 兜底）。
func archetype_stat() -> String:
	var a: Dictionary = EFFECT_ARCHETYPES.get(effect_id, {}) as Dictionary
	if a.is_empty():
		return "damage"
	return (a.get("stat", "damage") as String)

## 重建卡面效果文字（权威来源）：原型模板 + 攻击范围(阵营·范围) + 关键数值。
## override_key>=0 时用它替换 key_value（连锁提升数值时由 HandManager 调用，显示放大后的数值）。
## morale_bonus>=0 时把士气加成叠加到关键数值上（攻击牌实时显示「基础+士气」；非攻击牌由调用方传 0）。
## 关键数值后附升降箭头：显示值 > 基础值(key_value，含士气/连锁提升)→▲；<→▼；相等→空。
func derived_effect_text(override_key: int = -1, override_hits: int = -1, morale_bonus: int = 0) -> String:
	var a: Dictionary = EFFECT_ARCHETYPES.get(effect_id, {}) as Dictionary
	if a.is_empty():
		return _legacy_effect_text()
	var base_key: int = key_value
	var key: int = (override_key if override_key >= 0 else key_value) + morale_bonus
	var h: int = override_hits if override_hits >= 0 else hits
	var arrow: String = _arrow_for(key, base_key)
	var key_str: String = "%d%s" % [key, arrow]
	# 规则二攻击范围文案：对【阵营·范围】…；自身(我方·范围0)不加前缀。
	# 范围(⏳ 时间轴距离)由卡面固定徽章统一呈现，效果文字仅保留阵营前缀，避免信息重复。
	var prefix: String = ""
	if not (target_faction == "我方" and target_range == 0):
		prefix = target_faction   # 阵营前缀为纯文本，不带【】
	match effect_id:
		"damage_multi":
			return (a["tpl"] as String) % [prefix, h, key_str]
		"shield", "heal", "move":
			return (a["tpl"] as String) % [key_str]
		_:
			return (a["tpl"] as String) % [prefix, key_str]

## 关键数值升降箭头：显示值 > 基础值(卡牌原始 key_value，含士气加成/连锁提升)→▲(增益)；
## 显示值 < 基础值(被削减)→▼；相等→空。供卡面实时呈现数值涨跌。
func _arrow_for(key: int, base: int) -> String:
	if key > base:
		return "▲"
	elif key < base:
		return "▼"
	return ""

## 连锁提升后（已 ×M(ring_count)）的卡面文字：先叠加士气加成到基础值，再一次性乘 M(ring_count) 重建。
## morale_bonus 由调用方按「该卡是否为攻击牌」计算（攻击牌=施法者士气层数×每层加成，非攻击牌=0）。
func boosted_text(ring_count: int, morale_bonus: int = 0) -> String:
	var m: float = 1.0 + 0.25 * float(ring_count) + 0.05 * float(ring_count) * float(ring_count)
	var boosted: int = int(roundf(float(key_value + morale_bonus) * m))
	return derived_effect_text(boosted, -1, 0)

## 兼容旧数据（无 effect_id）：按 card_type 占位（攻击2伤/防御2盾/状态2层），后续所有卡都应补全 effect_id。
## 阵营/数值均不带【】；仅词条保留【…】(黑色)。
func _legacy_effect_text() -> String:
	var tag: String = target_tag if target_tag != "" else ""
	match card_type:
		0: return ("对%s" % tag) + "造成2点【伤害】" if tag != "" else "造成2点【伤害】"
		2: return "获得2点【护盾】"
		1:
			if target_tag in ["前排", "后排"]:
				return ("对%s" % tag) + "造成2层【出血】" if tag != "" else "造成2层【出血】"
			return ("为%s" % tag) + "获得2层【士气】" if tag != "" else "获得2层【士气】"
		_: return ""

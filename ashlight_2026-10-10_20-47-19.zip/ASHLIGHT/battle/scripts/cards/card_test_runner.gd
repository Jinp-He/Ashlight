extends Node2D

## cardtest 场景控制器：放置一张随机卡牌 + 「封装3D」按钮 + 「旋转卡牌」按钮。
##
## 伪3D 思路（参考卡牌工程 Demo 0.2 的 card_UI.gd）：
##   - 把「正面活卡」与「卡背贴图」分别渲染进两个离屏 SubViewport，得到两张快照纹理；
##   - 正面 / 背面各用一个 fake3d 着色器显示，且【背面的 y_rot 比正面偏移 -180°】；
##   - 着色器的 cull_back 会剔除背对相机的那一面（p.z <= 0 即丢弃），于是同一时刻
##     只有朝向观察者的那一面可见 —— 这天然产生「真实 3D 翻面 + 透视压扁」，
##     无需手动 scale.x 压扁或切换可见性。
##   - 鼠标跟随的伪3D 倾斜（x_rot / y_rot）叠在两面之上；翻面角 flip_theta 只喂给 y_rot。
##
## 「封装3D」= 进入双视口伪3D 显示；「还原卡牌」= 把原卡移回原位（仍是活卡）。
## 「旋转卡牌」= 用「角速度衰减」物理模型驱动 flip_theta（绕竖轴），转到力度不足时
##   弹簧回正到最近的「正面」。

const FAKE3D_SHADER: Shader = preload("res://battle/scripts/cards/fake3d.gdshader")
const ANGLE_MAX_DEG: float = 24.0
const CARD_W: float = 400.0   # 与正面卡牌底图(card_base/card_frame 均为 400x576)一致 → 卡背对齐
const CARD_H: float = 576.0
## SubViewport 取卡牌 2x 边长（4x 面积）。卡在视口内保持原生 scale=1、只占中心 50%，
## 给 fake3d 的透视过扫留边距；显示时 TextureRect 用视口同尺寸 1:1 映射 → 卡在屏上与原单卡等大同位。
const VP_SCALE: float = 2.0

## 旋转式翻面参数（flip_theta = 绕竖轴旋转角，弧度；用「角速度衰减」物理模型驱动）：
##   按下 → 注入初速度 SPIN_OMEGA（第一圈最快），角速度按 SPIN_DRAG 指数衰减 → 旋转逐渐变慢；
##   当角速度跌破 OMEGA_THRESHOLD（"力度不够"）→ 切换为「弹簧回正」：以 settle_stiffness/settle_damping
##   组成的阻尼弹簧把卡牌拉回最近的「正面」，过冲一点点后再停（"弹回去"的弹性手感）。
##   —— 整段比上一版更快：初速度更大、衰减更猛、阈值更高、回正更脆。
const SPIN_OMEGA: float = 95.0      # 初始角速度 (rad/s)：更大 → 第一圈更快
const SPIN_DRAG: float = 5.0        # 角速度衰减率 (1/s)：更大 → 衰减更快、停得更早、总时长更短
const OMEGA_THRESHOLD: float = 8.0  # 角速度下限 (rad/s)：更高 → 更早切换 → 回正更快
## 弹簧回正参数（@export，可在检视面板直接调"力度"）：
##   settle_stiffness 越大 → 拉回越猛、过冲越明显（"弹回去"越强）；settle_damping 越大 → 回正越黏、过冲越小。
@export var settle_stiffness: float = 72.0
@export var settle_damping: float = 12.0

@onready var card_slot: Node2D = $CardSlot
@onready var front_disp: TextureRect = $PseudoDisplay
@onready var package_button: Button = $PackageButton
@onready var rotate_button: Button = $RotateButton

var back_disp: TextureRect = null       # 背面显示层（与正面叠放，cull_back 决定谁可见）
var card: CardRoot
var flip: Node2D = null                # 未封装时承载「正面卡 + 背面设计」的容器
var card_back_scene: Node2D = null     # 背面设计节点（渲染进 back_viewport）
var front_viewport: SubViewport = null
var back_viewport: SubViewport = null

var packaged: bool = false
var busy: bool = false
var flipping: bool = false
var pointer_inside: bool = false

## 旋转物理状态机：IDLE(静止) → SPINNING(角速度衰减中) → SETTLING(弹性回正中)
enum SpinState { IDLE, SPINNING, SETTLING }
var _spin_state: SpinState = SpinState.IDLE
var _spin_theta: float = 0.0      # 当前翻面角（弧度）
var _spin_omega: float = 0.0      # 当前角速度（rad/s）
var _settle_target: float = 0.0   # 回正锁定的目标角：进入 SETTLING 时算一次后固定，绝不每帧重算

## 当前倾斜角度（度），平滑插值用
var _cur_x: float = 0.0
var _cur_y: float = 0.0

func _ready() -> void:
	_spawn_random_card()

	# 背面显示层（与正面叠放；鼠标只交给正面层捕获）
	back_disp = TextureRect.new()
	back_disp.name = "BackDisplay"
	back_disp.mouse_filter = Control.MOUSE_FILTER_IGNORE
	back_disp.z_index = 0
	back_disp.visible = false
	add_child(back_disp)

	package_button.text = "封装3D"
	package_button.pressed.connect(_on_package_pressed)

	front_disp.mouse_filter = Control.MOUSE_FILTER_STOP
	front_disp.z_index = 1
	front_disp.mouse_entered.connect(_on_display_entered)
	front_disp.mouse_exited.connect(_on_display_exited)
	front_disp.visible = false
	front_disp.size = Vector2(CARD_W, CARD_H)

	var center: Vector2 = get_viewport_rect().size * 0.5
	card_slot.global_position = center

	package_button.size = Vector2(180.0, 54.0)
	package_button.position = center + Vector2(-90.0, CARD_H * 0.5 + 60.0)

	rotate_button.size = Vector2(180.0, 54.0)
	rotate_button.position = center + Vector2(90.0, CARD_H * 0.5 + 60.0)
	rotate_button.pressed.connect(_on_rotate_pressed)

## 构建未封装态：FlipContainer 持有「正面活卡 + 背面设计」，翻转时整体移交双视口渲染。
func _spawn_random_card() -> void:
	flip = Node2D.new()
	flip.name = "FlipContainer"
	card_slot.add_child(flip)
	flip.position = Vector2.ZERO

	# 正面：活的整张卡（含边框/卡面/费用/文字）
	card = CardRoot.new()
	flip.add_child(card)
	card.position = Vector2.ZERO
	card.scale = Vector2.ONE
	card.randomize_combo()      # 先入树触发 _ready/_build，_base 等子节点才存在

	# 背面：卡背贴图（res://assets/cards/card_back.png，UI_Card 美术），渲染进 back_viewport
	card_back_scene = _build_card_back()
	card_back_scene.visible = false
	flip.add_child(card_back_scene)

## 卡背：直接复用美术贴图（res://assets/cards/card_back.png，源 UI_Card 442x638）。
## 尺寸对齐正面卡牌（CARD_W x CARD_H = 400x576，与 card_base/card_frame 一致），
## stretch 填满 → 卡背边缘与正面严丝合缝，翻面透视完全一致。
func _build_card_back() -> Node2D:
	var root := Node2D.new()
	root.name = "CardBack"

	var tex := load("res://assets/cards/card_back.png") as Texture2D
	if tex == null:
		push_warning("card_test_runner: 卡背贴图未导入，使用占位色块（路径 res://assets/cards/card_back.png）")
		var ph := ColorRect.new()
		ph.size = Vector2(CARD_W, CARD_H)
		ph.position = -Vector2(CARD_W, CARD_H) * 0.5
		ph.color = Color(0.12, 0.13, 0.22)
		root.add_child(ph)
		return root

	var tr := TextureRect.new()
	tr.texture = tex
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE   # 拉伸填满 CARD_W x CARD_H（442x638→400x576，纵横比差异<0.3% 可忽略）
	tr.size = Vector2(CARD_W, CARD_H)
	tr.position = -Vector2(CARD_W, CARD_H) * 0.5      # 根节点即卡中心：贴图左上角偏移半尺寸 → 居中
	root.add_child(tr)
	return root

func _on_package_pressed() -> void:
	if busy or flipping:
		return
	if not packaged:
		_package_card()
	else:
		_unpackage_card()

## 封装：正面活卡 → front_viewport；背面设计 → back_viewport；两者各自套 fake3d 显示层。
## 正面 y_rot = 倾斜 + flip_theta；背面 y_rot = 倾斜 + flip_theta - 180（Demo 卡背技巧）。
func _package_card() -> void:
	busy = true

	front_viewport = _make_viewport()
	back_viewport = _make_viewport()
	add_child(front_viewport)
	add_child(back_viewport)

	# 正面活卡移入 front_viewport，居中、保持原生 scale=1
	card.reparent(front_viewport)
	card.position = front_viewport.size * 0.5
	card.scale = Vector2.ONE
	card.visible = true

	# 背面设计移入 back_viewport
	card_back_scene.reparent(back_viewport)
	card_back_scene.position = back_viewport.size * 0.5
	card_back_scene.scale = Vector2.ONE
	card_back_scene.visible = true

	# 两个显示层：分别采样各自视口的纹理，背面 y_rot 偏移在 _process 中持续写入
	front_disp.material = _make_fake3d_material()
	front_disp.texture = front_viewport.get_texture()
	front_disp.size = front_viewport.size
	front_disp.position = get_viewport_rect().size * 0.5 - front_viewport.size * 0.5
	front_disp.visible = true

	back_disp.material = _make_fake3d_material()
	back_disp.texture = back_viewport.get_texture()
	back_disp.size = back_viewport.size
	back_disp.position = front_disp.position
	back_disp.visible = true

	# 快速淡入（比之前更短）
	front_disp.modulate.a = 0.0
	back_disp.modulate.a = 0.0
	var tw := create_tween()
	tw.tween_property(front_disp, "modulate:a", 1.0, 0.09)
	tw.parallel().tween_property(back_disp, "modulate:a", 1.0, 0.09)

	packaged = true
	package_button.text = "还原卡牌"
	busy = false

## 还原：淡出销毁双视口快照，把原卡与卡背移回原位（仍是活卡）。
func _unpackage_card() -> void:
	busy = true
	var tw := create_tween()
	tw.tween_property(front_disp, "modulate:a", 0.0, 0.12)
	tw.parallel().tween_property(back_disp, "modulate:a", 0.0, 0.12)
	tw.tween_callback(_finish_unpackage)

func _finish_unpackage() -> void:
	if is_instance_valid(card) and is_instance_valid(front_viewport):
		card.reparent(flip)
		card.position = Vector2.ZERO
		card.scale = Vector2.ONE
		card.visible = true

	if is_instance_valid(card_back_scene) and is_instance_valid(back_viewport):
		card_back_scene.reparent(flip)
		card_back_scene.position = Vector2.ZERO
		card_back_scene.scale = Vector2.ONE
		card_back_scene.visible = false

	front_disp.material = null
	front_disp.texture = null
	front_disp.modulate.a = 1.0
	front_disp.visible = false

	back_disp.material = null
	back_disp.texture = null
	back_disp.modulate.a = 1.0
	back_disp.visible = false

	if is_instance_valid(front_viewport):
		front_viewport.queue_free()
		front_viewport = null
	if is_instance_valid(back_viewport):
		back_viewport.queue_free()
		back_viewport = null

	_cur_x = 0.0
	_cur_y = 0.0
	packaged = false
	package_button.text = "封装3D"
	busy = false

## 旋转卡牌：给一个初速度，交给我们自己的物理积分（在 _process 里逐帧衰减）。
## 未封装时自动先封装，否则没有双面纹理可翻。
func _on_rotate_pressed() -> void:
	if flipping:
		return
	if not packaged:
		if busy:
			return
		_package_card()
	flipping = true
	_spin_theta = 0.0
	_spin_omega = SPIN_OMEGA
	_spin_state = SpinState.SPINNING

## 旋转物理积分（逐帧）：
##   SPINNING 段角速度指数衰减；跌破 OMEGA_THRESHOLD 即切换为弹簧回正（SETTLING）。
##   阈值判定【仅此一处】——一旦进入 SETTLING，下方 match 不会再回头判阈值，
##   所以回弹途中角速度哪怕因弹性过冲再次超过阈值，也绝不会「续杯」重新旋转。
##   SETTLING 用进入时锁定的 _settle_target（只算一次），整段回正不再重算目标，
##   避免过冲超半圈时目标跳到下一面而引发的「无限回弹 / 假续杯」。
func _spin_integrate(delta: float) -> void:
	match _spin_state:
		SpinState.SPINNING:
			_spin_omega *= exp(-SPIN_DRAG * delta)
			_spin_theta += _spin_omega * delta
			if _spin_omega < OMEGA_THRESHOLD:
				# 锁定回正目标：取运动前方最近的「正面」，只算这一次。
				var t: float = roundf(_spin_theta / TAU) * TAU
				if t < _spin_theta:
					t += TAU
				_settle_target = t
				_spin_state = SpinState.SETTLING
		SpinState.SETTLING:
			var accel: float = (_settle_target - _spin_theta) * settle_stiffness
			_spin_omega += accel * delta
			_spin_omega *= exp(-settle_damping * delta)
			_spin_theta += _spin_omega * delta
			if absf(_settle_target - _spin_theta) < 0.002 and absf(_spin_omega) < 0.05:
				_spin_theta = _settle_target
				_spin_state = SpinState.IDLE
				flipping = false

func _on_display_entered() -> void:
	pointer_inside = true

func _on_display_exited() -> void:
	pointer_inside = false

func _process(delta: float) -> void:
	# 旋转物理积分（始终运行，与是否封装无关）
	_spin_integrate(delta)

	if not packaged:
		return

	# 鼠标跟随伪3D 倾斜目标
	var tx: float = 0.0
	var ty: float = 0.0
	if pointer_inside:
		var lp: Vector2 = front_disp.get_local_mouse_position()
		var nx: float = clampf(remap(lp.x, 0.0, front_disp.size.x, 0.0, 1.0), 0.0, 1.0)
		var ny: float = clampf(remap(lp.y, 0.0, front_disp.size.y, 1.0, 0.0), 0.0, 1.0)
		tx = lerpf(-ANGLE_MAX_DEG, ANGLE_MAX_DEG, nx)
		ty = lerpf(-ANGLE_MAX_DEG, ANGLE_MAX_DEG, ny)

	# 倾斜插值更快（响应更脆）
	var k: float = minf(1.0, delta * 30.0)
	_cur_x = lerpf(_cur_x, tx, k)
	_cur_y = lerpf(_cur_y, ty, k)

	# 翻面角只喂 y_rot；背面偏移 -180°（Demo 卡背技巧）。cull_back 决定哪面可见。
	var flip_deg: float = rad_to_deg(_spin_theta)
	var fmat := front_disp.material as ShaderMaterial
	var bmat := back_disp.material as ShaderMaterial
	if fmat != null:
		fmat.set_shader_parameter("x_rot", _cur_x)
		fmat.set_shader_parameter("y_rot", _cur_y + flip_deg)
	if bmat != null:
		bmat.set_shader_parameter("x_rot", _cur_x)
		bmat.set_shader_parameter("y_rot", _cur_y + flip_deg - 180.0)

## 离屏渲染目标（透明背景，持续刷新以支持倾斜/文字变化）。
## 视口取卡 2x 边长 → 卡在视口内保持原生 scale=1、只占中心 50%，给透视过扫留边距。
func _make_viewport() -> SubViewport:
	var vp := SubViewport.new()
	vp.size = Vector2(CARD_W * VP_SCALE, CARD_H * VP_SCALE)
	vp.transparent_bg = true
	vp.disable_3d = true
	vp.handle_input_locally = false
	vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	return vp

## fake3d 着色器材质（纯透视形变，不含光效/阴影/抠色）。纹理由 TextureRect.texture 提供。
func _make_fake3d_material() -> ShaderMaterial:
	var mat := ShaderMaterial.new()
	mat.shader = FAKE3D_SHADER
	mat.set_shader_parameter("fov", 70.0)   # 更小=透视形变越夸张（90→70：明显加强）
	mat.set_shader_parameter("cull_back", true)
	mat.set_shader_parameter("inset", 0.0)
	mat.set_shader_parameter("x_rot", 0.0)
	mat.set_shader_parameter("y_rot", 0.0)
	return mat

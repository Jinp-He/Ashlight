## 自动生成，勿手改。来源：CardBaseInfo.xlsx（周周 8 张最终卡 + 其他角色占位卡）。
## 规则2 效果原型系统 + 卡表三轴（基础类型 / 施放类型 cost_color / 攻击范围 沙漏记法）。
## 注意：周周 C3 踏歌 / R2 仙人观棋 依赖「闪回」子系统（本期未实装），故卡组暂落 8 张。
class_name CardDataGen
extends RefCounted

## 返回全部卡牌静态数据（由 xlsx 经生成脚本填充，运行时只读）。
func all_cards() -> Array[CardData]:
	var out: Array[CardData] = []
	var c: CardData

	# 轰击 — 防御·我方·单体·获得10点护盾
	c = CardData.new(); c.id="Rocket101"; c.card_name="轰击"; c.belong_to="Rocket"; c.card_type=2; c.cost_type=1; c.cost_value=4
	c.target_faction="我方"; c.target_range=0; c.scope="单体"; c.effect_id="shield"; c.key_value=10; c.hits=1
	c.cost_color=1; c.rarity=1; c.enhanced=false; c.art_id="Rocket007.png"; c.keywords=""; c.description=""
	c.effects_text = c.derived_effect_text(); out.append(c)

	# 回响 — 攻击·敌方·群体(全场)·造成5点伤害
	c = CardData.new(); c.id="Irene101"; c.card_name="回响"; c.belong_to="Irene"; c.card_type=0; c.cost_type=1; c.cost_value=4
	c.target_faction="敌方"; c.target_range=-1; c.scope="群体"; c.effect_id="damage_all"; c.key_value=5; c.hits=1
	c.cost_color=1; c.rarity=2; c.enhanced=false; c.art_id="Irene013.png"; c.keywords=""; c.description=""
	c.effects_text = c.derived_effect_text(); out.append(c)

	# 裂甲 — 防御·我方·单体·前进1格
	c = CardData.new(); c.id="Rocket102"; c.card_name="裂甲"; c.belong_to="Rocket"; c.card_type=2; c.cost_type=1; c.cost_value=3
	c.target_faction="我方"; c.target_range=1; c.scope="单体"; c.effect_id="move"; c.key_value=1; c.hits=1
	c.cost_color=1; c.rarity=1; c.enhanced=false; c.art_id="Rocket009.png"; c.keywords=""; c.description=""
	c.effects_text = c.derived_effect_text(); out.append(c)

	# 时滞 — 防御·我方·群体·前进1格（引导测试占位）
	c = CardData.new(); c.id="Irene102"; c.card_name="时滞"; c.belong_to="Irene"; c.card_type=2; c.cost_type=1; c.cost_value=2
	c.target_faction="我方"; c.target_range=1; c.scope="群体"; c.effect_id="move"; c.key_value=1; c.hits=1
	c.cost_color=2; c.rarity=1; c.enhanced=false; c.art_id="Irene012.png"; c.keywords=""; c.description=""
	c.effects_text = c.derived_effect_text(); out.append(c)

	# 织影 — 攻击·敌方·单体·造成10点伤害
	c = CardData.new(); c.id="Irene103"; c.card_name="织影"; c.belong_to="Irene"; c.card_type=0; c.cost_type=0; c.cost_value=3
	c.scope="单体"; c.effect_id="damage_single"; c.key_value=10; c.hits=1
	c.cost_color=0; c.rarity=2; c.enhanced=false; c.art_id="Irene010.png"; c.keywords=""; c.description=""
	c.effects_text = c.derived_effect_text(); out.append(c)

	# 召雷 — 状态·敌方·群体(全场)·造成3层出血
	c = CardData.new(); c.id="Irene104"; c.card_name="召雷"; c.belong_to="Irene"; c.card_type=1; c.cost_type=1; c.cost_value=1
	c.target_faction="敌方"; c.target_range=-1; c.scope="群体"; c.effect_id="bleed"; c.key_value=3; c.hits=1
	c.cost_color=1; c.rarity=2; c.enhanced=false; c.art_id="Irene002.png"; c.keywords=""; c.description=""
	c.effects_text = c.derived_effect_text(); out.append(c)

	# 凝滞 — 状态·我方·单体·获得3层士气
	c = CardData.new(); c.id="Irene105"; c.card_name="凝滞"; c.belong_to="Irene"; c.card_type=1; c.cost_type=0; c.cost_value=3
	c.target_faction="我方"; c.target_range=1; c.scope="单体"; c.effect_id="morale"; c.key_value=3; c.hits=1
	c.cost_color=0; c.rarity=3; c.enhanced=false; c.art_id="Irene009.png"; c.keywords=""; c.description=""
	c.effects_text = c.derived_effect_text(); out.append(c)

	# 燃烧 — 状态·我方·群体·获得3层士气
	c = CardData.new(); c.id="Rocket103"; c.card_name="燃烧"; c.belong_to="Rocket"; c.card_type=1; c.cost_type=1; c.cost_value=5
	c.target_faction="我方"; c.target_range=2; c.scope="群体"; c.effect_id="morale"; c.key_value=3; c.hits=1
	c.cost_color=1; c.rarity=3; c.enhanced=false; c.art_id="Rocket001.png"; c.keywords=""; c.description=""
	c.effects_text = c.derived_effect_text(); out.append(c)

	# 覆盖 — 状态·我方·单体·获得3层士气
	c = CardData.new(); c.id="Rocket104"; c.card_name="覆盖"; c.belong_to="Rocket"; c.card_type=1; c.cost_type=0; c.cost_value=3
	c.target_faction="我方"; c.target_range=1; c.scope="单体"; c.effect_id="morale"; c.key_value=3; c.hits=1
	c.cost_color=0; c.rarity=3; c.enhanced=false; c.art_id="Rocket004.png"; c.keywords=""; c.description=""
	c.effects_text = c.derived_effect_text(); out.append(c)

	# ── 周周（Zhouzhou）最终卡组（10 张 = 5普通 / 3稀有 / 2史诗；闪回子系统已落地，C3/R2 已接入）──
	# C1 崩拳 — 攻击·即时·沙漏2·单体 2*3 伤
	c = CardData.new(); c.id="Zhouzhou01"; c.card_name="崩拳"; c.belong_to="Zhouzhou"; c.card_type=0; c.cost_type=0; c.cost_value=3
	c.target_faction="敌方"; c.target_range=2; c.scope="单体"; c.effect_id="damage_multi"; c.key_value=2; c.hits=3
	c.cost_color=0; c.rarity=1; c.enhanced=false; c.art_id="Zhouzhou01.png"; c.keywords=""; c.description=""
	c.effects_text = c.derived_effect_text(); out.append(c)

	# C2 游身 — 防御·即时·沙漏2·1单位后退1；友方额外+5盾（不可对自身）
	c = CardData.new(); c.id="Zhouzhou08"; c.card_name="游身"; c.belong_to="Zhouzhou"; c.card_type=2; c.cost_type=0; c.cost_value=3
	c.target_faction="全场"; c.target_range=2; c.scope="单体"; c.effect_id=""; c.key_value=0; c.hits=1
	c.special="ZZ_youshen"; c.cost_color=0; c.rarity=1; c.enhanced=false; c.art_id="Zhouzhou08.png"; c.keywords=""; c.description=""
	c.effects_text = "使1单位后退1格；友方额外+5护盾"; out.append(c)

	# C3 踏歌 — 状态·即时·自身·本回合获1张周周卡闪回（池=仅周周）
	c = CardData.new(); c.id="Zhouzhou02"; c.card_name="踏歌"; c.belong_to="Zhouzhou"; c.card_type=1; c.cost_type=0; c.cost_value=2
	c.target_faction="我方"; c.target_range=0; c.scope="单体"; c.effect_id=""; c.key_value=0; c.hits=1
	c.special="ZZ_tage"; c.cost_color=0; c.rarity=1; c.enhanced=false; c.art_id="Zhouzhou02.png"; c.keywords=""; c.description=""
	c.effects_text = "本回合获得1张周周卡闪回（仅周周池）"; out.append(c)

	# C4 吐纳 — 状态·引导·沙漏A+·全场友方+1士气
	c = CardData.new(); c.id="Zhouzhou03"; c.card_name="吐纳"; c.belong_to="Zhouzhou"; c.card_type=1; c.cost_type=0; c.cost_value=3
	c.target_faction="我方"; c.target_range=-1; c.scope="群体"; c.effect_id="morale"; c.key_value=1; c.hits=1
	c.cost_color=2; c.rarity=1; c.enhanced=false; c.art_id="Zhouzhou03.png"; c.keywords=""; c.description=""
	c.effects_text = c.derived_effect_text(); out.append(c)

	# C5 问云手 — 攻击·即时·沙漏A·末端单位2伤+前进1
	c = CardData.new(); c.id="Zhouzhou07"; c.card_name="问云手"; c.belong_to="Zhouzhou"; c.card_type=0; c.cost_type=0; c.cost_value=4
	c.target_faction="全场"; c.target_range=-1; c.scope="单体"; c.effect_id=""; c.key_value=0; c.hits=1
	c.special="ZZ_wenyunshou"; c.cost_color=0; c.rarity=1; c.enhanced=false; c.art_id="Zhouzhou07.png"; c.keywords=""; c.description=""
	c.effects_text = "对队列末端单位造成2伤并使其前进1格"; out.append(c)

	# R1 千军借势 — 攻击·即时·沙漏2·集他人士气+6伤+每5层+6伤
	c = CardData.new(); c.id="Zhouzhou05"; c.card_name="千军借势"; c.belong_to="Zhouzhou"; c.card_type=0; c.cost_type=0; c.cost_value=4
	c.target_faction="敌方"; c.target_range=2; c.scope="单体"; c.effect_id=""; c.key_value=0; c.hits=1
	c.special="ZZ_qianjun"; c.cost_color=0; c.rarity=2; c.enhanced=false; c.art_id="Zhouzhou05.png"; c.keywords=""; c.description=""
	c.effects_text = "获取其他角色士气；造成6伤；每5层士气+6伤"; out.append(c)

	# R2 仙人观棋 — 状态·即时·自身·获2闪回（池=全角色）
	c = CardData.new(); c.id="Zhouzhou04"; c.card_name="仙人观棋"; c.belong_to="Zhouzhou"; c.card_type=1; c.cost_type=0; c.cost_value=4
	c.target_faction="我方"; c.target_range=0; c.scope="单体"; c.effect_id=""; c.key_value=0; c.hits=1
	c.special="ZZ_guanqi"; c.cost_color=0; c.rarity=2; c.enhanced=false; c.art_id="Zhouzhou04.png"; c.keywords=""; c.description=""
	c.effects_text = "获得2张闪回（全角色池随机）"; out.append(c)

	# R3 雁落京门 — 防御·即时·沙漏0+·范围内敌方击退1；每击退1敌+2盾
	c = CardData.new(); c.id="Zhouzhou010"; c.card_name="雁落京门"; c.belong_to="Zhouzhou"; c.card_type=2; c.cost_type=0; c.cost_value=5
	c.target_faction="敌方"; c.target_range=0; c.scope="群体"; c.effect_id=""; c.key_value=0; c.hits=1
	c.special="ZZ_yanluo"; c.cost_color=0; c.rarity=2; c.enhanced=false; c.art_id="Zhouzhou010.png"; c.keywords=""; c.description=""
	c.effects_text = "范围内敌方击退1格；每击退1敌+2盾"; out.append(c)

	# E1 千里不留行 — 状态·即时·沙漏A·所有友方前进2格(不含自身)
	c = CardData.new(); c.id="Zhouzhou012"; c.card_name="千里不留行"; c.belong_to="Zhouzhou"; c.card_type=1; c.cost_type=0; c.cost_value=5
	c.target_faction="我方"; c.target_range=-1; c.scope="群体"; c.effect_id=""; c.key_value=0; c.hits=1
	c.special="ZZ_qianli"; c.cost_color=0; c.rarity=3; c.enhanced=false; c.art_id="Zhouzhou012.png"; c.keywords=""; c.description=""
	c.effects_text = "所有友方前进2格（不含自身）"; out.append(c)

	# E2 十步杀一人 — 攻击·即时·沙漏2·10伤；记录同名最高伤害
	c = CardData.new(); c.id="Zhouzhou013"; c.card_name="十步杀一人"; c.belong_to="Zhouzhou"; c.card_type=0; c.cost_type=0; c.cost_value=4
	c.target_faction="敌方"; c.target_range=2; c.scope="单体"; c.effect_id=""; c.key_value=0; c.hits=1
	c.special="ZZ_shibu"; c.cost_color=0; c.rarity=3; c.enhanced=false; c.art_id="Zhouzhou013.png"; c.keywords=""; c.description=""
	c.effects_text = "造成10伤；伤害随本场同名最高更新"; out.append(c)

	return out

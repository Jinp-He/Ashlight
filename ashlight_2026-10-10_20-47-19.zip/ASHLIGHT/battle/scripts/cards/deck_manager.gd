class_name DeckManager
extends RefCounted

## 按角色分牌库：每个玩家角色持有一份 抽牌堆(draw) + 弃牌堆(discard)。
## 抽牌从抽牌堆顶取；抽空则把弃牌堆洗回抽牌堆；已打出的卡进弃牌堆循环。
## 闪回副本不入牌库（由 HandManager 单独持有、回合末销毁），不影响本结构。

var piles: Dictionary = {}   # role:String -> {"draw":Array[CardData], "discard":Array[CardData]}

func init_decks(roles: Array[String]) -> void:
	piles.clear()
	var db := CardDatabase.new()
	for r in roles:
		var cards: Array[CardData] = db.get_by_role(r)
		var draw: Array[CardData] = []
		for c in cards:
			draw.append(c)   # get_by_role 每次返回全新 CardData 实例，无需再 duplicate
		draw.shuffle()
		var discard: Array[CardData] = []
		piles[r] = {"draw": draw, "discard": discard}

func has_role(role: String) -> bool:
	return piles.has(role)

## 从 role 抽牌堆顶抽 n 张；抽牌堆空则先把弃牌堆洗回抽牌堆；仍空则返回已抽到的（可能少于 n）。
func draw(role: String, n: int) -> Array[CardData]:
	var out: Array[CardData] = []
	if not piles.has(role):
		return out
	var bucket: Dictionary = piles[role]
	var draw_arr: Array[CardData] = bucket.get("draw", [])
	var disc_arr: Array[CardData] = bucket.get("discard", [])
	for i in n:
		if draw_arr.is_empty():
			if disc_arr.is_empty():
				break
			draw_arr.append_array(disc_arr)
			disc_arr.clear()
			draw_arr.shuffle()
		out.append(draw_arr.pop_back())
	bucket["draw"] = draw_arr
	bucket["discard"] = disc_arr
	piles[role] = bucket
	return out

## 已打出的卡进弃牌堆（供后续洗回抽牌堆循环）。
func discard_card(role: String, cd: CardData) -> void:
	if not piles.has(role):
		var draw: Array[CardData] = []
		var disc: Array[CardData] = []
		piles[role] = {"draw": draw, "discard": disc}
	var bucket: Dictionary = piles[role]
	var disc_arr: Array[CardData] = bucket.get("discard", [])
	disc_arr.append(cd)
	bucket["discard"] = disc_arr
	piles[role] = bucket

## 调试用：返回各角色牌库余量。
func debug_status() -> String:
	var parts: Array[String] = []
	for r in piles.keys():
		var b: Dictionary = piles[r]
		var d: Array[CardData] = b.get("draw", [])
		var x: Array[CardData] = b.get("discard", [])
		parts.append("%s[抽%d/弃%d]" % [r, d.size(), x.size()])
	return " | ".join(parts)

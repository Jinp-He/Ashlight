class_name EchoCell
extends Node2D

## 单个 ATB【回声格】（新版视觉，独立可复用组件）。
##
## 层级（z_index，从后到前）：
##   回声格背景 (-1) —— 白底圆角图 × 颜色填充 #232323
##   回声格美术 (0)  —— 施法者复制体插图（逐单位美术未生成，留空占位）
##   回声格边框 (1)  —— 白色描边环（中空） × 按【阵营】着色
##
## 边框着色规则：
##   回声属【锁定类】（无法被移动 / 推拉）→ 边框恒为 #474d50，不区分阵营、无「当前回合」态。
##
## 注：回声格不含黑幕渐变与意图 icon（与单位格一致，且回声恒为施法者复制体）。

## 阵营枚举（回声格只区分 我方 / 敌方）。
enum Faction { ALLY, ENEMY }

## 回声格背景填充色 #232323（与单位格一致）。
const BG_FILL: Color = Color(0.137255, 0.137255, 0.137255, 1.0)
## 边框配色（规则见文件头）。回声为锁定类 → 恒 #474d50。
const FRAME_LOCKED: Color = Color(0.278431, 0.301961, 0.313725, 1.0)   # #474d50 锁定类
## 聚光压暗过渡时长（秒），与 atb1 AtbPart.set_dimmed 的 0.18s 一致，使「盖黑」有动画过程而非瞬间跳变。
const DIM_TIME: float = 0.18

## 新版回声格美术目录。
const CELL_ASSET_DIR: String = "res://assets/atb/cell/"
const BG_TEX_PATH: String = CELL_ASSET_DIR + "Echo_Background.png"
const FRAME_TEX_PATH: String = CELL_ASSET_DIR + "Echo_Frame.png"
## 回声格内美术占位：与单位格同目录，单位格用 01、回声格用 02（Img_Zhouzhou02 = 49×30，适配 50×30 回声条）。
const DEFAULT_ART_PATH: String = CELL_ASSET_DIR + "Img_Zhouzhou02.png"
## 首格特效组（回声·小版本）场景：横向光束爆开（不旋转 90°）、整体尺寸 100%（完整设计尺寸，不缩小），
## 由 atb2 轨道层在「堆叠上方的回声（基础版 / 小版本）演完演出组后」链式触发（非进入首格触发，区别于基础版单位格）。
const ECHO_FX_SCENE := preload("res://FX/BeamBurst/FirstCellEchoFX.tscn")

@onready var _bg: TextureRect = $CellBackground
@onready var _art: TextureRect = $CellArt
@onready var _frame: TextureRect = $CellFrame

## 当前阵营（默认我方）。回声格无「当前回合」概念。
var faction: int = Faction.ALLY


func _ready() -> void:
	# 背景/边框为固定资源；美术（施法者复制体）按需由 set_art_path 设置。
	if ResourceLoader.exists(BG_TEX_PATH):
		_bg.texture = load(BG_TEX_PATH)
	if ResourceLoader.exists(FRAME_TEX_PATH):
		_frame.texture = load(FRAME_TEX_PATH)
	_bg.modulate = BG_FILL
	# 居中共享锚点 + 保持原始尺寸。
	_fit(_bg)
	_fit(_art)
	_fit(_frame)
	# 美术：优先应用外部暂存的 art_path（atb2 _make_echo 在 add_child 前写入），否则缺图时回退默认占位。
	if art_path != "":
		set_art_path(art_path)
	elif _art.texture == null:
		set_art_path("")
	_apply_frame_color()


## 让一张 TextureRect 保持原始尺寸，并以本节点原点为中心对齐（居中共享锚点）。
func _fit(tr: TextureRect) -> void:
	if not is_instance_valid(tr) or tr.texture == null:
		return
	var s: Vector2 = tr.texture.get_size()
	tr.size = s
	tr.position = -s * 0.5


## 设置回声格内美术（回声 = 施法者复制体）。path 为空或不存在 → 回退默认占位（Img_Zhouzhou02）。
## _ready 前（_art 尚未初始化）调用时仅暂存到 art_path，待 _ready 应用；与 UnitCell.set_art_path 同款守卫。
func set_art_path(path: String) -> void:
	if not is_instance_valid(_art):
		art_path = path
		return
	var tex: Texture2D = null
	if path != "" and ResourceLoader.exists(path):
		tex = load(path)
	if tex == null and ResourceLoader.exists(DEFAULT_ART_PATH):
		tex = load(DEFAULT_ART_PATH)
	_art.texture = tex
	_fit(_art)


## 设置阵营，刷新边框颜色（不改动单位美术）。
func set_state(target_faction: int) -> void:
	faction = target_faction
	_apply_frame_color()


## 按规则刷新边框颜色。
func _apply_frame_color() -> void:
	if not is_instance_valid(_frame):
		return
	_frame.modulate = _frame_color()


## 返回边框颜色：回声属锁定类 → 恒 #474d50（不区分阵营 / 无当前回合态）。
func _frame_color() -> Color:
	return FRAME_LOCKED


## ---- ATB 接口（供 Atb2Track / BattleRoot 调用）----
## 施法者（回声来源）唯一 id（由轨道层写入，用于聚光 / 回声触发链路）。
var unit_uid: String = ""
## 美术路径覆盖：若非空，_ready 用其替代默认美术（atb2 渲染回声时按施法者 uid 取 02）。
## 必须在 add_child（触发 _ready）之前设置，此时 _art 尚未初始化，set_art_path 会暂存到此变量待 _ready 应用。
var art_path: String = ""

## 本组件是回声。
func is_echo() -> bool:
	return true
## 当前进行中的「小格特效」实例引用（loop=false 播完自释放；重新触发时先释放旧的再重建）。
var _echo_fx: FirstCellEchoFX = null


## 播放「首格特效组（回声·小版本）」：横向光束爆开特效，作为本节点的子节点、居中于回声格中心
## （local 0,0 = 居中共享锚点），随回声格一起移动 / 重排 / 移除，而非挂在 atb 轨道节点上。
## 与基础版单位格 FirstCellFX 的差异：
##   · 角度 0°（【不】旋转 90°，保持横向光束，贴合小回声条宽而薄形态）
##   · 整体尺寸 100%（完整设计尺寸，不再缩小 50%；除以自身 scale 抵消 cell0 首格回声组 1.2 放大，保证视觉一致）
##   · 层级 z_index=-2：绘制于【回声块之下】（背景(-1)/美术(0)/边框(1) 之后），光束自回声后方透出
##   · 触发条件不同：不在「进入首格」时触发，而是当【堆叠上方的单位格（基础版回声）】演完效果后由轨道层链式触发。
## 每次调用重新实例化一次（FirstCellEchoFX loop=false 播完自释放），保证可重复触发。
func play_echo_fx() -> void:
	if not is_instance_valid(self):
		return
	if _echo_fx != null and is_instance_valid(_echo_fx):
		_echo_fx.queue_free()
		_echo_fx = null
	var fx := ECHO_FX_SCENE.instantiate() as FirstCellEchoFX
	if fx == null:
		return
	add_child(fx)
	fx.z_index = -2                                  # 绘制于【回声块之下】：光束自回声后方透出
	fx.position = Vector2.ZERO                       # 居中于回声格（本节点原点 = 居中共享锚点）
	# 整体尺寸 100%（完整设计尺寸，不缩小）；再除以自身 scale（cell0 首格回声组放大 1.2 时还原设计尺寸），保证视觉一致。
	fx.scale = Vector2(1.0, 1.0) / maxf(scale.x, 0.001)
	_echo_fx = fx
	fx.play()
## 聚光压暗状态缓存（dim 不变则跳过动画，避免每次 relayout 重启发动画）与动画 tween 引用
## （重启时先 kill 旧 tween，防止多条 tween 同时写同一 modulate 造成抖动）。
var _dimmed: bool = false
var _dim_tween: Tween = null


## 聚光压暗（带动画过渡，与 atb1 AtbPart.set_dimmed 一致）：dim=true → 整格在 DIM_TIME 内渐变为暗灰（盖黑）。
## 回声恒由轨道层置 true（覆盖黑膜）。状态未变时跳过，避免每次 relayout 重启发动画。
## instant=true 用于轨道层每帧/每次 relayout 的「恒置暗」——直接设定、不播动画（与 atb1 force_dim 一致），
## 避免与 _relayout 的淡入(alpha)动画争夺 modulate 造成抖动。
func set_dimmed(dim: bool, instant: bool = false) -> void:
	if _dimmed == dim and not instant:
		return
	_dimmed = dim
	var target := Color(0.35, 0.35, 0.35, 1.0) if dim else Color.WHITE
	if _dim_tween != null and _dim_tween.is_valid():
		_dim_tween.kill()
	if instant:
		modulate = target
		return
	_dim_tween = create_tween()
	_dim_tween.tween_property(self, "modulate", target, DIM_TIME)


## 全局坐标命中测试（供每帧权威聚光）。考虑 scale 后实际绘制尺寸。
func is_point_inside(global_pos: Vector2) -> bool:
	var sz := cell_size() * scale
	var top_left := global_position - sz * 0.5
	return Rect2(top_left, sz).has_point(global_pos)


## 返回回声格像素尺寸（取边框纹理尺寸；两图同尺寸 50×30）。
func cell_size() -> Vector2:
	if is_instance_valid(_frame) and _frame.texture != null:
		return _frame.texture.get_size()
	if is_instance_valid(_bg) and _bg.texture != null:
		return _bg.texture.get_size()
	return Vector2.ZERO

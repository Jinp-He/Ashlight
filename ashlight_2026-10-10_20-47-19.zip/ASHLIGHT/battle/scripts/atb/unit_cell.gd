class_name UnitCell
extends Node2D

## 单个 ATB【单位格】（新版视觉，独立可复用组件）。
##
## 层级（z_index，从后到前）：
##   单位格背景 (-1) —— 白底圆角图 × 颜色填充 #232323
##   单位格美术 (0)  —— 单位插图（逐单位美术尚未生成，暂用 Img_Zhouzhou01 占位展示）
##   单位格边框 (1)  —— 白色描边环（中空） × 按【阵营 / 是否当前回合】着色
##
## 边框着色规则：
##   我方 + 非当前回合 → #000000
##   我方 + 当前回合   → #ffffff
##   敌方（不分回合）  → #a30000
##   锁定类（无法被移动/推拉的格，如天气 / 回声）→ #474d50（优先于以上所有规则）
##
## 注 1：新版单位格【不含】黑幕渐变与意图 icon —— 敌方单位格不再叠加黑幕/icon。
## 注 2：所有美术保持原始尺寸（50×80），不做缩放；对齐靠「居中共享锚点」——
##       三张图 position 均 = -尺寸 * 0.5，使其以本节点原点为中心共享同一锚点。

## 阵营枚举（天气类留待轨道层扩展，单位格本身只区分 我方 / 敌方）。
enum Faction { ALLY, ENEMY }

## 单位格背景填充色 #232323。
const BG_FILL: Color = Color(0.137255, 0.137255, 0.137255, 1.0)
## 边框配色（规则见文件头）。
const FRAME_ALLY_IDLE: Color = Color(0.0, 0.0, 0.0, 1.0)        # #000000 我方·非当前回合
const FRAME_ALLY_ACTIVE: Color = Color(1.0, 1.0, 1.0, 1.0)      # #ffffff 我方·当前回合
const FRAME_ENEMY: Color = Color(0.639216, 0.0, 0.0, 1.0)        # #a30000 敌方
## #474d50 锁定类：表示该格【无法被移动 / 推拉】（天气 / 回声）。优先于阵营 / 当前回合规则。
const FRAME_LOCKED: Color = Color(0.278431, 0.301961, 0.313725, 1.0)
## 聚光压暗过渡时长（秒），与 atb1 AtbPart.set_dimmed 的 0.18s 一致，使「盖黑」有动画过程而非瞬间跳变。
const DIM_TIME: float = 0.18
## 进入首格（cell0）时播放的「首格特效组」场景（竖向光束爆开，详见 FX/BeamBurst/README_FirstCellFX.md）。
## 由本组件在「单位进入首格」时实例化并作为子节点播放，居中于单位格、随其移动 / 重排 / 移除。
const FIRST_CELL_FX_SCENE := preload("res://FX/BeamBurst/FirstCellFX.tscn")

## 新版单位格美术目录（边框/背景/占位美术均在此，待逐单位美术补齐）。
const CELL_ASSET_DIR: String = "res://assets/atb/cell/"
const BG_TEX_PATH: String = CELL_ASSET_DIR + "Cell_Background.png"
const FRAME_TEX_PATH: String = CELL_ASSET_DIR + "Cell_Frame.png"
## 单位美术占位：逐单位美术（Img_{Unit}01.png）尚未全部生成，先用 Img_Zhouzhou01 展示。
const DEFAULT_ART_PATH: String = CELL_ASSET_DIR + "Img_Zhouzhou01.png"

@onready var _bg: TextureRect = $CellBackground
@onready var _art: TextureRect = $CellArt
@onready var _frame: TextureRect = $CellFrame

## 当前阵营（默认我方）与是否处于当前行动回合。
var faction: int = Faction.ALLY
var is_current_turn: bool = false


func _ready() -> void:
	# 背景/边框为固定资源；美术可被 set_art_path 覆盖。
	if ResourceLoader.exists(BG_TEX_PATH):
		_bg.texture = load(BG_TEX_PATH)
	if ResourceLoader.exists(FRAME_TEX_PATH):
		_frame.texture = load(FRAME_TEX_PATH)
	if art_path != "":
		set_art_path(art_path)
	elif _art.texture == null:
		set_art_path("")
	# 背景填充 #232323，但透明度降为 0.5（需求：单位格背景半透明），使背景后的内容透出。
	_bg.modulate = Color(BG_FILL.r, BG_FILL.g, BG_FILL.b, 0.5)
	# 居中共享锚点 + 保持原始尺寸。
	_fit(_bg)
	_fit(_art)
	_fit(_frame)
	_apply_frame_color()


## 让一张 TextureRect 保持原始尺寸，并以本节点原点为中心对齐（居中共享锚点）。
func _fit(tr: TextureRect) -> void:
	if not is_instance_valid(tr) or tr.texture == null:
		return
	var s: Vector2 = tr.texture.get_size()
	tr.size = s
	tr.position = -s * 0.5


## 设置单位美术；path 为空或不存在 → 回退默认占位（Img_Zhouzhou01）。
## _ready 前（_art 尚未初始化）调用时仅暂存到 art_path，待 _ready 应用。
func set_art_path(path: String) -> void:
	if not is_instance_valid(_art):
		art_path = path
		return
	var tex: Texture2D = null
	if path != "" and ResourceLoader.exists(path):
		tex = load(path)
	if tex == null and ResourceLoader.exists(DEFAULT_ART_PATH):
		tex = load(DEFAULT_ART_PATH)
	if tex == null:
		return
	_art.texture = tex
	_fit(_art)


## 设置阵营 + 是否当前回合，刷新边框颜色（不改动单位美术）。
func set_state(target_faction: int, current: bool) -> void:
	faction = target_faction
	is_current_turn = current
	_apply_frame_color()


## 按规则刷新边框颜色。
func _apply_frame_color() -> void:
	if not is_instance_valid(_frame):
		return
	_frame.modulate = _frame_color()


## 返回当前状态对应的边框颜色（锁定类优先）。
func _frame_color() -> Color:
	if locked or is_echo_override:
		return FRAME_LOCKED
	if faction == Faction.ENEMY:
		return FRAME_ENEMY
	return FRAME_ALLY_ACTIVE if is_current_turn else FRAME_ALLY_IDLE


## ---- ATB 接口（供 Atb2Track / BattleRoot 调用）----
## 单位唯一 id（由轨道层写入，用于聚光 / 队列顺序读取）。
var unit_uid: String = ""
## 美术路径覆盖：若非空，_ready 用其替代默认美术（atb2 首格回声用 Img_Zhouzhou02）。
## 必须在 add_child（触发 _ready）之前设置，避免 _ready 前访问尚未初始化的 _art。
var art_path: String = ""
## 是否为「角色」（玩家可用英雄，如周周/艾琳/炮炮）。仅影响 cell0 高亮框的白色边框判定。
var is_character: bool = false
## 锁定类标记：true = 该格无法被移动 / 推拉（天气 / 回声），边框恒为 FRAME_LOCKED(#474d50)，
## 且不受 cell0 的「角色白框 / 阵营框」规则影响。普通单位恒为 false。
var locked: bool = false
## 回声覆盖标记：仅 atb2 用 UnitCell 尺寸渲染「第一格回声」时置 true（让 is_echo() 返回 true，
## 使该节点被回声触发链路正确识别）。普通单位永远为 false。
var is_echo_override: bool = false
## 聚光压暗状态缓存（dim 不变则跳过动画，避免每帧/每次 relayout 重启发动画）与动画 tween 引用
## （重启时先 kill 旧 tween，防止多条 tween 同时写同一 modulate 造成抖动）。
var _dimmed: bool = false
var _dim_tween: Tween = null
## 当前进行中的「首格特效组」实例引用（loop=false 播完自释放；重新触发时先释放旧的再重建）。
var _first_cell_fx: FirstCellFX = null

## 本组件默认不是回声；atb2 以 UnitCell 尺寸渲染的首格回声会置 is_echo_override=true。
func is_echo() -> bool:
	return is_echo_override


## 单位格进入首格（cell0）时由轨道层调用：播放「首格特效组」竖向光束特效。
## 特效作为本节点的子节点、居中于单位格中心（local 0,0 = 居中共享锚点），随单位格一起移动 / 重排 / 移除，
## 而非挂在 atb 轨道节点上。每次调用重新实例化一次（FirstCellFX loop=false 播完自释放），
## 保证同一单位格可重复进入 cell0 时都能重新触发，无需重建单位格本身。
func play_first_cell_fx() -> void:
	if not is_instance_valid(self):
		return
	if _first_cell_fx != null and is_instance_valid(_first_cell_fx):
		_first_cell_fx.queue_free()
		_first_cell_fx = null
	var fx := FIRST_CELL_FX_SCENE.instantiate() as FirstCellFX
	if fx == null:
		return
	add_child(fx)
	fx.z_index = -2            # 绘制于【单位组之下】：在背景(-1)/美术(0)/边框(1) 之后，光束自单位格后方透出
	fx.position = Vector2.ZERO  # 居中于单位格（本节点原点 = 居中共享锚点）
	_first_cell_fx = fx
	fx.play()


## 设置该单位格是否处于 cell0（行动格）。atb2 用「在 cell0」取代旧的高亮框：
##   激活 → 放大 120%；white=true 时按 cell0 规则着色（角色→白框 / 非角色我方→黑框 / 敌方→红框），
##         white=false 时仅按阵营着色（我方→黑、敌方→红，不白框）；非激活 → 恢复标准阵营框，尺寸 100%。
##   设计：cell0 内仅【首格】单位 white=true（白框），其余 cell0 单位 white=false（仅放大 + 阵营框）。
func set_cell0_active(active: bool, white: bool = true) -> void:
	scale = Vector2(1.2, 1.2) if active else Vector2(1.0, 1.0)
	if not active:
		_apply_frame_color()
		return
	# 锁定类（天气 / 回声）不参与「白框 / 阵营框」规则，恒为 #474d50。
	if locked or is_echo_override:
		_frame.modulate = FRAME_LOCKED
		return
	# 非首格的 cell0 单位：仅按阵营着色（敌方红 / 我方黑），不白框。
	if not white:
		_frame.modulate = FRAME_ENEMY if faction == Faction.ENEMY else FRAME_ALLY_IDLE
		return
	# 首格白框：角色→白 / 敌方→红 / 我方非角色→黑。
	if faction == Faction.ENEMY:
		_frame.modulate = FRAME_ENEMY
	elif is_character:
		_frame.modulate = FRAME_ALLY_ACTIVE
	else:
		_frame.modulate = FRAME_ALLY_IDLE


## 聚光压暗（带动画过渡，与 atb1 AtbPart.set_dimmed 一致）：dim=true → 整格在 DIM_TIME 内渐变为暗灰（盖黑）；
## dim=false → 还原为全彩。回声恒由轨道层单独置暗，不在此处理。状态未变时跳过，避免重复触发动画。
## instant=true 用于轨道层每帧/每次 relayout 对回声的「恒置暗」——直接设定、不播动画（与 atb1 force_dim 一致），
## 避免与 _relayout 的淡入(alpha)动画争夺 modulate 造成抖动。
func set_dimmed(dim: bool, instant: bool = false) -> void:
	if _dimmed == dim and not instant:
		return
	_dimmed = dim
	var target := Color(0.35, 0.35, 0.35, 1.0) if dim else Color.WHITE
	if _dim_tween != null and _dim_tween.is_valid():
		_dim_tween.kill()
	if instant:
		modulate = target
		return
	_dim_tween = create_tween()
	_dim_tween.tween_property(self, "modulate", target, DIM_TIME)


## 全局坐标命中测试（供每帧权威聚光）。考虑 scale 后实际绘制尺寸。
func is_point_inside(global_pos: Vector2) -> bool:
	var sz := cell_size() * scale
	var top_left := global_position - sz * 0.5
	return Rect2(top_left, sz).has_point(global_pos)


## 返回单位格像素尺寸（取边框纹理尺寸；三张图同尺寸 50×80）。
func cell_size() -> Vector2:
	if is_instance_valid(_frame) and _frame.texture != null:
		return _frame.texture.get_size()
	if is_instance_valid(_bg) and _bg.texture != null:
		return _bg.texture.get_size()
	return Vector2.ZERO

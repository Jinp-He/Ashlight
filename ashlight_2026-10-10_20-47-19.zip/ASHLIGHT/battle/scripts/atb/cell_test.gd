extends Node2D

## 单位格（UnitCell）+ 回声格（EchoCell）独立测试场景。
##
## 按钮 1：切换单位格阵营及状态（四种：我方·非当前 / 我方·当前 / 敌方 / 锁定类）。
## 按钮 2：切换回声格状态（回声属锁定类，恒 #474d50，不区分阵营）。
##
## 两个按钮都【不改动单位美术】，只切边框配色，用于查看不同状态下的格效果。

## 单位格状态表（不改动美术）。locked = 锁定类（无法被移动 / 推拉，如天气 / 回声）→ #474d50。
const STATES: Array[Dictionary] = [
	{"faction": UnitCell.Faction.ALLY, "current": false, "text": "我方 · 非当前回合（边框 #000000）"},
	{"faction": UnitCell.Faction.ALLY, "current": true, "text": "我方 · 当前回合（边框 #ffffff）"},
	{"faction": UnitCell.Faction.ENEMY, "current": false, "text": "敌方（边框 #a30000）"},
	{"faction": UnitCell.Faction.ALLY, "current": false, "locked": true, "text": "锁定类（边框 #474d50，天气 / 回声）"},
]

## 回声格状态表：回声属锁定类，恒 #474d50（无阵营 / 无当前回合态）。
const ECHO_STATES: Array[Dictionary] = [
	{"text": "锁定类（边框 #474d50）"},
]

@onready var _cell: UnitCell = $UnitCell
@onready var _btn: Button = $ButtonCycle
@onready var _label: Label = $StateLabel

@onready var _echo: EchoCell = $EchoCell
@onready var _echo_btn: Button = $EchoButton
@onready var _echo_label: Label = $EchoLabel

var _idx: int = 0
var _echo_idx: int = 0


func _ready() -> void:
	_apply()
	_apply_echo()


func _on_btn_cycle_pressed() -> void:
	_idx = (_idx + 1) % STATES.size()
	_apply()


func _on_echo_btn_pressed() -> void:
	_echo_idx = (_echo_idx + 1) % ECHO_STATES.size()
	_apply_echo()


func _apply() -> void:
	var st: Dictionary = STATES[_idx]
	_cell.locked = bool(st.get("locked", false))
	_cell.set_state(int(st["faction"]), bool(st["current"]))
	if is_instance_valid(_btn):
		_btn.text = "切换单位格阵营及状态"
	if is_instance_valid(_label):
		_label.text = "单位格：%s" % String(st["text"])


func _apply_echo() -> void:
	var st: Dictionary = ECHO_STATES[_echo_idx]
	_echo.set_state(EchoCell.Faction.ALLY)
	if is_instance_valid(_echo_btn):
		_echo_btn.text = "切换回声格状态"
	if is_instance_valid(_echo_label):
		_echo_label.text = "回声格：%s" % String(st["text"])

class_name AtbRoot
extends Node2D

## ATB 测试场景宿主（atb2 版）：实例化 Atb2Track，提供调试按钮。
##
## 按钮：
##   推进     —— 仅推进【玩家单位】；敌方 / 回声进 cell0 首格由轨道层【自动播放】（停顿 1s 后，敌方→向后插队、
##              回声→播放并销毁其堆叠），无需手动。
##   生成回声 —— 模拟打出一张引导卡（随机费用 2-3）：沿队列插入回声（首格回声单位尺寸、后续更小），
##              施法者推回 cost 格；回声随队列左移，最终进 cell0 首格由自动播放接管（1s 后播放并销毁）。
##   重生成   —— 按战斗名册重建 ATB UI 组（玩家在 cell0、敌方在 cell1-5）。
##
## 另：_process 复刻战斗的「每帧权威命中」聚光（鼠标悬停某部件→该部件彩色、其余压暗；回声恒黑膜）。
##
## 注：atb1 的「全部意图 / 插入预览」按钮依赖旧 AtbPart 的意图 icon 与插入预览标记，
## 而 atb2 的单位格 / 回声格已不含意图 icon 与高亮框预览，故这两个按钮不移植到 atb2 测试场景。
## 回声 / 敌方 的进框自动播放由 Atb2Track 内部（_maybe_auto_play / _auto_play）处理，测试场景不重复消费。

## 战斗名册（与 Battle.tscn 的 Units 一致）：玩家从顶到底排进 cell0（首项最先行动 = Rocket）。
const ALLY_IDS: Array[String] = ["Rocket", "Irene", "Zhouzhou"]
## 敌方起始 ATB 格（clamp 到 [1,5]，永不入 cell0）。
const ENEMY_SPECS: Array[Dictionary] = [
	{"id": "Banner", "cell": 1},
	{"id": "DogKnight", "cell": 3},
	{"id": "Tusk", "cell": 5},
]

# 无类型：避免与 atb2_track.gd 的 class_name 形成加载顺序依赖（atb.gd 先于 atb2_track.tscn 解析）。
@onready var _track = $Atb2Track


func _ready() -> void:
	# 直接用战斗名册建立 UI 组（内容与战斗内一致：玩家在 cell0、敌方在 cell1-5）。
	# 回声 / 敌方 进框自动播放由 Atb2Track 内部处理，测试场景不额外连接消费。
	_track.build_roster(ALLY_IDS, ENEMY_SPECS)


func _process(_delta: float) -> void:
	# 复刻战斗的「每帧权威命中」聚光：鼠标悬停某部件 → 该部件彩色、其余压暗；回声(force_dim)恒黑膜。
	if _track == null or not is_instance_valid(_track):
		return
	var mp := get_global_mouse_position()
	var uid := ""
	for p in _track.get_parts():
		if is_instance_valid(p) and p.is_point_inside(mp):
			uid = p.unit_uid
			break
	_track.set_spotlight(uid)


func _on_btn_advance_pressed() -> void:
	_track.advance_random()


func _on_btn_echo_pressed() -> void:
	_track.spawn_guide_demo()


func _on_btn_respawn_pressed() -> void:
	_track.build_roster(ALLY_IDS, ENEMY_SPECS)

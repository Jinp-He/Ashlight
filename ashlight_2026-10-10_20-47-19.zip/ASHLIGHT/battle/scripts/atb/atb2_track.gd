class_name Atb2Track
extends Node2D

## ATB 轨道系统（atb2 版）—— 以「当前版本格子美术组」重建。
##
## 与 atb1（AtbTrack）的核心差异（用户铁规则）：
##   1. 整组【水平居中】于屏幕、且所有单元【上边对齐】；增删回声 / cell0 放大均触发重新居中。
##   2. 6 个【横向队列格】（cell0..cell5 从左到右排列，cell0=行动格）；**同格内单位【从左到右】横向排**，
##      先后顺序 = 【同格内排队规则】（与 atb1 完全一致）：天气(含回声基础块) > 我方 > 敌方，同优先级【先来后到】FIFO
##      （见 _precedence / _ordered_insert_index）。**回声插入规则**：某格尚无「首格回声 / 天气」时，
##      生成的【首格回声】以【单位格尺寸】作为队列成员【横排进单位行】（不堆叠）；该格已有首格回声 / 天气时，
##      后续回声以【小回声格】紧挨【首格回声 / 天气正下方】纵向堆叠、不重叠。
##   3. 【折叠】仅在 [0, 末位被占用格] 区间内渲染；区间外的空队列格（真正的队尾之后）才隐藏。区间内的空队列格
##      渲染为【分割块】补足到末位被占用格（例：cell0=A、cell2=12、cell5=actor → A/12///actor，cell3/4 用分割块补足）；整组按实际内容宽度居中。
##   4. 单位格堆叠间距 = 2（stack_gap）；分割块（Cell_Divider.png）出现于【相邻两个被渲染格】之间（含中间的空队列格，用分割块填补空缺），
##      且【顶到上边】（顶边与单位格顶边对齐，y=0），不再垂直居中。
##   5. 旧「高亮框」视觉移除；以「单位进入 cell0」取代高亮：【尺寸变化只发生在 cell0 的【首格】占用者】——
##      「首格占用者」= 该格单位行第 0 位（cell0 内 i==0 的单位）；若该格单位行为空（无单位/天气），则回声组占据首格。
##      首格白框（仅单位）：角色→白 / 敌方→红 / 我方非角色→黑；其余 cell0 单位【不放大】、仅按阵营着色（不白）；
##      锁定类(天气·回声)恒 #474d50（优先）。
##      ⚠️ 回声组【仅在自己占据 cell0 首格时】才放大 120%（基础回声 + 其下方堆叠小回声【同步放大】、位置紧贴不变）；
##         若 cell0 内已有单位 / 天气占据首格，则回声即使同在 cell0 也恒为 100%
##         （修复「回声在队伍中段被撑大 120%、看起来莫名变大」的问题）。
##      高亮框触发的规则（如播演出）通过 framed_changed 保留。
##   6. 引导卡回声（插入而非同时推进）：先在 cost-1 各格生成回声——该格无首格回声/天气则插入【单位格尺寸首格回声】
##      （UnitCell 尺寸盒 + 基础单位美术，锁定类 #474d50，从【下方】向上推入单位行）；已有则从【下方】淡入拼接到首格回声/天气下方。
##      回声生成【完成】后，再推进队列格（单位前移，回声随之随队列左移、与单位格同时位移）。
##   7. 自动播放（轮到 cell0 首格时）：回声 / 天气 / 敌方阵营 单位块进 cell0 首格即【自动播放】（玩家单位不自动，等手动「推进」）。
##      天气 / 回声视作「无法操控的单位格」（类似敌方类型）：
##        · 回声：进入首格即进入「回声回合」——置【暂停推进】状态（类比玩家回合，回合内队列不前进）；
##          依次演出首格全部回声（基础版→堆叠小版本）→ 整组原地淡出 → 【淡出动画结束（销毁）后】解除暂停、队列正常推进。
##          推进由「回声真正销毁」事件（tween.finished）驱动，不再用定时器等待动画时长。
##        · 敌方 / 天气：演出效果 → 按设定落点（遵循同格先后顺序）重新插入队列 → 继续推进队列。
##      播放细节（1s 占位）后续对接真实演出；当前为占位实现。
##
## 保留给 Battle 集成的信号 / 接口（与 atb1 同名，便于后续接轨）：
##   framed_changed(uid, is_player) —— 框内单位变化（含回声进框）→ 触发演出等规则
##   enemy_action_started(uid)      —— 敌方单位进框
##   queue_reorder(faction)         —— 队列位移（占位）

## 部件场景（atb2 直接复用 unit_cell / echo_cell，不再用 AtbPart）。
const UNIT_CELL_SCENE := preload("res://battle/scripts/atb/unit_cell.tscn")
const ECHO_CELL_SCENE := preload("res://battle/scripts/atb/echo_cell.tscn")
const CELL_DIR: String = "res://assets/atb/cell/"
const DIVIDER_TEX: String = CELL_DIR + "Cell_Divider.png"
## 单位格 / 回声格美术命名约定（与 build_roster 传入的 uid 一致）：
##   Img_{uid}01.png —— 50×80 单位格美术；Img_{uid}02.png —— 50×30 回声格美术。
## 例如 uid="Rocket" → Img_Rocket01.png / Img_Rocket02.png。
## 文件不存在时回退到默认占位（Img_Zhouzhou01 / 02），避免因将来新增 uid 未配美术而空白。
const UNIT_ART_FMT: String = CELL_DIR + "Img_%s01.png"
const ECHO_ART_FMT: String = CELL_DIR + "Img_%s02.png"
const DEFAULT_UNIT_ART: String = CELL_DIR + "Img_Zhouzhou01.png"
const DEFAULT_ECHO_ART: String = CELL_DIR + "Img_Zhouzhou02.png"
## 预览三角描边色（与 atb1 的 COLOR_ENHANCED 一致：暗金），仅作 2px 轮廓，不参与填充。
const COLOR_ENHANCED: Color = Color(0.61176, 0.4, 0.03922, 1.0)

## 柔边扩散（黑色）改为【逐单位格模块化】：由 unit_cell.tscn / echo_cell.tscn 各自内置的 Halo 子节点实现——
## 每个单位格 / 回声格自带一圈贴合自身形状的柔边黑晕（透明中心 + 边缘向外扩散），不再是「整组一个大矩形」。
## 故 atb2 轨道层【不再】统一绘制整组柔边（原整组 Sprite2D 方案已移除）。

func _unit_art_path(uid: String) -> String:
	var p := UNIT_ART_FMT % uid
	return p if ResourceLoader.exists(p) else DEFAULT_UNIT_ART

func _echo_art_path(uid: String) -> String:
	var p := ECHO_ART_FMT % uid
	return p if ResourceLoader.exists(p) else DEFAULT_ECHO_ART

const FACTION_ALLY: int = 0
const FACTION_ENEMY: int = 1
## 天气阵营（预留最高优先级类，与 atb1 AtbPart.Faction.WEATHER 对应；当前尚未提供具体部件/美术）。
const FACTION_WEATHER: int = 2

## 列内一个条目（单位或回声）。同格内：单位按【从左到右】= 插入顺序排，回声按【从上到下】堆叠。
## node 用无类型（Variant）：格内可能同时混用 UnitCell（单位 / 首格回声）与 EchoCell（后续回声），
## 二者都提供 cell_size / is_point_inside / set_dimmed / is_echo / unit_uid，但无公共基类，故以动态分发调用。
class Entry:
	var node
	var uid: String
	var faction: int
	var echo: bool
	var character: bool
	func _init(n, u: String, f: int, e: bool, c: bool) -> void:
		node = n
		uid = u
		faction = f
		echo = e
		character = c
	## 回声效果负载（规则2·引导卡）：由 BattleRoot.spawn_guide_echoes 写入、经 spawn_echo 落到本条目，
	## 进首格演出时通过 echo_effect_requested 信号回传给 BattleRoot 做真实结算。非回声条目恒为空。
	var echo_data: Dictionary = {}


## 框内单位变化信号：携带其 unit uid 与是否玩家阵营（供 BattleRoot 转发，如动态手牌间距 / 播演出）。
signal framed_changed(uid: String, is_player: bool)
## 敌方回合开始信号（占位，目前无实际行为）。
signal enemy_action_started(uid: String)
## 队列位移信号（占位，供战场规则二重排物理槽位）。
signal queue_reorder(faction: String)
## 队列整体「前进一格」信号：每次 _shift_left()（一次左移 = 一个时间 tick）后发出。
## advanced_uids = 本 tick 因左移而前移一格的所有【单位】uid（不含回声；cell0 行动者已离场、不在列）。
## 进入 cell0 的单位也前进了一格，一并包含。供 BattleRoot 结算「每前进一格触发一次」的 DoT（如出血）。
signal units_advanced(advanced_uids: Array[String])
## 回声效果请求信号：atb2 在回声(基础版/小版本)进首格并进入「回声回合」时发出，携带该回声的 echo_data（效果负载）。
## 由 BattleRoot 连接，经真实编排器(CutsceneGroup)演出 + 结算后调用 complete_echo_effect() 通知 atb2 继续（淡出 + 推进）。
## 若无连接（如纯测试场景），atb2 自动回退 1s 占位，避免协程永久挂起。
signal echo_effect_requested(echo_data: Dictionary)
## atb2 内部信号：BattleRoot 完成回声效果演出 + 结算后调用 complete_echo_effect() 触发本信号，唤醒 _perform_effect 的 await。
signal echo_effect_completed()


@export_group("Layout")
@export var cell_count: int = 6
## 列内单位格上下堆叠间距（铁规则 = 2）。
@export var stack_gap: float = 2.0
## 分割块两侧留白。
@export var divider_pad: float = 2.0
## 整组顶部对齐到的 y（像素）。
@export var top_margin: float = 80.0
## 是否自动在屏幕上水平居中（测试场景 true；Battle 集成可改手动坐标）。
@export var center_screen: bool = true
## center_screen=false 时使用的中心 x。
@export var manual_center_x: float = 800.0
## 整组附加 y 偏移（像素）：叠加在 top_margin 之上，用于整体上下微调（如整体上移 60px → 设 -60）。
@export var position_offset_y: float = 0.0

@export_group("Animation")
## 滑动 / 重排时长。
@export var slide_time: float = 0.35
## 首格回声从下方推入时的起始偏移（像素）：初始位于目标下方该值处，再上移归位。
const RISE_OFFSET: float = 80.0
## 回声销毁移除时的【原地淡出】动画时长（秒）：仅透明度（modulate:a）降为 0，不缩放、不扩散，到 0 后释放节点。
const FADE_OUT_TIME: float = 0.3
## 首格特效组触发前的等待时长（秒）：等单位格大致滑入 cell0 后再播放，避免「未到首格就爆开」抢拍。
## （slide_time = 0.35s，略小于它即可；设为 0.32 让单位接近落定才爆。）
const FX_TRIGGER_DELAY: float = 0.2

@export_group("Auto Play")
## 是否自动推进敌方单位（测试场景 true；Battle 集成设 false，由 BattleRoot 经 enemy_action_started 驱动真实演出）。
## 回声恒自动播放（测试回退 1s / Battle 经 echo_effect_requested 回调），不受此旗标影响。
## 天气系统尚未实现，预留为恒自动播放。
@export var auto_play_enemy: bool = true

@export_group("Marker")
## 预览占位组整体上下偏移（默认 0 = 与插入行垂直中心对齐；负数上移、正数下移）。
@export var marker_y_offset: float = 0.0
## 底部三角相对「插入行底边」的向下间隙（px）：三角落在单位行正下方、指向上方的插入槽，而非压在格子上。
## atb2 单位格高约 80（首格放大 120% 时 ≈96）；此值控制三角与底边留白，默认 10。
@export var marker_bot_gap: float = 10.0
## 浮动振幅（三角向插入槽方向上探/回落的幅度，单位 px）。
@export var marker_float_amp: float = 6.5
## 浮动单程时长（秒）。
@export var marker_float_time: float = 1.0

## 每列的单位清单（自上而下 = 行动顺序）。_units[c] = Array[Entry]。
var _units: Array[Array] = []
## 每列的回声清单（在单位的下方堆叠）。_echoes[c] = Array[Entry]。
var _echoes: Array[Array] = []
## 分割块节点（cell_count-1 个）。
var _dividers: Array[TextureRect] = []

## 分割块尺寸（运行时从纹理读取，默认 15×60）。
var _div_w: float = 15.0
var _div_h: float = 60.0
## 单位格宽度（50，作为无纹理时的兜底列宽）。
var _unit_w: float = 50.0

var _busy: bool = false
## 队列推进暂停状态（「回声回合」锁，类比玩家回合）：为 true 时【整条队列不自动推进】，
## 直至首格回声播放完毕并销毁后才解除。回声进 cell0 首格即置 true，销毁后由回调置 false。
var _advance_paused: bool = false
var _front: Entry = null
var _spot_uid: String = ""
var _loading: bool = true
var _relayout_tween: Tween = null

## ---- 插入位置预览标记（移植自 atb1 的 _insert_marker）----
## 单一白色底部三角 ▲：apex 朝上、指向中心（inward），落于「插入行正下方」指向上方的插入槽。
## 钉在「悬停付费卡对应单位向前推进 cost 格后的插入位」——即该卡打出后单位将落入的位置。
## 三角向插入槽方向轻微浮动仅作视觉提示。常态隐藏，仅悬停付费卡时由 preview_cost_for 显示，0 费卡/无悬停时隐藏。
## ⚠️ atb2 坐标系与 atb1 不同（atb1 用固定列网格+分割线坐标；atb2 用局部坐标+折叠打包布局），
##    故定位逻辑按 atb2 的 _relayout 数学重算（基于每列缓存的 left/row_h/row），非直接照搬 atb1 公式。
var _insert_marker: Node2D = null
var _tri_bot: Polygon2D = null   ## 底部三角 ▲：apex 朝上，指向中心（inward），落于插入行正下方、指示插入槽
var _marker_rowh: float = 80.0   ## 当前预览目标列的行高缓存（用于把底部三角锚定到行底边下方）
var _float_tweens: Array = []
## 当前预览目标（供 _relayout 后重算落点）：target 列 + 对应单位 uid；<0 表示无预览。
var _marker_target: int = -1
var _marker_uid: String = ""
## 每列布局缓存（_relayout 写入，_compute_marker_slot 读取）：left=列左缘局部 x；width=列宽；row_h=行高；row=行内条目（横向顺序）。
var _col_left: Array = []
var _col_width: Array = []
var _col_rowh: Array = []
var _col_row: Array = []
## 末位被占用列（_relayout 写入）；<0 表示队列全空。
var _last_occ: int = -1


func _ready() -> void:
	var tex := load(DIVIDER_TEX) as Texture2D
	if tex != null:
		_div_w = tex.get_width()
		_div_h = tex.get_height()
	_units = []
	_echoes = []
	for i in cell_count:
		_units.append([])
		_echoes.append([])
	# 每列布局缓存（marker 定位用）
	_col_left = []
	_col_width = []
	_col_rowh = []
	_col_row = []
	for i in cell_count:
		_col_left.append(0.0)
		_col_width.append(0.0)
		_col_rowh.append(0.0)
		_col_row.append([])
	_last_occ = -1
	# 供 HandManager / BattleRoot 经 group 取得引用（解耦路径），与 atb1 AtbTrack 行为一致。
	add_to_group("atb_track")
	# 插入位置预览标记（移植自 atb1）。常态隐藏，仅悬停付费卡时显示。
	_build_marker()
	# 测试场景由 AtbRoot._ready 显式调用 build_roster；此处不自动生成。


## ---- 名册建立 ----
## 测试/演示用：按战斗名册结构建立布局（无需 UnitRoot 节点，直接喂 unit_id + 起始格）。
## ally_ids：玩家单位 id（按顺序从左到右排进 cell0，数组首项 = 最先行动 = 列最左）。
## enemy_specs：敌方 [{id, cell}]，cell 为起始 ATB 格（clamp 到 [1, cell_count-1]，永不入 cell0）。
## 入队统一走 _insert_unit → 同格内按 _precedence 排队（天气 > 我方 > 敌方，同优先级先来后到），
## 故多个敌方落在同一格时也按此规则排定左右顺序。
func build_roster(ally_ids: Array[String], enemy_specs: Array[Dictionary]) -> void:
	_clear_all()
	for uid in ally_ids:
		if uid == "":
			continue
		var e := _make_unit(uid, FACTION_ALLY, true)
		_insert_unit(e, 0)
	for spec in enemy_specs:
		var uid: String = spec.get("id", "")
		if uid == "":
			continue
		var c: int = clampi(int(spec.get("cell", 1)), 1, cell_count - 1)
		var e := _make_unit(uid, FACTION_ENEMY, false)
		_insert_unit(e, c)
	_build_dividers()
	_relayout(false)
	_set_front(_compute_front())
	_loading = false


## 按【战斗单位节点】建立名册（与 atb1 AtbTrack.start_turn 同名同义，供 BattleRoot 调用）。
## 与 build_roster 的区别：入参是 Units 子节点的 UnitRoot 列表（而非裸 id/spec），
## 内部自行推导 ally_ids（玩家，按场景 x 坐标降序 → 从右到左进 cell0，slot0=最右）与
## enemy_specs（敌方，{id, cell=start_cell_index clamp 到 [1,cell_count-1]}），再调 build_roster。
## 末尾 emit queue_reorder("all") → BattleRoot 据此重排双方物理槽位（规则二）。
func start_turn(unit_nodes: Array) -> void:
	_clear_all()
	var players: Array = []
	var enemies: Array = []
	for u in unit_nodes:
		if u is UnitRoot and (u as UnitRoot).unit_id != "":
			var ur := u as UnitRoot
			if ur.unit_faction == "player":
				players.append(ur)
			else:
				enemies.append(ur)
	# 玩家按场景 x 降序（从右往左）→ 依次进入 cell0，slot0 = 最右单位（与 atb1 一致）。
	players.sort_custom(func(a: UnitRoot, b: UnitRoot) -> bool:
		return a.global_position.x > b.global_position.x)
	var ally_ids: Array[String] = []
	for ur in players:
		ally_ids.append(ur.unit_id)
	var enemy_specs: Array[Dictionary] = []
	for e in enemies:
		var ur := e as UnitRoot
		var cell: int = ur.enemy_spawn_cell(cell_count - 1)   # 敌方出生格由速度档决定（首次等待=再次等待），不再读手填 start_cell_index
		enemy_specs.append({"id": ur.unit_id, "cell": cell})
	build_roster(ally_ids, enemy_specs)


## 查找某条目当前所在列（供 execute_end / 调试）。
func _column_of(e: Entry) -> int:
	for c in cell_count:
		if _units[c].has(e) or _echoes[c].has(e):
			return c
	return 0


## 清空所有单位 / 回声 / 分割块。
func _clear_all() -> void:
	for c in cell_count:
		for e in _units[c]:
			if is_instance_valid(e.node):
				e.node.queue_free()
		for e in _echoes[c]:
			if is_instance_valid(e.node):
				e.node.queue_free()
		_units[c] = []
		_echoes[c] = []
	for d in _dividers:
		if is_instance_valid(d):
			d.queue_free()
	_dividers = []
	_front = null
	# 重生成可能发生在「回声回合」中途（暂停推进 / 演出协程尚未结束）。
	# 必须在此把暂停 / 忙碌锁一并清零，否则重生成后轨道会永远卡在暂停态（队列不再推进、自动播放也被 _advance_paused 拒之门外）。
	# 注：回声演出协程(_play_and_remove_echoes)在节点被释放后仍以旧 Entry 引用运行，
	#      但其淡出 / 销毁路径均对 is_instance_valid 与 _echoes[cell]==[] 做了空值守卫，不会崩溃，仅留下一次无害的过期回调。
	_advance_paused = false
	_busy = false


func _build_dividers() -> void:
	for d in _dividers:
		if is_instance_valid(d):
			d.queue_free()
	_dividers = []
	for i in cell_count - 1:
		var tr := TextureRect.new()
		if ResourceLoader.exists(DIVIDER_TEX):
			tr.texture = load(DIVIDER_TEX)
		tr.expand_mode = TextureRect.EXPAND_KEEP_SIZE
		tr.stretch_mode = TextureRect.STRETCH_KEEP
		tr.size = Vector2(_div_w, _div_h)
		tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(tr)
		_dividers.append(tr)


## ---- 工厂 ----
func _make_unit(uid: String, faction: int, character: bool) -> Entry:
	var node := UNIT_CELL_SCENE.instantiate() as UnitCell
	node.unit_uid = uid
	node.is_character = character
	node.art_path = _unit_art_path(uid)   # 按 uid 取对应单位美术（缺则回退默认占位）
	node.set_state(faction, false)
	add_child(node)
	return Entry.new(node, uid, faction, false, character)


func _make_echo(uid: String, faction: int, is_first: bool) -> Entry:
	var node: Node2D
	if is_first:
		# 首格回声：用 UnitCell 尺寸盒渲染（50×80），内部回声美术居中；is_echo_override 使其被识别为回声。
		# 注意：实例化后 _ready 尚未运行（_art/_frame 为 null），故美术/阵营经 art_path / 普通 var 暂存，由 _ready 应用。
		var uc := UNIT_CELL_SCENE.instantiate() as UnitCell
		uc.is_echo_override = true
		uc.locked = true          # 回声属锁定类 → 边框 #474d50
		uc.unit_uid = uid
		uc.is_character = false
		uc.art_path = _unit_art_path(uid)   # 首格回声 = 基础单位尺寸盒 + 基础单位美术（非回声小美术），按施法者 uid 取 01
		uc.faction = faction
		uc.is_current_turn = false
		node = uc
	else:
		# 后续回声：50×30 回声格。
		var ec := ECHO_CELL_SCENE.instantiate() as EchoCell
		ec.unit_uid = uid
		ec.set_state(faction)   # set_state 对未初始化 _frame 安全（_apply_frame_color 有空值守卫，_ready 会按 faction 重新着色）
		ec.set_art_path(_echo_art_path(uid))   # 按施法者 uid 取 02 回声美术（缺则回退默认占位）
		node = ec
	add_child(node)
	return Entry.new(node, uid, faction, true, false)


## 生成「引导卡回声」（规则2·引导卡调度）：复用施法者同名美术，写入 echo_data（由 BattleRoot 组装效果数值，含连锁 M(n)）。
## 插入到指定 cell（= 费用-1 内的中间格）。该列无回声则插入【单位格尺寸首格回声】(UnitCell)，已有则插入【小回声格】(EchoCell)。
## 与 atb1 同名方法签名一致（caster_uid, cell, echo_data），供 BattleRoot.spawn_guide_echoes 直接调用。
## ⚠️ 仅生成并归位（下方推入 / 淡入），不在此推进队列——推进由 HandManager 打出卡后调 advance_framed(cost) 统一完成。
func spawn_echo(caster_uid: String, cell: int, echo_data: Dictionary) -> void:
	if _busy:
		return
	var c: int = clampi(cell, 1, cell_count - 1)
	var caster_faction: int = FACTION_ALLY   # 引导卡回声恒我方（施法者）
	var is_first: bool = _echoes[c].is_empty()
	var e := _make_echo(caster_uid, caster_faction, is_first)
	e.echo_data = echo_data
	_echoes[c].append(e)
	var rise_nodes: Array = []
	var fade_nodes: Array = []
	if is_first:
		rise_nodes.append(e.node)
	else:
		fade_nodes.append(e.node)
	_busy = true
	_relayout(true, rise_nodes, fade_nodes)
	await get_tree().create_timer(slide_time).timeout
	_busy = false


## 批量生成引导卡回声（修复：原 BattleRoot.spawn_guide_echoes 在循环里【非 await】调用 spawn_echo，
## 会被 _busy 门截断——第 1 次插入即置 _busy=true，后续 (cost-1) 次调用全部在「if _busy: return」处早退，
## 最终只生成 1 个回声而非 cost-1 个）。本函数同步插入 cells 1..cost-1 共 (cost-1) 个回声，
## 一次性 relayout + 单段滑入动画，规避多段 busy 串行与「只生成 1 个」bug。
## 每格堆叠规则（同 spawn_echo）：该列无回声 → 基础版(UnitCell)；已有 → 小回声格(EchoCell) 叠在其下。
## echo_data 由调用方组装（所有回声共用同一效果负载）；cost<2 不生成（引导卡费用死规矩≥2）。
func spawn_guide_echoes_batch(caster_uid: String, cost: int, echo_data: Dictionary) -> void:
	if _busy:
		return
	cost = maxi(cost, 2)
	var rise_nodes: Array = []
	var fade_nodes: Array = []
	for i in range(1, cost):
		var is_first: bool = _echoes[i].is_empty()
		var e := _make_echo(caster_uid, FACTION_ALLY, is_first)
		e.echo_data = echo_data
		_echoes[i].append(e)
		if is_first:
			rise_nodes.append(e.node)
		else:
			fade_nodes.append(e.node)
	_busy = true
	_relayout(true, rise_nodes, fade_nodes)
	await get_tree().create_timer(slide_time).timeout
	_busy = false


## ---- 队列查询 ----
## 返回某列的全部条目（单位在前、回声在后，自上而下）。
func _column_entries(c: int) -> Array:
	var out: Array = []
	for e in _units[c]:
		out.append(e)
	for e in _echoes[c]:
		out.append(e)
	return out


## 当前框内（cell0 列顶）条目 —— 必须【严格按同格优先级】取首格动作者：
##   回声 / 天气（_precedence=0，锁定类）恒在最前，【即便该格同时有单位（玩家/敌方）】，echo/weather 仍为前。
## 与 _relayout 的 row[0] 排序保持一致（回声经 _ordered_insert_index 插到队首）。
## ⚠️ 旧实现先查 _units[0] 再查 _echoes[0]，会导致「回声与单位同处 cell0」时把单位当框内前排 →
##   跳过回声的「暂停推进」逻辑，让同格敌方抢先行动并推进队列（即本轮回填的 bug）。故先查回声/天气，再查单位行。
func _compute_front() -> Entry:
	if not _echoes[0].is_empty():
		return _echoes[0][0]   # 基础回声（row[0]，优先级 0 恒最前；天气实现后同为 0，按 FIFO 取首个）
	if not _units[0].is_empty():
		return _units[0][0]
	return null


func _remove_unit(e: Entry) -> void:
	for c in cell_count:
		var idx: int = _units[c].find(e)
		if idx >= 0:
			_units[c].remove_at(idx)
			return


## 按 uid 移除对应【单位】条目（非回声），并重新布局；随后按该阵营 emit queue_reorder 触发战场站位重排。
## 若移除的是 cell0 当前前排且首格变空 → 推进队列消化空格（确保不卡死）；否则仅重排。
## 找不到 / 已是回声 → 忽略。供 BattleRoot._on_unit_died 调用。
func remove_unit_by_uid(uid: String) -> void:
	for c in cell_count:
		for i in range(_units[c].size()):
			var e = _units[c][i]   # 动态分发：_units[c] 内层为无类型数组，元素实为 Entry
			if not e.echo and e.uid == uid:
				if is_instance_valid(e.node):
					e.node.queue_free()
				_units[c].remove_at(i)
				var fac: String = "enemy" if e.faction == FACTION_ENEMY else "player"
				# 前排单位死亡 → 首格可能变空，需推进队列把后续单位送入 cell0（不卡死）；
				# 非前排仅重排 + 发 queue_reorder 刷新该阵营物理槽位。
				if _units[0].is_empty() and _echoes[0].is_empty():
					_advance_queue()      # 内部在 _front 变化时 emit queue_reorder("all")
				else:
					queue_reorder.emit(fac)
				_set_front(_compute_front())
				_relayout(true)
				return


## 击退：把指定单位从当前格向后（远离 cell0）移动 n 格，立即重排（不等待其行动）。
## 供 Grey 意图3 等「护盾未挡满则击退」：被攻击到（真实掉血=有效伤害）的玩家被推后，行动延后。
## - uid 即 UnitRoot.unit_id（build_roster/start_turn 入队时 uid 取 unit_id，与 BattleRoot._find_unit 同口径）。
## - clamp 到 [1, cell_count-1]：cell0 为行动格允许被推到 1（行动延后）；已在最远格则 no-op（先摘后判，无变化则还原回原格）。
## - 时机：在怪物结算(_resolve_enemy_intent)时调用，位于 execute_end 的整盘左移 tick 之前；
##   击退(+1) 后随 tick(-1) 净效果 = 该单位比「未被击退」时多延迟 1 格（其余单位也 tick，故相对位置变化正确）。
func retreat_unit(uid: String, n: int) -> void:
	if n <= 0 or uid == "":
		return
	# 定位该单位 Entry 并摘除，记录其当前格。
	var e: Entry = null
	var cur: int = -1
	for c in cell_count:
		for i in range(_units[c].size()):
			if not _units[c][i].echo and _units[c][i].uid == uid:
				e = _units[c][i]
				cur = c
				_units[c].remove_at(i)
				break
		if e != null:
			break
	if e == null:
		return   # 不在队列中（已死 / 回声 / 未入队）
	var dest: int = clampi(cur + n, 1, cell_count - 1)
	if dest == cur:
		_insert_unit(e, cur)   # 已在最远格，无变化 → 还原回原格
		return
	_insert_unit(e, dest)
	_relayout(true)

## 前进：把指定单位向 cell0 方向（索引减小）移动 n 格，立即重排（不等待其行动）。
## 供周周 E1 千里不留行（全体友方前进2）/ C5 问云手（末端单位前进1）等「加速抢拍」使用；与 retreat_unit 对称。
## - uid 即 UnitRoot.unit_id（与 build_roster/start_turn 入队时同口径）。
## - clamp 到 [0, cell_count-1]：允许推到 cell0（成为当前行动格 → 更早行动）；已在 cell0 则 no-op（先摘后判，无变化则还原回原格）。
## - 时机：玩家卡结算时调用（位于演出结束后的 flush 阶段）；重排后发 queue_reorder 刷新物理槽位。
func advance_unit(uid: String, n: int) -> void:
	if n <= 0 or uid == "":
		return
	var e: Entry = null
	var cur: int = -1
	for c in cell_count:
		for i in range(_units[c].size()):
			if not _units[c][i].echo and _units[c][i].uid == uid:
				e = _units[c][i]
				cur = c
				_units[c].remove_at(i)
				break
		if e != null:
			break
	if e == null:
		return   # 不在队列中（已死 / 回声 / 未入队）
	var dest: int = clampi(cur - n, 0, cell_count - 1)
	if dest == cur:
		_insert_unit(e, cur)   # 已在最前格，无变化 → 还原回原格
		return
	_insert_unit(e, dest)
	_relayout(true)
	queue_reorder.emit("enemy" if e.faction == FACTION_ENEMY else "player")


func _remove_echo(e: Entry) -> void:
	for c in cell_count:
		var idx: int = _echoes[c].find(e)
		if idx >= 0:
			_echoes[c].remove_at(idx)
			return


## 插入单位到目标格：按【同格内先后排序】插队（见 _precedence / _ordered_insert_index），
## 与 atb1 AtbTrack._insert 同规则 —— 天气 > 我方 > 敌方，同优先级【先来后到】(FIFO)。
## 只影响本格队列，其他格不动。
func _insert_unit(e: Entry, c: int) -> void:
	var q: Array = _units[c]
	q.erase(e)   # 防御：若该条目已在格内，先摘出再按序插回，避免重复入列
	q.insert(_ordered_insert_index(q, e), e)


## 同格内先后排序优先级（数值越小越靠前 / 越靠左），与 atb1 AtbTrack._precedence 一致：
##   回声基础块 / 天气(WEATHER) = 0（最高；二者同为「锁定类」，恒在队首最左，同级【先来后到】FIFO）
##   我方(ALLY)    = 10
##   敌方(ENEMY)   = 20
##   其它          = 30
## 注：atb1 另有「我方内部 即时(SWIFT) 排在执行(EXECUTION) 之后」的次级规则；atb2 的 Entry 暂无卡型字段，
##     待引入卡型后再补（当前我方内部为纯 FIFO）。
func _precedence(e: Entry) -> int:
	if e.echo:
		return 0   # 回声基础块与天气同为最高优先级 0（锁定类，恒在首格最左）
	match e.faction:
		FACTION_WEATHER:
			return 0
		FACTION_ALLY:
			return 10
		FACTION_ENEMY:
			return 20
		_:
			return 30


## 在格队列 q 中，条目 e 按 _precedence 应插入的槽位索引：
## 插到「第一个优先级【严格低于】e（数值更大）的条目」之前；若不存在则追加到队尾。
## 因只有严格更低才前插，同优先级条目一律排在既有同级【之后】→ 即【先来后到】(FIFO)。
func _ordered_insert_index(q: Array, e: Entry) -> int:
	var pr := _precedence(e)
	for i in q.size():
		if _precedence(q[i]) > pr:
			return i
	return q.size()


## 整体左移一格（cell0 清空后的「时间 tick」）：列 i = 列 i+1，末列清空。
## 每次左移 = 一个时间 tick：所有存活单位都朝 cell0 方向前进一格。
func _shift_left() -> void:
	for c in range(cell_count - 1):
		_units[c] = _units[c + 1]
		_echoes[c] = _echoes[c + 1]
	_units[cell_count - 1] = []
	_echoes[cell_count - 1] = []
	# 每前进一格 → 通知上层结算「逐格 DoT」（如出血）：携带本 tick 所有前移单位的 uid。
	var advanced: Array[String] = []
	for c in cell_count:
		for e in _units[c]:
			if not e.echo:
				advanced.append(e.uid)
	units_advanced.emit(advanced)


## 统计队列内剩余条目总数（单位 + 回声，跨所有格）。
func _queue_total() -> int:
	var n: int = 0
	for c in cell_count:
		n += _units[c].size() + _echoes[c].size()
	return n


## 【核心推进】cell0 占用者（单位行动 / 回声销毁）离场后推进队列：
## 若 cell0 变空，左移把后续占用者送入 cell0；遇空格（cell1 也为空）继续左移，
## 直到 cell0 有占用者或整队列清空（防止队列卡在「空格 + 远格有单位」之间、框内恒为空 → 死锁）。
## 仅更新数据与框内单位（_front / 信号 / 放大判定在 _relayout 内统一处理），不负责重排（由调用方统一 _relayout）。
## guard 防止异常情况下无限循环（理论上队列非空必能在 cell_count 次内把首占用者推到 cell0）。
func _advance_queue() -> void:
	var guard: int = 0
	while _units[0].is_empty() and _echoes[0].is_empty():
		if _queue_total() == 0:
			break   # 整队列已空，无更多占用者
		_shift_left()
		guard += 1
		if guard > cell_count + 2:
			break
	var f := _compute_front()
	if f != _front:
		queue_reorder.emit("all")
	_set_front(f)


## ---- 布局计算与重排 ----
## 【完全折叠·同 atb1】只有被占用的格参与排列：空队列格不显示、不占位；
## 分割块只在相邻两个「有内容」格之间出现，且【顶到上边】（y=0，与单位格顶边对齐），不再垂直居中。
##
## 同格内布局（用户铁规则）：
##   · 单位：在格顶【从左到右】横向排（与 atb1 一致），先后顺序 = 插入顺序。
##   · 首格回声：以【单位格尺寸】作为队列成员，横排进单位行（在各单位之后），【不堆叠】；
##     若某格已有首格回声 / 天气，后续回声以【小回声格】紧挨其【正下方】纵向堆叠、不重叠。
##   · 整组水平居中（按实际内容宽度）、顶部对齐 top_margin。
## rise_nodes：本次新生成的【首格回声】，从下方向上推入（起始位于目标下方 RISE_OFFSET，再上移归位）。
## fade_nodes：本次新生成的【后续回声】，直接淡入拼接到首格回声 / 天气下方（停留在目标位，透明度 0→1）。
func _relayout(animated: bool, rise_nodes: Array = [], fade_nodes: Array = []) -> void:
	if _relayout_tween != null and _relayout_tween.is_valid():
		_relayout_tween.kill()
		_relayout_tween = null

	var local_pos: Dictionary = {}
	# 分割块中心 x 列表（相邻「有内容」格之间各一个）。
	var div_xs: Array[float] = []
	var x: float = 0.0
	var placed: int = 0

	# 末位被占用格：仅在 [0, last_occ] 区间内渲染；区间外（真正队尾之后）的空队列格才折叠隐藏分割块。
	var last_occ: int = -1
	for c in cell_count:
		if not _units[c].is_empty() or not _echoes[c].is_empty():
			last_occ = c
	if last_occ < 0:
		# 队列全空：隐藏全部分割块并归位（保持居中锚点），不渲染任何格。
		for d in _dividers:
			d.visible = false
		var cx0: float = (get_viewport().size.x * 0.5) if center_screen else manual_center_x
		self.position = Vector2(cx0, top_margin + position_offset_y)
		_last_occ = -1
		_refresh_marker()
		return

	for c in range(0, last_occ + 1):
		var units: Array = _units[c]
		var echoes: Array = _echoes[c]
		var occupied: bool = not (units.is_empty() and echoes.is_empty())
		# 分割块：相邻「被渲染格」之间各一个（含中间的空队列格——空队列格也照插，补足到末位被占用格）。
		if placed > 0:
			x += divider_pad
			div_xs.append(x + _div_w * 0.5)
			x += _div_w + divider_pad
		if not occupied:
			# 空队列格：不占宽、不渲染内容，仅上方已插入的分割块标示其存在（补足到末位被占用格）。
			placed += 1
			continue

		# 组装横向单位行：单位（已按 _precedence 同格排队） + 【首格回声（基础尺寸）】。
		# 首格回声 = 锁定类，与天气同为 _precedence 0，横排进单位行时按 _precedence 插到队首（与天气并列最左、同级先来后到）。
		var base_echo = echoes[0] if not echoes.is_empty() else null
		var row: Array = []
		for e in units:
			row.append(e)
		if base_echo != null:
			row.insert(_ordered_insert_index(row, base_echo), base_echo)
	
		# 样式（影响 scale → 尺寸）：仅 cell0【首格】占用者放大 120%；首格占用者 = 单位行第 0 位（row[0]）。
		# 锁定类（天气 / 回声）恒 #474d50 优先；白框仅作用于【首格的非锁定单位】。
		var first_is_echo: bool = (not row.is_empty() and row[0].echo)
		for i in row.size():
			var e = row[i]
			if e.node is UnitCell:
				var first_in_cell0: bool = (c == 0 and i == 0 and not e.echo)
				(e.node as UnitCell).set_cell0_active(first_in_cell0, first_in_cell0)
	
		# 回声恒压暗（锁定类）。
		# ⚠️ 尺寸规则：回声组【只有自己占据 cell0 首格】时才放大 120%（基础回声 + 其下方堆叠小回声同步放大、位置紧贴不变）；
		#    若 cell0 首格被天气 / 单位占据（即 row[0] 不是回声），则回声即使同在 cell0 也恒为 100%。
		var echo_group_is_cell0_first: bool = (c == 0 and not echoes.is_empty() and first_is_echo)
		for i in echoes.size():
			var e = echoes[i]
			# 回声恒压暗（锁定类）：instant=true 直接置暗、不播动画，避免与下方淡入(alpha)动画争夺 modulate。
			e.node.set_dimmed(true, true)
			e.node.scale = Vector2(1.2, 1.2) if echo_group_is_cell0_first else Vector2(1.0, 1.0)

		var row_w: float = 0.0
		var row_h: float = 0.0
		for e in row:
			var sz: Vector2 = e.node.cell_size() * e.node.scale
			row_w += sz.x
			row_h = maxf(row_h, sz.y)
		if row.size() > 1:
			row_w += stack_gap * float(row.size() - 1)

		# 后续小回声（index≥1）最宽者参与列宽计算。
		var small_w: float = 0.0
		for i in range(1, echoes.size()):
			var sz: Vector2 = echoes[i].node.cell_size() * echoes[i].node.scale
			small_w = maxf(small_w, sz.x)

		var cell_w: float = maxf(row_w, small_w)
		if cell_w <= 0.0:
			cell_w = _unit_w

		var cell_left: float = x
		var cell_cx: float = x + cell_w * 0.5

		# 横向单位行：顶边对齐，中心 y = 半高，从左到右。
		var ux: float = cell_left
		var base_echo_x: float = cell_cx
		for e in row:
			var sz: Vector2 = e.node.cell_size() * e.node.scale
			local_pos[e.node] = Vector2(ux + sz.x * 0.5, sz.y * 0.5)
			if e == base_echo:
				base_echo_x = ux + sz.x * 0.5
			ux += sz.x + stack_gap

		# 后续小回声：紧贴【首格回声正下方】纵向堆叠（无首格回声的格不会进入此循环）。
		var ey: float = row_h + stack_gap
		for i in range(1, echoes.size()):
			var e = echoes[i]
			var sz: Vector2 = e.node.cell_size() * e.node.scale
			local_pos[e.node] = Vector2(base_echo_x, ey + sz.y * 0.5)
			ey += sz.y + stack_gap

		x += cell_w
		placed += 1
		# 缓存本列布局（供预览标记定位）：左缘 / 列宽 / 行高 / 行内条目（横向顺序）。
		_col_left[c] = cell_left
		_col_width[c] = cell_w
		_col_rowh[c] = row_h
		_col_row[c] = row

	# 分割块：按需显隐（渲染区间内的被渲染格之间各一个），且顶到上边 y=0。
	for i in _dividers.size():
		var d: TextureRect = _dividers[i]
		if i < div_xs.size():
			d.visible = true
			d.position = Vector2(div_xs[i] - _div_w * 0.5, 0.0)
		else:
			d.visible = false

	# 铁规则：整组水平居中（按实际内容宽度）、顶部对齐 top_margin + 位置偏移 position_offset_y（默认 0）。
	var cx: float = (get_viewport().size.x * 0.5) if center_screen else manual_center_x
	self.position = Vector2(cx - x * 0.5, top_margin + position_offset_y)

	# 应用位置（动画或瞬移）。新生成的回声按 rise（下方推入）/ fade（下方淡入）入场。
	var tw: Tween = null
	if animated:
		tw = get_tree().create_tween().set_parallel(true)
		_relayout_tween = tw
	for n in local_pos.keys():
		var target: Vector2 = local_pos[n]
		if animated and tw != null:
			if rise_nodes.has(n):
				# 首格回声：起始于目标下方 RISE_OFFSET，向上推入队列。
				n.position = Vector2(target.x, target.y + RISE_OFFSET)
				tw.tween_property(n, "position", target, slide_time)
			elif fade_nodes.has(n):
				# 后续回声：停留在目标位（首格回声/天气正下方），透明度 0→1 淡入拼接。
				n.position = target
				n.modulate.a = 0.0
				tw.tween_property(n, "modulate:a", 1.0, slide_time)
			else:
				tw.tween_property(n, "position", target, slide_time)
		else:
			n.position = target

	# 末位被占用列写入缓存（供 marker 定位）；刷新预览标记使其跟随最新布局（视觉不脱节）。
	_last_occ = last_occ
	_refresh_marker()


## ---- 框内单位变更 ----
func _set_front(e: Entry) -> void:
	if e == _front:
		return
	_front = e
	var uid := e.uid if e != null else ""
	var is_pl := e != null and not e.echo and e.faction == FACTION_ALLY
	framed_changed.emit(uid, is_pl)
	if e != null and not e.echo and e.faction == FACTION_ENEMY:
		enemy_action_started.emit(uid)
	# 首格特效组：任何【单位格节点】（玩家 / 敌方 / 天气 / 基础版回声）进入 cell0 时，由单位格自身播放竖向光束爆开特效。
	# · _loading 期间（初次 build_roster）不触发。
	# · 触发范围 = e.node is UnitCell：覆盖玩家单位、敌方单位、天气单位格、以及 atb2 以 UnitCell 尺寸渲染的
	#   【基础版回声格】（is_echo_override=true 的 UnitCell）。小回声格（EchoCell，50×30）不是 UnitCell，不触发。
	# · 特效已收编为单位格的模块化子节点（见 UnitCell.play_first_cell_fx），居中于单位格、随其移动 / 重排。
	# · 由 _set_front 的「前排实际变化」天然限流：仅当新单位格真正进入 cell0 才播一次。
	# · 先等待 FX_TRIGGER_DELAY（=0.2s）让单位落定，再播——避免「未到首格就爆开」抢拍。
	# · 【小版本回声（EchoCell）的首格特效】不在此处触发：其触发条件 = 堆叠上方的回声（基础版或小版本）演完「演出组」
	#   之后，由 _play_and_remove_echoes 的连锁循环按「上一格演完 → 下一格爆开 + 演出」链式播放（见该处）。
	if not _loading and e != null and e.node is UnitCell:
		var cell := e.node as UnitCell
		await get_tree().create_timer(FX_TRIGGER_DELAY).timeout
		if is_instance_valid(cell):
			cell.play_first_cell_fx()


## ---- 推进 / 执行结束 ----
## 让 cell0 当前单位行动，重新插入 target 格（≥1），并触发一次 tick（重排 / cell0 空则左移）。
func _act_front(target: int, rise_nodes: Array = [], fade_nodes: Array = []) -> void:
	if _busy:
		return
	var front := _compute_front()
	if front == null or front.echo:
		return
	_busy = true
	_remove_unit(front)
	# 先推进队列（把下一单位送入 cell0），再按费用把当前行动者插到目标格；
	# 避免「先插到 cell5 后整列左移」把行动者又推回 cell4（行动者应停在「当前格 + cost」= 末位被占用格处）。
	_advance_queue()
	_insert_unit(front, clampi(target, 1, cell_count - 1))
	_relayout(true, rise_nodes, fade_nodes)
	# 行动者已重新插回 target 格（可能与他者同格 / 占用已有格）→ 重排物理槽位（规则二），确保战场插槽按队列先后对位、不重叠。
	# 注：_advance_queue 仅在 _front 变化时 emit；此处插回后顺序已变但 _front 未必变，须补发以刷新双方插槽。
	queue_reorder.emit("all")
	await get_tree().create_timer(slide_time).timeout
	_busy = false
	# 落定后：若新框内为回声 / 敌方 / 天气 → 自动播放（玩家单位不自动，等手动「推进」）。
	await _maybe_auto_play()


## 玩家打出「有费用」卡：cell0 当前单位向前插入 cost 格（= cell0 + cost）。
## rise_nodes / fade_nodes：随本次推进新生成的回声节点，供入场动画使用。
## 返回 coroutine：等待本次推进（含重排动画）完成，便于外部 await。
func advance_framed(cost: int, rise_nodes: Array = [], fade_nodes: Array = []) -> void:
	if cost <= 0:
		return
	await _act_front(cost, rise_nodes, fade_nodes)


## ---- 自动播放（回声 / 天气 / 敌方进 cell0 首格时触发）----
## 玩家单位不自动（等手动「推进」或战斗中打牌推进）。仅当新框内为【回声 / 敌方 / 天气】时自动播放。
## 天气 / 回声视作「无法操控的单位格」（类似敌方类型）：
##   · 回声：依次演出首格全部回声（基础版→堆叠小版本）→ 整组原地淡出销毁 → 销毁结束后推进队列。
##   · 敌方 / 天气：演出效果 → 按设定落点（遵循同格先后顺序）重新插入队列 → 继续推进队列。
## 播放细节（1s 占位）后续对接真实演出；当前为占位实现。
func _maybe_auto_play() -> void:
	# 守卫：_busy=演出/重排动画进行中；_advance_paused=「回声回合」暂停推进锁。
	# ⚠️ 关键语义：此暂停【只冻结「将队列往前推进 / 自动触发下一格」这一动作】，
	#    绝不阻断【当前首格回声自身的演出播放】——回声播放走独立的 _play_and_remove_echoes 协程，
	#    不经此函数，故不受本守卫影响。回声演完销毁后由 _on_echo_fade_done 解除本锁。
	if _busy or _advance_paused:
		return
	var f := _compute_front()
	if f == null:
		return
	# 回声恒自动播放（测试场景回退 1s；Battle 集成经 echo_effect_requested 回调真实演出 + 结算后继续）。
	# 不受 auto_play_enemy 影响——回声进入 cell0 首格即须播放并销毁。
	if f.echo:
		await _auto_play(f)
		return
	# 天气系统尚未实现，预留：天气视作「无法操控单位格」亦自动播放。
	# 敌方自动推进仅测试场景启用(auto_play_enemy=true)；Battle 集成设 false，改由 BattleRoot 经
	# enemy_action_started 信号驱动真实演出并调 execute_end()，避免 atb2 内部与 BattleRoot 双重推进。
	if f.faction == FACTION_ENEMY and auto_play_enemy:
		await _auto_play(f)


## 演出效果对接端口（占位）：当前【不连接】游戏内演出组，以「1s 占位延时」模拟「演出组实际播放时长」。
## 真实演出接入时，把下述【1s 占位】替换为：按 e 的类型 / uid 触发对应演出并 await 演出完成即可。
## 所有演出调用点（回声基础版 / 堆叠小版本 / 敌方 / 天气）统一走这里，保证「仅一个端口」方便以后对接。
## （原黑色矩形可视化占位已移除，仅保留占位延时。）
func _perform_effect(e: Entry) -> void:
	# 回声（且 BattleRoot 已连接 echo_effect_requested）：经信号回调真实演出 + 结算，await 完成事件后继续。
	# 无连接（纯测试场景 / 未接入编排器）→ 回退 1s 占位延时，避免协程永久挂起。
	if e.echo and e.echo_data.size() > 0 and echo_effect_requested.get_connections().size() > 0:
		echo_effect_requested.emit(e.echo_data)
		await echo_effect_completed
	else:
		await get_tree().create_timer(1.0).timeout


func _auto_play(f: Entry) -> void:
	_busy = true
	if f.echo:
		# 进入「回声回合」：首格回声存在期间置 _advance_paused=true → 暂停整条队列推进（类比玩家回合：回合内 ATB 不 tick）。
		# 依次演出首格全部回声（基础版→堆叠小版本，走 _perform_effect 端口）→ 整组原地淡出；
		# 淡出动画【结束信号(tw.finished)】触发 _on_echo_fade_done：销毁整组 → 解除暂停 → 推进队列。
		# 推进完全由「回声真正销毁」这一事件驱动，【不再用定时器等待动画时长】卡推进，消除早前的重叠观感根因。
		# 此处不 await、不等待动画：演出+淡出由 _play_and_remove_echoes 在后台协程启动，销毁与推进由结束回调负责。
		_advance_paused = true
		_play_and_remove_echoes(0)
	else:
		# 敌方 / 天气（视作同类的「无法操控单位格」）：先通过统一端口演出效果，结束后按设定落点
		# （遵循同格先后顺序规则：天气/回声 > 我方 > 敌方）重新插入队列，并在这一过程中接着推进 ATB 队列。
		# 先释放 busy 再推进，避免 _act_front 的 _busy 守卫误拒；_act_front 末尾会衔接 _maybe_auto_play。
		await _perform_effect(f)
		_busy = false
		_act_front(_enemy_reinsert_target(f))   # _act_front 末尾会衔接 _maybe_auto_play


## 测试按钮「推进」：仅推进【玩家单位】（玩家单位不自动，等手动推进）；敌方 / 回声进 cell0 首格由自动播放处理。
## 推进后若新框内为敌方 / 回声 → 自动播放衔接。
func advance_random() -> void:
	if _busy:
		return
	var front := _compute_front()
	if front == null or front.echo or front.faction != FACTION_ALLY:
		return
	_busy = true
	_remove_unit(front)
	# 先推进队列（下一单位进 cell0 并 emit queue_reorder 重排物理槽位），再随机插回当前行动者，避免整列左移将其推回。
	var f := _compute_front()
	if _units[0].is_empty() and _echoes[0].is_empty():
		_shift_left()
		f = _compute_front()
		queue_reorder.emit("all")
	_set_front(f)
	_insert_unit(front, randi_range(1, cell_count - 1))
	_relayout(true)
	# 行动者随机插回某格（可能与他者同格）→ 补发 queue_reorder 刷新战场插槽（规则二），避免重叠。
	queue_reorder.emit("all")
	await get_tree().create_timer(slide_time).timeout
	_busy = false
	# 落定后：若新框内为回声 / 敌方 / 天气 → 自动播放衔接。
	await _maybe_auto_play()


## 播放并移除回声块：先依次演出首格【全部】回声的演出组效果（基础版→堆叠小版本，统一走 _perform_effect 端口），
## 全部演完后整组播放 FADE_OUT_TIME 原地淡出动画（仅透明度降至 0，不缩放、不扩散）。
## 淡出动画【结束信号】(tw.finished) 触发 _on_echo_fade_done：销毁整组 + 解除暂停(_advance_paused) + 推进队列。
## —— 推进完全由「回声真正销毁」这一事件驱动，【不再用定时器等待动画时长】卡推进（消除早前重叠观感的根因）。
## cell = -1：移除全部格的回声（预留）；cell = 0：仅移除 cell0 首格回声堆叠（自动播放用）。
## 本函数【不负责重排 / 不负责推进】——均由 _on_echo_fade_done 回调完成。
func _play_and_remove_echoes(cell: int = -1) -> void:
	var cells: Array[int] = []
	if cell < 0:
		for c in cell_count:
			cells.append(c)
	else:
		cells = [cell]
	var all: Array = []
	# 1) 演出组效果（连锁）：按【列 → 列内自上而下（基础版 i=0 → 堆叠小版本 i>=1）】顺序逐格演出，
	#    统一走 _perform_effect 端口（当前占位 1s 黑色矩形，后续对接真实演出）。
	#    · 基础版（i==0）的「首格特效组」已在 _set_front 进入首格时播过 → 此处只演其演出组。
	#    · 堆叠小版本（i>=1，EchoCell）：必须【等本格上方（i-1）回声演完（_perform_effect 完成）后】，
	#      才播其「小格特效(FirstCellEchoFX)」+ 演出组 —— 形成「上一格演完 → 下一格爆开 + 演出」的链式观感。
	#      这恰是用户要求：小版本特效触发条件 = 上方演完演出组后，而非「进入首格时」触发。
	for c in cells:
		for i in range(_echoes[c].size()):
			all.append(_echoes[c][i])
	if all.is_empty():
		return
	for c in cells:
		for i in range(_echoes[c].size()):
			var e = _echoes[c][i]
			# 仅堆叠小版本在「上方（i-1）演完」后触发其小格特效（基础版不在此重复触发）。
			if i >= 1 and e.node is EchoCell:
				(e.node as EchoCell).play_echo_fx()
			await _perform_effect(e)
	# 2) 整组原地淡出（仅透明度→0，不缩放、不扩散）。
	var tw := get_tree().create_tween().set_parallel(true)
	for e in all:
		if is_instance_valid(e.node):
			tw.tween_property(e.node, "modulate:a", 0.0, FADE_OUT_TIME)
	# 3) 淡出动画【结束】才销毁并推进——由结束信号事件驱动（本工程已验证 tw.finished 可靠），不再用定时器猜测时长。
	tw.finished.connect(_on_echo_fade_done.bind(cell), CONNECT_ONE_SHOT)


## 回声整组淡出动画结束回调：销毁该格全部回声（基础 + 小版本）、解除「暂停推进」、推进队列并衔接下一格自动播放。
## 由 _play_and_remove_echoes 的淡出 tween.finished 事件驱动（不靠定时器等待），保证「先销毁、后推进」。
func _on_echo_fade_done(cell: int) -> void:
	# 销毁整组回声节点并清空数据。
	for e in _echoes[cell]:
		if is_instance_valid(e.node):
			e.node.queue_free()
	_echoes[cell] = []
	# 回声回合结束：解除暂停，队列恢复正常推进。
	_advance_paused = false
	# 推进队列把下一占用者送入 cell0（并消化中间空格），避免 cell0 恒空死锁。
	_advance_queue()
	_relayout(true)
	_busy = false
	# 衔接下一格自动播放：若新框内为天气 / 回声 / 敌方 → 接着演出（busy 已释放、暂停已解除，正常触发）。
	_maybe_auto_play()


## 测试按钮「生成回声」：模拟打出一张引导卡（随机费用 2-3）。
## 取 cell0 当前单位(caster)为施法者，沿队列在格 1..cost-1 生成回声：该格无首格回声/天气 → 插入【单位尺寸首格回声】
## （横排进单位行）；已有 → 生成【小回声格】叠在其正下方。回声【先】完全生成（下方推入 / 淡入），
## 【再】推进队列格（单位前移，回声随队列左移 → 与单位格同时位移）。
func spawn_guide_demo(cost_override: int = -1) -> void:
	if _busy:
		return
	var front := _compute_front()
	if front == null or front.echo:
		return
	var caster_uid: String = front.uid
	var caster_faction: int = front.faction
	var cost: int = cost_override if cost_override >= 2 else randi_range(2, 3)
	var rise_nodes: Array = []
	var fade_nodes: Array = []
	for c in range(1, cost):
		# 首格判定：该列【首格】是否有回声（天气系统尚未实现，暂仅看回声列表是否为空）。
		# 无 → 生成【单位格尺寸】首格回声（下方上推，横排进单位行）；
		# 已有 → 生成【小回声格】淡入叠在首格回声正下方。
		var is_first: bool = _echoes[c].is_empty()
		var e := _make_echo(caster_uid, caster_faction, is_first)
		_echoes[c].append(e)
		if is_first:
			rise_nodes.append(e.node)
		else:
			fade_nodes.append(e.node)
	# 先生成回声：完全推入 / 淡入（await 结束才算生成完成）。
	_busy = true
	_relayout(true, rise_nodes, fade_nodes)
	await get_tree().create_timer(slide_time).timeout
	_busy = false
	# 回声生成完毕后再推进队列格：单位前移，回声随队列左移 → 与单位格同时位移。
	await advance_framed(cost)


## 消费 cell0 当前回声并推进队列（规则2·引导卡调度）：回声进框触发效果后移除自身，下一单位/回声顶上。
## 与 atb1 remove_framed_and_advance 同名，供测试场景 framed_changed 链路调用。
func remove_framed_and_advance() -> void:
	var front := _compute_front()
	if front == null or not front.echo:
		return
	_busy = true
	_remove_echo(front)
	_advance_queue()
	_relayout(true)
	await get_tree().create_timer(slide_time).timeout
	_busy = false


## ---- 聚光（每帧权威命中） ----
func set_spotlight(uid: String) -> void:
	if uid == _spot_uid:
		return
	_spot_uid = uid
	for c in cell_count:
		for e in _column_entries(c):
			if e.echo:
				continue   # 回声恒压暗，不被聚光还原
			var n := e.node as UnitCell
			if is_instance_valid(n):
				n.set_dimmed(_spot_uid != "" and n.unit_uid != _spot_uid)


## ---- 对外查询接口（供 BattleRoot / 测试场景） ----
## ---- atb1 兼容接口（供 BattleRoot / HandManager 沿用既有调用，无需改写编排器逻辑）----
## 返回该阵营在 ATB 队列中【前→后】的 unit_id 顺序：从 cell0(高亮框/即将行动) 逐格到队尾，格内按插入序。
## ⚠️ 回声(is_echo)不是战场单位，绝不作为战场位置读取信息（否则同 uid 回声会让施法者重复出现、物理槽位错乱）。
func get_faction_order(faction: String) -> Array[String]:
	var want := FACTION_ENEMY if faction == "enemy" else FACTION_ALLY
	var order: Array[String] = []
	for c in cell_count:
		for e in _column_entries(c):
			if not e.echo and e.faction == want:
				order.append(e.uid)
	return order


## 攻击范围查询（规则2）：返回 cells [lo, hi] 闭区间内全部条目的 uid（不区分阵营，越界 clamp 到 [0, cell_count-1]）。
func get_cell_unit_ids(lo: int, hi: int) -> Array[String]:
	var out: Array[String] = []
	lo = maxi(lo, 0)
	hi = mini(hi, cell_count - 1)
	for c in range(lo, hi + 1):
		for e in _column_entries(c):
			if is_instance_valid(e.node):
				out.append(e.uid)
	return out


## 返回某 uid 条目当前所在 cell（找不到返回 0）。⚠️ 回声与施法者同 uid 但非真实单位，必须跳过，否则索敌基准错位。
func get_unit_cell(uid: String) -> int:
	for c in cell_count:
		for e in _column_entries(c):
			if not e.echo and e.uid == uid:
				return c
	return 0


## 敌方重入队目标格：优先用单位自身速度档（UnitRoot.enemy_reinsert_cell），非敌方 / 节点无此方法 → 回落纯随机。
## 取代旧的固定 randi_range(1, cell_count-1) —— 让怪物行动后的等待距离受「速度」档位控制（见怪物设计总表·速度段）。
func _enemy_reinsert_target(e: Entry) -> int:
	if e != null and is_instance_valid(e.node) and e.node.has_method("enemy_reinsert_cell"):
		return e.node.enemy_reinsert_cell(cell_count - 1)
	return randi_range(1, cell_count - 1)


## 玩家/敌方单位行动结束：将 cell0 当前【非回声】单位重新插入目标格（常规 tick=随机格；cost_override>=0=「当前格+cost」插队式），
## 并触发一次 tick（重排 / cell0 空则左移、消化中间空格）。与 atb1 execute_end 同名同义。
## autoplay=false：插入后不自动播放（由 BattleRoot 经 enemy_action_started / echo_effect_requested 驱动，避免双重推进）。
func execute_end(cost_override: int = -1) -> void:
	if _busy:
		return
	var front := _compute_front()
	if front == null or front.echo:
		return
	_busy = true
	var col: int = _column_of(front)
	var target: int
	if cost_override >= 0:
		target = clampi(col + cost_override, 1, cell_count - 1)
	else:
		target = _enemy_reinsert_target(front)
		# 特殊意图（如 Mafe 意图4）：行动后额外前进（靠近 cell0）N 格；消费后清零。
		if front.node is UnitRoot and front.node.pending_atb_advance > 0:
			target = clampi(target - front.node.pending_atb_advance, 1, cell_count - 1)
			front.node.pending_atb_advance = 0
	_remove_unit(front)
	# 先推进队列（下一单位进 cell0），再按费用把当前行动者插到目标格，避免整列左移将其推回前一格。
	_advance_queue()
	_insert_unit(front, target)
	_relayout(true)
	# 行动者已重新插回 target 格（可能与他者同格）→ 补发 queue_reorder 刷新战场插槽（规则二），避免重叠。
	queue_reorder.emit("all")
	await get_tree().create_timer(slide_time).timeout
	_busy = false
	_maybe_auto_play()


## 返回当前框内条目携带的回声效果负载（规则2·引导卡）。非回声 / 无则返回空 Dictionary。
## 取代 atb1 的 `framed_part().echo_data`（atb2 的 framed_part 返回裸节点，无 echo_data 字段）。
func framed_echo_data() -> Dictionary:
	if _front != null and _front.echo:
		return _front.echo_data
	return {}


## BattleRoot 完成回声效果演出 + 结算后调用，唤醒 _perform_effect 中 await 的回声协程，使 atb2 继续淡出 + 推进。
func complete_echo_effect() -> void:
	echo_effect_completed.emit()


## 敌方意图联动占位：atb2 单位格 / 回声格不含意图 icon（美术铁规则），故此处为空实现，仅保持与 atb1 同签名以便 BattleRoot 直接调用。
func apply_enemy_intent(uid: String, type_id: String, target_id: String, value: String, target_faction: String = "", target_range: int = -1, scope: String = "单体") -> void:
	pass


## ---- 插入位置预览标记（移植自 atb1，atb2 仅保留底部三角）----
## 单一白色底部三角 ▲：apex 朝上、指向中心（inward），落于「插入行正下方」并指向上方的插入槽；
## 锚定在「悬停付费卡对应单位向前推进 cost 格后的插入位」——即该卡打出后单位将落入的位置。
## 三角向插入槽方向轻微浮动仅作视觉提示。常态隐藏，仅悬停付费卡时由 preview_cost_for 显示；0 费卡 / 无悬停时隐藏。
func _build_marker() -> void:
	_insert_marker = Node2D.new()
	_insert_marker.name = "InsertMarker"
	_insert_marker.z_index = 20
	_insert_marker.visible = false
	add_child(_insert_marker)

	# 底部三角 ▲：apex 朝上，指向中心（inward），约 10px；y 由 _refresh_marker 按行高锚定到行底边下方。
	_tri_bot = Polygon2D.new()
	_tri_bot.color = Color.WHITE
	_tri_bot.polygon = PackedVector2Array([Vector2(0.0, -5.0), Vector2(-5.0, 5.0), Vector2(5.0, 5.0)])
	_tri_bot.position = Vector2(0.0, 0.0)
	_tri_bot.add_child(_make_outline(_tri_bot.polygon))
	_insert_marker.add_child(_tri_bot)


## 沿三角轮廓生成暗金(COLOR_ENHANCED) 2px 描边（闭合 Line2D），作为三角子节点随浮动动画一起移动。
func _make_outline(poly: PackedVector2Array) -> Line2D:
	var line := Line2D.new()
	line.points = poly
	line.closed = true
	line.width = 2.0
	line.default_color = COLOR_ENHANCED
	line.z_index = 1
	return line


## 预览：悬停一张费用为 cost、归属单位 uid 的手牌时，把插入预览标记移到
## 「该单位当前所在列 + cost」列的插入位（即打这张牌后单位将落入的位置）。
## 仅在悬停付费卡时显示；0 费卡（即时施放、不插队）不显示预览。常态下（无悬停）标记隐藏。
## ⚠️ atb2 无「框内单位下次落点」概念（execute_end 走随机格），故预览统一以「uid 当前列 + cost」为准，与 advance_framed/execute_end 的插队式规则一致。
func preview_cost_for(cost: int, uid: String) -> void:
	if _insert_marker == null:
		return
	# 0 费卡不插队 → 不显示预览标记
	if cost <= 0 or _last_occ < 0:
		clear_preview()
		return
	# 找 uid 当前所在列（跳过回声：回声与施法者同 uid 但非真实单位）。
	var col := -1
	for c in cell_count:
		for e in _column_entries(c):
			if not e.echo and e.uid == uid:
				col = c
				break
		if col >= 0:
			break
	if col < 0:
		clear_preview()
		return
	_marker_target = clampi(col + cost, 1, cell_count - 1)
	_marker_uid = uid
	_insert_marker.visible = true
	_refresh_marker()
	_start_float()


## 清除费用预览：鼠标离开卡牌 → 隐藏插入预览标记（常态不显示）。
func clear_preview() -> void:
	if _insert_marker != null and _insert_marker.visible:
		_insert_marker.visible = false
		_stop_float()
	_marker_target = -1
	_marker_uid = ""


## 参数化预览落点：给定目标列 target 与要插入的单位 uid，返回「该单位应插入 target 列的位置」（局部坐标）。
## 规则与 advance_framed/execute_end 实际插入一致（同 _ordered_insert_index、同格内横向排布）。仅用于预览，不改 _units/_echoes。
## ⚠️ atb2 坐标系与 atb1 不同：此处基于 _relayout 缓存的每列 left/row_h/row 重算，而非 atb1 的固定列网格+分割线坐标。
## 预览落点分两步（见 _compute_marker_slot）：
##   第1步 列基准 —— 目标列在队列中的左缘 X（占用列走 _relayout 缓存；空列走规则4 分割块中心；超队尾按标准列宽外推），
##            以及该列行高（供底部三角锚定到行底边下方）。
##   第2步 列内位移 —— 按规则2（天气/回声>我方>敌方+先来后到）求插入槽位，沿 X 累加「每个前置单位格宽 + stack_gap」。

## 第1步（横向）：目标列左缘 X（局部坐标）。
## 占用列：_relayout 真实缓存 _col_left；空列（规则4）：单插入单位居中于包围它的两块分割块 → 左缘 = 分割块中心 − 单位宽半；
## 超末位占用列（cost 推到队尾之后）：按标准列宽外推。
func _column_base_left(target: int) -> float:
	if target <= _last_occ and _col_row[target] != null and (_col_row[target] as Array).size() > 0:
		return float(_col_left[target])
	if target <= _last_occ:
		# 空队列格：取左右分割块中心，单插入单位居中于其间（规则4）。
		var left_bound: float = 0.0
		var right_bound: float
		if target >= 1 and _dividers.size() > target - 1 and is_instance_valid(_dividers[target - 1]) and _dividers[target - 1].visible:
			left_bound = _dividers[target - 1].position.x + _div_w * 0.5
		if _dividers.size() > target and is_instance_valid(_dividers[target]) and _dividers[target].visible:
			right_bound = _dividers[target].position.x + _div_w * 0.5
		else:
			right_bound = float(_col_left[_last_occ] + _col_width[_last_occ]) if _last_occ >= 0 else 0.0
		var cx := (left_bound + right_bound) * 0.5
		return cx - _unit_w * 0.5
	# 超末位占用列：标准列宽外推（cost 推到队尾之后）。
	var std := _unit_w + divider_pad * 2.0 + _div_w
	var base := float(_col_left[_last_occ] + _col_width[_last_occ]) if _last_occ >= 0 else 0.0
	return base + (target - _last_occ) * std

## 第1步（纵向）：目标列行高，供底部三角锚定到行底边下方；空列/超队尾无内容用标准单位格高 80。
func _column_row_h(target: int) -> float:
	if target <= _last_occ and _col_row[target] != null and (_col_row[target] as Array).size() > 0:
		return float(_col_rowh[target])
	if target <= _last_occ:
		return 80.0
	return float(_col_rowh[_last_occ]) if _last_occ >= 0 else 80.0

func _compute_marker_slot(target: int, uid: String) -> Vector2:
	if _last_occ < 0 or target < 0 or target >= cell_count:
		return Vector2.ZERO
	# 取 uid 阵营（决定同格先后优先级），找不到则默认我方。
	var faction := FACTION_ALLY
	for c in cell_count:
		for e in _column_entries(c):
			if not e.echo and e.uid == uid:
				faction = e.faction
				break
	# 第1步：列基准（左缘 + 行高）。
	var left: float = _column_base_left(target)
	var rowh: float = _column_row_h(target)
	var row: Array = (_col_row[target] as Array) if (target <= _last_occ) else []
	# 第2步：列内位移 —— 按规则2 先后（天气/回声>我方>敌方+先来后到）求插入槽位，
	# 再沿 X 累加「每个前置单位格宽 + stack_gap」，得插入中心（占位单位宽 = 单位格基础宽 _unit_w）。
	var ne := Entry.new(null, uid, faction, false, faction == FACTION_ALLY)
	var idx := _ordered_insert_index(row, ne)
	var items: Array = []
	for e in row:
		var w := _unit_w
		if is_instance_valid(e.node):
			var sz: Vector2 = e.node.cell_size() * e.node.scale
			w = sz.x
		items.append(w)
	items.insert(idx, _unit_w)
	var ux := left
	var cx_res := left
	for i in items.size():
		var w: float = items[i]
		if i == idx:
			# 占用列：插在「第 idx 个单位左侧的精确边界」——即单位格之间的缝隙（tip 指缝隙，而非压在某格中心）。
			# 空列 / 超队尾（row 空、仅有占位单位）：落在该列或外推槽的正中（分割块中心 / 槽中心）。
			cx_res = ux if not row.is_empty() else (ux + w * 0.5)
		ux += w + stack_gap
	# 垂直中心 = 行高一半（行顶对齐 y=0，单位/首格回声高 ~80 → 中心 ~40）。
	var y_res := rowh * 0.5
	_marker_rowh = rowh   # 缓存行高，供 _refresh_marker 把底部三角锚定到行底边下方
	return Vector2(cx_res, y_res)


## 预览标记位置刷新（跟随最新目标列 + 上下偏移）；目标无效时隐藏。
## 底部三角按目标列行高锚定到「插入行底边下方 marker_bot_gap」，指向上方的插入槽，不再压在格子上。
func _refresh_marker() -> void:
	if _insert_marker == null or not _insert_marker.visible:
		return
	if _marker_target < 0:
		_insert_marker.visible = false
		return
	_insert_marker.position = _compute_marker_slot(_marker_target, _marker_uid) + Vector2(0.0, marker_y_offset)
	# 底部三角：落在插入行正下方（行中心 + 半行高 + 间隙），向上指向插入槽。
	_tri_bot.position.y = _marker_rowh * 0.5 + marker_bot_gap


## 调试：切换插入位置预览（上下三角占位组）的显隐，并启停浮动动画（以框内单位「当前列+1」为预览落点）。
func toggle_insert_marker() -> void:
	if _insert_marker == null:
		return
	if _insert_marker.visible:
		clear_preview()
		return
	var f := _compute_front()
	if f == null or f.echo:
		return
	var col := -1
	for c in cell_count:
		for e in _column_entries(c):
			if not e.echo and e.uid == f.uid:
				col = c
				break
		if col >= 0:
			break
	if col < 0:
		return
	_marker_target = clampi(col + 1, 1, cell_count - 1)
	_marker_uid = f.uid
	_insert_marker.visible = true
	_refresh_marker()
	_start_float()


## 底部三角跑一条无限循环 tween：本地 Y 在锚定基位(由 _refresh_marker 设定) 与「基位−amp」间正弦往返，
## 即轻微向插入槽方向上探 / 回落，提示此处为插入落点。
func _start_float() -> void:
	_stop_float()
	if _tri_bot == null:
		return
	var base := _tri_bot.position.y
	var t_bot := get_tree().create_tween().set_loops(-1)
	t_bot.tween_property(_tri_bot, "position:y", base - marker_float_amp, marker_float_time).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	t_bot.tween_property(_tri_bot, "position:y", base, marker_float_time).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	_float_tweens = [t_bot]


func _stop_float() -> void:
	for t in _float_tweens:
		if t != null and t.is_valid():
			t.kill()
	_float_tweens.clear()


## 返回当前框内条目对应的节点（含 is_echo / unit_uid）。无则返回 null。
## 返回 Variant：节点实为 UnitCell / EchoCell 混合，调用方以动态分发访问其方法。
func framed_part():
	return _front.node if _front != null else null


## 是否处于 tick 中（_busy 守卫）。
func is_busy() -> bool:
	return _busy


## 返回所有条目节点（供每帧权威命中测试）。
func get_parts() -> Array:
	var out: Array = []
	for c in cell_count:
		for e in _column_entries(c):
			out.append(e.node)
	return out
